const express = require("express");
const router = express.Router();


router.get("/list", list);



module.exports = router;