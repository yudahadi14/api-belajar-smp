const express = require("express");
const {
  historyAppointment,
  batalAppointment,
  historyAppDetail,
} = require("../../controllers/api/antrianController");
const router = express.Router();

const authMid = require("../../middleware/authMid");

router.get("/history", authMid, historyAppointment);
router.get("/history/detail", authMid, historyAppDetail);
router.post("/cancel", authMid, batalAppointment);

module.exports = router;
