const express = require("express");
const {
  uploadJantung,
  listJantung,
  findJantung,
} = require("../../controllers/api/RSUD/jantungController");
const { error } = require("../../helpers/utility/response");
const authMid = require("../../middleware/authMid");
const router = express.Router();

const upload = require("../../helpers/utility/uploads");
const {
  addSignature,
  findSignature,
} = require("../../controllers/api/RSUD/signatureController");
const {
  generatePDF,
  requestSKL,
  listKelahiran,
  getKakiBayi,
  getIbuJari,
  latestRequestSKL,
} = require("../../controllers/api/RSUD/kelahiranController");
const {
  addSign,
  getSign,
  getSignPhoto,
} = require("../../controllers/api/RSUD/signatureC");

const many = upload("jantung").any("file");
const single = upload("skl_request").any("file");

router.get("/jantung", authMid, listJantung);
router.get("/jantung/find", findJantung);
router.post(
  "/jantung/jantung-upload",
  authMid,
  (req, res, next) =>
    many(req, res, (err) => {
      if (err) {
        return error(req, res, [], err.message);
      }
      next();
    }),
  //   postFoto,
  uploadJantung
);

//SIGANTURE
router.post("/signature/add", authMid, addSignature);
router.get("/signature/find", findSignature);

//SIGANTURE
router.get("/sign/add", addSign);
router.get("/sign/get-photo", getSignPhoto);
router.get("/sign/get", getSign);

router.get("/kelahiran/print", generatePDF);
router.get("/kelahiran", authMid, listKelahiran);
router.get("/kelahiran/request-skl", authMid, latestRequestSKL);
router.get("/kelahiran/ibu-jari", getIbuJari);
router.get("/kelahiran/kaki-bayi", getKakiBayi);
router.post(
  "/kelahiran/request-skl",
  authMid,
  (req, res, next) => {
    single(req, res, (err) => {
      if (err) {
        return error(req, res, [], err.message);
      }
      next();
    });
  },
  requestSKL
);

module.exports = router;
