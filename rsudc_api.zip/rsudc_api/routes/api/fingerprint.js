const express = require("express");
const router = express.Router();
const {
  addDevice,
  addFinger,
  getDevice,
  register,
  processVerification,
  generateVerification,
  verification,
  generateRegister,
  returnMessage,
  testController,
  testQuery,
} = require("../../controllers/api/RSUD/fingerprintC");

router.post("/add", addDevice);
router.get("/get-device", getDevice);

router.get("/register", register);
router.get("/generate-register", generateRegister);
router.post("/process-register", addFinger);

router.get("/generate-verification", generateVerification);
router.get("/verification", verification);
router.post("/process-verification", processVerification);

router.get("/return-message", returnMessage);

router.get("/test", testQuery);
module.exports = router;
