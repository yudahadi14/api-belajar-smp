const express = require("express");
const {
  getUbeRule,
  getUbe,
  addUbe,
  getUbeRuleGroup,
  createUbeRule,
  exportUbe,
  editUbeRule,
  lockUbe,
  findUbeUser,
  exportUbeData,
  editUbeRuleNew,
  addUbeRule,
  deleteUbeRule,
  listFiles,
  putFile,
  addFile,
  removeUbe,
} = require("../../controllers/api/ubeController");
const uploadUbe = require("../../middleware/uploadUbe");
const authMid = require("../../middleware/authMid");
const ubeMid = require("../../middleware/ubeMid");
const router = express.Router();

router.get("/list", authMid, getUbe);
router.get("/user/find", authMid, findUbeUser);
router.get("/export", exportUbe);
router.get("/export-data", exportUbeData);
router.get("/rule-group", authMid, ubeMid, getUbeRuleGroup);
router.get("/rule", authMid, ubeMid, getUbeRule);
router.post("/rule/create", authMid, ubeMid, createUbeRule);
router.post("/rule/add", authMid, ubeMid, addUbeRule);
router.put("/rule/edit", authMid, ubeMid, editUbeRuleNew);
router.delete("/rule/delete", authMid, ubeMid, deleteUbeRule);
router.post("/add", authMid, uploadUbe, addUbe);
router.post("/lock", authMid, ubeMid, lockUbe);
router.delete("/remove", authMid, ubeMid, removeUbe);
router.get("/files", authMid, ubeMid, listFiles);
router.put("/files/edit", authMid, ubeMid, putFile);
router.post("/files/add", authMid, ubeMid, addFile);
module.exports = router;
