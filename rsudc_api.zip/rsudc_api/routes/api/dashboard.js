const express = require("express");
const {
  kunjunganBulanan,
  kunjunganMerchant,
  kunjunganHarian,
  kunjunganRajal,
} = require("../../controllers/api/RSUD/dashboardController");
const router = express.Router();

router.get("/kunjungan/bulanan", kunjunganBulanan);
router.get("/kunjungan/merchant", kunjunganMerchant);
router.get("/kunjungan/harian", kunjunganHarian);
router.get("/kunjungan/rajal", kunjunganRajal);

module.exports = router;
