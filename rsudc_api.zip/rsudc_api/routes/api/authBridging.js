const express = require("express");
const {
  getToken,
  addUser,
} = require("../../controllers/api/authBridgingController");
const router = express.Router();

router.post("/create", addUser);
router.get("/token", getToken);
router.post("/token", getToken);
module.exports = router;
