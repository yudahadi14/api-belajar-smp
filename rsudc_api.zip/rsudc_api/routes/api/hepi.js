const express = require("express");
const { tambahHepB } = require("../../controllers/api/SIHEPI/hepiBController");
const {
  tempC,
  checkPasien,
  updateTes,
  updateFRHepC,
  updateTesHepC,
} = require("../../controllers/api/SIHEPI/hepiCController");
const router = express.Router();

router.post("/tambah-tes-b", tambahHepB);
router.post("/tambah-temp-c", tempC);
router.get("/cari-pasien", checkPasien);

router.post("/fr-hep-c", updateFRHepC);
router.post("/tambah-tes-hep-c", updateTesHepC);
// router.post("/tambah-tes-c", updateTes);
module.exports = router;
