const express = require("express");
const router = express.Router();
const {
  daftarOnline,
  inapPulang,
  ambilAntrian,
  cariRujukan,
  ambilAntrianByPass,
  findHargaPoli,
  findTutupPoli,
  latestErrorMobile,
  daftarIGDBaru,
  daftarIGDLama,
  checkPasien,
  poliTutupMendadak,
} = require("../../controllers/api/layananController");
const {
  validDaftarOnline,
  validDaftarVaksin,
} = require("../../helpers/validators/layanan");
const authMid = require("../../middleware/authMid");
const uploadID = require("../../middleware/uploadID");
const uploadIDRemote = require("../../middleware/uploadIDRemote");

router.post(
  "/daftar-baru",
  validDaftarOnline,
  uploadID,
  uploadIDRemote,
  daftarOnline
);
router.post(
  "/daftar-igd-baru",
  validDaftarOnline,
  uploadID,
  uploadIDRemote,
  daftarIGDBaru
);
router.post("/daftar-igd-lama", daftarIGDLama);
router.get("/check-pasien", checkPasien);
router.post("/daftar-vaksin", validDaftarVaksin, daftarOnline);
router.get("/rawat-inap/pulang", authMid, inapPulang);
router.get("/cari-rujukan", cariRujukan);
router.post("/ambil-antrian", authMid, ambilAntrian);
router.post("/ambil-antrian-admin", ambilAntrianByPass);
router.get("/harga-daftar", findHargaPoli);
router.get("/tutup-poli", findTutupPoli);
router.get("/latest-error", latestErrorMobile);
router.post("/blast-wa/tutup-poli", poliTutupMendadak);

module.exports = router;
