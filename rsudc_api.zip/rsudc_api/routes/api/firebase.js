const express = require("express");
const router = express.Router();
const {
  sendFcm,
  setTokenAdmin,
  setTokenDevice,
} = require("../../controllers/api/Firebase/cloudMessagingController");
const authMid = require("../../middleware/authMid");

router.post("/send", sendFcm);
router.post("/set-token-admin", authMid, setTokenAdmin);
router.post("/set-token-device", setTokenDevice);

module.exports = router;
