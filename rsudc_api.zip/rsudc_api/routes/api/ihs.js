const express = require("express");
const {
  addCondition,
} = require("../../controllers/api/IHS/conditionController");
const {
  addEncounter,
  putEncounter,
  funcAddEncounter,
} = require("../../controllers/api/IHS/encounterController");
const {
  addLocation,
  getLocation,
  testC,
} = require("../../controllers/api/IHS/locationController");
const {
  addOrganization,
  getOrganization,
} = require("../../controllers/api/IHS/organizationController");
const {
  getPasienByNIK,
  getPasienData,
} = require("../../controllers/api/IHS/patientController");
const {
  getPractionerByNIK,
} = require("../../controllers/api/IHS/practionerController");
const {
  addObservation,
} = require("../../controllers/api/IHS/observationController");
const {
  addProcedure,
} = require("../../controllers/api/IHS/procedureController");
const {
  addComposition,
} = require("../../controllers/api/IHS/compositionController");
const {
  reqMedication,
  dispenseMedication,
} = require("../../controllers/api/IHS/medicationController");
const {
  serviceRequest,
  observation,
} = require("../../controllers/api/IHS/labController");
const router = express.Router();
const { pagination } = require("../../helpers/utility/common");
const {
  funcAddCondition,
} = require("../../controllers/api/IHS/conditionController");

const { autoSync } = require("../../controllers/api/IHS/automationController");

// router.post("/add-location", addLocation);
// router.get("/location", getLocation);

// router.post("/add-organization", addOrganization);
// router.get("/organization", getOrganization);

// router.get("/patient/nik", getPasienByNIK);
// router.get("/patient", getPasienData);

// router.get("/practioner/nik", getPractionerByNIK);

// router.post("/encounter/planned", addEncounter);
// router.put("/encounter/progress", putEncounter);

// router.post("/condition/add", addCondition);

// router.post("/observation/add", addObservation);

// router.post("/procedure/add", addProcedure);

// router.post("/composition/add", addComposition);

// router.get("/test", testC);

// router.get("/medication/request", reqMedication);

// router.get("/medication/dispense", dispenseMedication);

// router.get("/service/add", serviceRequest);
// router.get("/observation/add", observation);

router.get("/sync-auto", autoSync);

module.exports = router;
