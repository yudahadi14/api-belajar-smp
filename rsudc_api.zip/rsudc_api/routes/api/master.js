const express = require("express");
const router = express.Router();
const {
  pekerjaan,
  pendidikan,
  agama,
  jenisIdentitas,
  statusNikah,
  produk,
  getNIK,
  getTipeBerkas,
  getPenanggung,
  getPropinsi,
  getKotamadya,
  getKecamatan,
  getKelurahan,
  getPoliBPJS,
  getGeoLocation,
  findMaintenance,
} = require("../../controllers/api/masterController");

router.get("/agama", agama);
router.get("/produk", produk);
router.get("/pekerjaan", pekerjaan);
router.get("/pendidikan", pendidikan);
router.get("/status-nikah", statusNikah);
router.get("/jenis-identitas", jenisIdentitas);
router.get("/get-nik", getNIK);
router.get("/tipe-berkas", getTipeBerkas);
router.get("/penanggung", getPenanggung);

router.get("/propinsi", getPropinsi);
router.get("/kotamadya", getKotamadya);
router.get("/kecamatan", getKecamatan);
router.get("/kelurahan", getKelurahan);

router.get("/dinas/geolocation", getGeoLocation);
router.get("/poli-bpjs/cari", getPoliBPJS);
router.get("/maintenance", findMaintenance);
module.exports = router;
