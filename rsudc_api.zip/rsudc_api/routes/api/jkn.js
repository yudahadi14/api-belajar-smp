const express = require("express");
const upload = require("../../helpers/utility/uploads");
const router = express.Router();

const {
  jadwalPoliDokter,
  listPoli,
} = require("../../controllers/api/jaksehat/perjanjianRaJal/jadwalController");
const {
  findPasien,
  cekRujukanBPJS,
  daftarPasien,
} = require("../../controllers/api/jaksehat/perjanjianRaJal/pasienController");
const {
  createAppointment,
  findAppointment,
  sisaAntri,
  cancelAppointment,
} = require("../../controllers/api/jaksehat/perjanjianRaJal/perjanjianController");

const { validDaftarOnline } = require("../../helpers/validators/jkn");
const { error } = require("../../controllers/api/jaksehat/helpers/responser");
const authMid = require("../../controllers/api/jaksehat/helpers/auth");
const {
  perPoli,
  top10Diagnosa,
} = require("../../controllers/api/jaksehat/eisDinkes/kunjungan");
const { ambilAntrianTest } = require("../../controllers/api/layananController");
const single = upload("identitas").single("identity");
router.get("/patient/find/:type/:number", authMid, findPasien);
router.post(
  "/patient/create",
  authMid,
  (req, res, next) =>
    single(req, res, (err) => {
      if (err) {
        return error(req, res, [], err.message);
      }
      next();
    }),
  validDaftarOnline,
  daftarPasien
);

router.get("/refference/find/bpjs/:bpjs", authMid, cekRujukanBPJS);
router.get("/layanan", authMid, listPoli);

router.get("/doctor/schedule/:poli_id/:visit_date", authMid, jadwalPoliDokter); //quota masih belom ada querynya

router.get(
  "/appointment/search/:noMr/:startDate/:endDate",
  authMid,
  findAppointment
);
router.get("/appointment/sisa-antrian/:kodebooking", authMid, sisaAntri);
router.put("/appointment/cancel", authMid, cancelAppointment);
router.post("/appointment/create", authMid, createAppointment);

router.post("/eis/kunjungan/poli", authMid, perPoli);
router.post("/eis/kunjungan/top-diagnosa", authMid, top10Diagnosa);

module.exports = router;
