const express = require("express");
const { paketMCU } = require("../../controllers/api/productController");
const router = express.Router();
const authMid = require("../../middleware/authMid");

router.get("/paket-mcu", paketMCU);

module.exports = router;
