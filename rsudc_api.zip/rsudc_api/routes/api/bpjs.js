const express = require("express");
const {
  refPoli,
  refDokter,
  refJadwalDokter,
  updateJadwalDokter,
  daftarBaruBPJS,
  updateWaktuAntri,
  batalBPJS,
  dashboardTgl,
  dashboardBln,
  ambilListTask,
  antreanPerTgl,
  bulkUpdateAntrian,
} = require("../../controllers/api/BPJS/Antrian/wsBPJSController");

const { getToken } = require("../../controllers/api/BPJS/Auth/authController");
const {
  statusAntrian,
  ambilAntrian,
  sisaAntrian,
  batalAntrian,
  checkIn,
  jadwalOperasi,
  jadwalOperasiPasien,
  daftarBaru,
} = require("../../controllers/api/BPJS/Antrian/wsrsController");
const authMid = require("../../controllers/api/BPJS/Auth/authMid");
const {
  validDaftarBaruWSRS,
} = require("../../controllers/api/BPJS/Validators/wsrsValidator");
const {
  validDaftarBaruWSBPJS,
} = require("../../controllers/api/BPJS/Validators/wsBPJSValidator");
const {
  validUpdateJadwal,
} = require("../../controllers/api/BPJS/Validators/wsBPJSValidator");
const {
  pesertaBy,
} = require("../../controllers/api/BPJS/Antrian/wsBPJSPeserta");
const { createSep } = require("../../controllers/api/BPJS/Antrian/wsBPJSSep");

const {
  rujukanbynoka,
} = require("../../controllers/api/BPJS/Antrian/wsBPJSRujukan");
const {
  historysep,
  createKontrol,
} = require("../../controllers/api/BPJS/Antrian/wsBPJSMonitoring");

const router = express.Router();
//WS BPJS
router.get("/referensi/pesertabynoka", pesertaBy);
//cara oanggil
//http://localhost:4001/api/bpjs/pesertaby?noka=0001425727146&tglsep=2022-04-15
router.get("/pesertaby", pesertaBy);
router.get("/createsep", createSep);
router.get("/historysep", historysep);
router.get("/rujukanbynoka", rujukanbynoka);
router.get("/create-kontrol", createKontrol);

//WS BPJS
router.get("/referensi/poli", authMid, refPoli);
router.get("/referensi/dokter", authMid, refDokter);
router.get(
  "/referensi/jadwaldokter/kodepoli/:kd_poli/tanggal/:tgl",
  authMid,
  refJadwalDokter
);
router.post(
  "/jadwaldokter/update",
  validUpdateJadwal,
  authMid,
  updateJadwalDokter
);
router.post(
  "/antrian/daftar-bpjs",
  validDaftarBaruWSBPJS,
  authMid,
  daftarBaruBPJS
);
router.post("/antrian/update-waktu", updateWaktuAntri);
router.post("/antrian/batal-bpjs", authMid, batalBPJS);
router.post("/antrian/list-task", authMid, ambilListTask);
router.get("/dashboard/tanggal", authMid, dashboardTgl);
router.get("/dashboard/bulan", authMid, dashboardBln);
router.get("/antrian/per-tgl", antreanPerTgl);

//WS RS
router.get("/auth/token", getToken);

router.post("/antrian/status", authMid, statusAntrian);
router.post("/antrian/ambil", authMid, ambilAntrian);
router.post("/antrian/sisa", authMid, sisaAntrian);
router.post("/antrian/batal", authMid, batalAntrian);
router.post("/antrian/check-in", authMid, checkIn);
router.post("/antrian/daftar-baru", authMid, validDaftarBaruWSRS, daftarBaru);

router.post("/operasi/jadwal", authMid, jadwalOperasi);
router.post("/operasi/jadwal-pasien", authMid, jadwalOperasiPasien);

router.post("/antrian/bulk-update", bulkUpdateAntrian);

module.exports = router;
