var DataTypes = require("sequelize").DataTypes;

function initModels(sequelize) {


  return {
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
