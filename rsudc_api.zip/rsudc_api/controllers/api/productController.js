var models = require("../../models");
const { QueryTypes, Op } = require("sequelize");
const { error, success } = require("../../helpers/utility/response");

exports.paketMCU = (req, res) => {
  const { mcu_id, mcu_name } = req.query;

  let config = {
    include: [
      {
        model: models.ref_produk_paket_mcu,
        required: true,
        as: "produk_paket",
        include: {
          where: {
            ref_prod_id_grup: 3,
          },
          model: models.ref_produk,
          required: true,
          attributes: ["ref_prod_id", "ref_prod_nama", "ref_prod_hargajual"],
          as: "produk",
        },
      },
      {
        model: models.ref_produk,
        required: true,
        attributes: ["ref_prod_id", "ref_prod_nama", "tgl_update"],
        as: "produk",
      },
    ],
  };

  if (mcu_id) {
    config = {
      ...config,
      where: {
        ref_pkt_mcu_id: mcu_id,
      },
    };
  } else if (mcu_name) {
    config = {
      include: [
        {
          model: models.ref_produk_paket_mcu,
          required: true,
          as: "produk_paket",
          include: {
            where: {
              ref_prod_id_grup: 3,
            },
            model: models.ref_produk,
            required: true,
            attributes: ["ref_prod_id", "ref_prod_nama", "ref_prod_hargajual"],
            as: "produk",
          },
        },
        {
          model: models.ref_produk,
          required: true,
          attributes: ["ref_prod_id", "ref_prod_nama", "tgl_update"],
          as: "produk",
          where: {
            ref_prod_nama: {
              [Op.iLike]: `%${mcu_name}%`,
            },
          },
        },
      ],
    };
  }

  return models.ref_paket_mcu_new
    .findAll(config)
    .then((payload) => {
      return success(req, res, payload, "Paket MCU Termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal memuat", 500, err);
    });
};
