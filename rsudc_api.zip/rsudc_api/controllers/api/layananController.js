const models = require("../../models");
const { QueryTypes, Op } = require("sequelize");
const { parseJadwal } = require("../../helpers/parser/doctorParser");
const { success, error } = require("../../helpers/utility/response");
const base64ToFile = require("../../helpers/utility/base64ToFile");
const {
  pagination,
  getHari,
  getDiffDate,
  phoneParser,
  sisaKuota,
  removeVocal,
  isSiang,
} = require("../../helpers/utility/common");
const moment = require("moment");
const {
  getVisitTime,
  quotaDokter,
  kuotaBerjalanDokter,
  quotaDokterHFIS,
} = require("./BPJS/Antrian/wsrsController");
const { sequelize } = require("../../models");
const axiosBPJS = require("./BPJS/Helpers/axios");
const axiosInstance = require("axios");
const { funcAddEncounter } = require("./IHS/encounterController");
const { sendWA } = require("./authController");
const axios = axiosInstance.create();
axios.defaults.timeout = 1000 * 30;

exports.daftarOnline = (req, res) => {
  // let { image, filename } = req.body;

  let {
    jenisId,
    jenisIdnomor,
    namaLengkap,
    namaPanggilan,
    tempatLahir,
    tglLahir,
    jenisKelamin,
    alamat,
    rt,
    rw,
    kelurahan,
    kecamatan,
    kotaDati,
    kodePos,
    propinsi,
    noTelpon,
    agama,
    nilaiYakin,
    textNilaiYakin,
    statusNikah,
    statusWarganegara,
    infoIbu,
    infoAyah,
    infoIstriSuami,
    noPenjamin,
    namaWaliDarurat,
    telponWaliDarurat,
    fileUpload,
    filePhoto,
    noTelpon2,
    alamatDomisili,
    statusPendidikan,
    penjamin,
    bahasa,
    infoKerja,
    infoKerjaLainnya,
    penjaminSubjenis,
    produkId,
    tglKunjungan,
    suku,
  } = req.body;

  // let payload = {
  //   regpsonline_id_jns_id: jenisId || null,
  //   regpsonline_id_jns_id_nomor: jenisIdnomor || null,
  //   regpsonline_namalengkap: namaLengkap || null,
  //   regpsonline_namapanggilan: namaPanggilan || null,
  //   regpsonline_tmptlahir: tempatLahir || null,
  //   regpsonline_tgllahir: tglLahir || null,
  //   regpsonline_jnskelamin: jenisKelamin || null,
  //   regpsonline_alamat: alamat || null,
  //   regpsonline_rtrw: rt + "/" + rw || null,
  //   regpsonline_kelurahan: kelurahan || null,
  //   regpsonline_kecamatan: kecamatan || null,
  //   regpsonline_kotadati: kotaDati || null,
  //   regpsonline_kdpos: kodePos || null,
  //   regpsonline_propinsi: propinsi || null,
  //   regpsonline_notelpon: noTelpon || null,
  //   regpsonline_agama: agama || null,
  //   regpsonline_nilaiyakin: nilaiYakin || null,
  //   regpsonline_textnilaiyakin: textNilaiYakin || null,
  //   regpsonline_stsnikah: statusNikah || null,
  //   regpsonline_stswarganegara: statusWarganegara || null,
  //   regpsonline_infoibu: infoIbu || null,
  //   regpsonline_infoayah: infoAyah || null,
  //   regpsonline_infoistrisuami: infoIstriSuami || null,
  //   regpsonline_nopenjamin: penjamin || null,
  //   regpsonline_nmwalidarurat: namaWaliDarurat || null,
  //   regpsonline_telponwalidarurat: telponWaliDarurat || null,
  //   regpsonline_fileupload: req.fileName || null,
  //   regpsonline_filephoto: req.fileName || null,
  //   regpsonline_flig_flag: true || null,
  //   regpasienonline_notelpon2: noTelpon2 || null,
  //   regpsonline_alamat_domisili: alamatDomisili || null,
  //   regpsonline_stspendidikan: statusPendidikan || null,
  //   regpsonline_penjamin: penjamin || null,
  //   regpsonline_bahasa: bahasa || null,
  //   regpsonline_infokerja: infoKerja || null,
  //   // regpsonline_penjamin_subjenis: 0,
  //   // regpsonline_id_pasien_ps_id: null,
  // };
  // return models.pasienonline
  //   .findOne({
  //     where: {
  //       regpsonline_id_jns_id_nomor: jenisIdnomor,
  //     },
  //   })
  //   .then((exist) => {
  //     if (!exist) {
  //       throw new Error(
  //         "Pasien sudah terdaftar, silahkan datang ke RSUD Cengkareng"
  //       );
  //     }
  //   })
  //   .then(() => {
  alamat = alamat ? alamat.toUpperCase() : "";
  rt = rt ? rt.toUpperCase() : "";
  rw = rw ? rw.toUpperCase() : "";
  kelurahan = kelurahan ? kelurahan.toUpperCase() : "";
  kecamatan = kecamatan ? kecamatan.toUpperCase() : "";
  kotaDati = kotaDati ? kotaDati.toUpperCase() : "";
  propinsi = propinsi ? propinsi.toUpperCase() : "";
  kodePos = kodePos ? kodePos.toUpperCase() : "";

  namaLengkap = namaLengkap ? namaLengkap.toUpperCase() : "";
  namaPanggilan = namaPanggilan ? namaPanggilan.toUpperCase() : "";
  tempatLahir = tempatLahir ? tempatLahir.toUpperCase() : "";
  infoAyah = infoAyah ? infoAyah.toUpperCase() : "";
  infoIstriSuami = infoIstriSuami ? infoIstriSuami.toUpperCase() : "";
  namaWaliDarurat = namaWaliDarurat ? namaWaliDarurat.toUpperCase() : "";
  alamatDomisili = alamatDomisili ? alamatDomisili.toUpperCase() : "";
  bahasa = bahasa ? bahasa.toUpperCase() : "";

  return models.pasienonline
    .create({
      regpsonline_id_jns_id: jenisId || null,
      regpsonline_id_jns_id_nomor: jenisIdnomor || null,
      regpsonline_namalengkap: namaLengkap || null,
      regpsonline_namapanggilan: namaPanggilan || "-",
      regpsonline_tmptlahir: tempatLahir || null,
      regpsonline_tgllahir: tglLahir || null,
      regpsonline_jnskelamin: jenisKelamin || null,
      regpsonline_alamat:
        `${alamat} ${rt}/${rw} ${kelurahan} ${kecamatan} ${kotaDati} ${propinsi} ${kodePos}` ||
        null,
      regpsonline_rtrw: rt + "/" + rw || null,
      regpsonline_kelurahan: kelurahan || null,
      regpsonline_kecamatan: kecamatan || null,
      regpsonline_kotadati: kotaDati || null,
      regpsonline_kdpos: kodePos || null,
      regpsonline_propinsi: propinsi || null,
      regpsonline_notelpon: noTelpon || null,
      regpsonline_agama: agama || null,
      regpsonline_nilaiyakin: nilaiYakin || null,
      regpsonline_textnilaiyakin: textNilaiYakin || null,
      regpsonline_stsnikah: statusNikah || null,
      regpsonline_stswarganegara: statusWarganegara || null,
      regpsonline_infoibu: infoIbu || "-",
      regpsonline_infoayah: infoAyah || "-",
      regpsonline_infoistrisuami: infoIstriSuami || "-",
      regpsonline_nopenjamin: noPenjamin || null,
      regpsonline_nmwalidarurat: namaWaliDarurat || "-",
      regpsonline_telponwalidarurat: telponWaliDarurat || "-",
      regpsonline_fileupload: req.fileName || "-",
      regpsonline_filephoto: req.fileName || "-",
      regpsonline_flig_flag: false,
      regpasienonline_notelpon2: noTelpon2 || null,
      regpsonline_alamat_domisili: alamatDomisili || null,
      regpsonline_stspendidikan: statusPendidikan || null,
      regpsonline_penjamin: penjamin || null,
      regpsonline_bahasa: bahasa || null,
      regpsonline_infokerja: infoKerja || null,
      regpsonline_infokerja_lainnya: infoKerjaLainnya || null,
      regpsonline_produk_id: produkId || null,
      regpsonline_tgl_berkunjung: tglKunjungan || null,
      regpsonline_tribe: suku || null,

      // regpsonline_penjamin_subjenis: 0,
      // regpsonline_id_pasien_ps_id: null,
      // });
    })
    .then((pasien) => {
      if (pasien) {
        return success(req, res, pasien, "Pasien berhasil terdaftar.");
      }
      return error(req, res, {}, "Gagal mendaftar", 400);
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal mendaftar", 500, err);
    });
};
// regpsonline_id_reg: 2,
exports.inapPulang = (req, res) => {
  const { no_mr, page, png_id, start_date, end_date, ps_nama, is_pulang } =
    req.query;
  const { limit, offset } = pagination(page > 0 ? page : 1);
  const query = `select
	id_rkun as rkun_id
	,inap_waktu_awal::date as tgl
	,waktu_keluar::date
	,rkun_png_noncash
	,png_nama
	,inap_id
	,ps_mrn
	,ps_namalengkap
	,ref_ruang_nama
	,ref_kls_inap_nama
  ,case when bayar > 0 then 'Sudah Pulang' else 'Masih Dirawat' end as status
from 
    (select
        distinct rkun_id as id_rkun
        ,rkun_png_noncash
		,png_nama
        ,kun_id as id_kun
		,kun_id_pasien as id_ps
        ,(select inap_waktu_keluar from inap where inap_id_kunjungan = kun_id order by inap_waktu_keluar desc limit 1) as waktu_keluar
        ,(select inap_waktu from inap where inap_id_kunjungan = kun_id order by inap_id asc limit 1) as inap_waktu_awal
		,(select inap_id from inap where inap_id_kunjungan = kun_id order by inap_id asc limit 1) as inap_id_masuk
		,(select count(*) as jml from pembayaran_kasir where id_rkun = rkun_id and jenis_pembayaran in (1,4)) as bayar
    from
        rencana_kunjungan
			left join asp_penanggung on png_id = rkun_png_noncash
        ,kunjungan
        ,inap
    where
        rkun_id = kun_id_rencana_kunjungan
        and kun_id = inap_id_kunjungan
		and kun_inap is true
        and rkun_id_layanan <> 39
        and rkun_id_pasien > 0
		and kun_tgl >= :start_date :: date
		and kun_tgl <= :end_date ::date 
    ) as data
        left join inap on inap_id = inap_id_masuk
		left join v_tempat_tidur_5 on ref_tmpt_tdr_id = inap_tempat_tidur
		left join v_pasien_3 on ps_id = id_ps
where
    inap_id > 0
    ${no_mr ? "and ps_mrn = :no_mr" : "--"}
    ${png_id ? "and rkun_png_noncash = :png_id" : "--"}
    ${ps_nama ? "and ps_namalengkap ilike :ps_nama" : "--"}  
    ${is_pulang === "true" ? "and bayar > 0" : "and bayar <= 0"}
order by
	tgl desc
  limit :limit offset :offset`;

  const qCount = `select
	count(*)
from 
    (select
        distinct rkun_id as id_rkun
        ,rkun_png_noncash
		,png_nama
        ,kun_id as id_kun
		,kun_id_pasien as id_ps
        ,(select inap_waktu from inap where inap_id_kunjungan = kun_id order by inap_id asc limit 1) as inap_waktu_awal
		,(select inap_id from inap where inap_id_kunjungan = kun_id order by inap_id asc limit 1) as inap_id_masuk
		,(select count(*) as jml from pembayaran_kasir where id_rkun = rkun_id and jenis_pembayaran in (1,4)) as bayar
    from
        rencana_kunjungan
			left join asp_penanggung on png_id = rkun_png_noncash
        ,kunjungan
        ,inap
    where
        rkun_id = kun_id_rencana_kunjungan
        and kun_id = inap_id_kunjungan
		and kun_inap is true
        and rkun_id_layanan <> 39
        and rkun_id_pasien > 0
		and kun_tgl >= :start_date :: date
		and kun_tgl <= :end_date ::date 
    ) as data
        left join inap on inap_id = inap_id_masuk
		left join v_tempat_tidur_5 on ref_tmpt_tdr_id = inap_tempat_tidur
		left join v_pasien_3 on ps_id = id_ps
where
    inap_id > 0
    ${no_mr ? "and ps_mrn = :no_mr" : "--"}
    ${png_id ? "and rkun_png_noncash = :png_id" : "--"}
    ${ps_nama ? "and ps_namalengkap ilike :ps_nama" : "--"}  
    ${is_pulang === "true" ? "and bayar > 0" : "and bayar <= 0"}
  `;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        no_mr: no_mr,
        png_id: png_id,
        limit: limit,
        offset: offset,
        ps_nama: ps_nama ? `%${ps_nama}%` : "",
        start_date: start_date || moment().format("YYYY-MM-DD"),
        end_date: end_date || moment().format("YYYY-MM-DD"),
      },
    })
    .then((payload) => {
      return models.sequelize
        .query(qCount, {
          type: QueryTypes.SELECT,
          replacements: {
            no_mr: no_mr,
            png_id: png_id,
            ps_nama: ps_nama ? `%${ps_nama}%` : "",
            start_date: start_date || moment().format("YYYY-MM-DD"),
            end_date: end_date || moment().format("YYYY-MM-DD"),
          },
        })
        .then((count) => {
          let data = {
            data: payload,
            total_row: count[0] ? count[0].count : 0,
          };
          return success(req, res, data, "Pasien Rawat Inap Pulang Termuat.");
        });
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal memuat", 500, err);
    });
};
const cekKunjungan = (no_rujukan, kd_poli, kd_poli_rujukan) => {
  // K = KONTROL ,B= FAKSES 2,Y=FAKES 1
  // "jeniskunjungan": {1 (Rujukan FKTP), 2 (Rujukan Internal), 3 (Kontrol), 4 (Rujukan Antar RS)},
  let regExFK1 = /Y/g;
  let regExFK2 = /B/g;
  let result = 1;
  if (!no_rujukan) {
    return 1;
  }
  if (
    kd_poli_rujukan &&
    kd_poli &&
    kd_poli_rujukan.toUpperCase() !== kd_poli.toUpperCase()
  ) {
    result = 2;
  } else if (regExFK1.test(no_rujukan)) {
    result = 1;
  } else if (regExFK2.test(no_rujukan)) {
    result = 4;
  }
  return result;
};

exports.ambilAntrianByPass = (req, res) => {
  let {
    id_layanan,
    tanggal,
    doctor_id,
    is_bpjs,
    no_rujukan,
    // jenis_kunjungan,
    no_kartu,
    nik,
    waktu,
    penanggung_id,
    kd_poli,
    kd_poli_rujukan,
    mr,
    no_telp,
  } = req.body;

  if (!id_layanan || !tanggal || !doctor_id || !mr) {
    return error(req, res, {}, "Invalid Parameters", 400, null);
  }
  if (doctor_id !== "100080" && !kd_poli) {
    return error(req, res, {}, "Pilih Poli", 400, null);
  }
  const isDateValid = moment(tanggal, "YYYY-MM-DD", true).isValid();
  if (!isDateValid) {
    return error(req, res, {}, "Date Format : YYYY-MM-DD", 400, null);
  }
  if (doctor_id == "100080" && getDiffDate(tanggal) >= 0) {
    return error(req, res, {}, "Hanya Untuk Hari Mendatang", 400, null);
  }
  let jenis_kunjungan = cekKunjungan(no_rujukan, kd_poli, kd_poli_rujukan);
  let nama_dokter = "";
  let nama_layanan = "";
  let nama_pasien = "";
  let hariPeriksa = "";
  let is_lansia = false;
  let no_mr = "";
  no_kartu = no_kartu;
  nik = nik;
  let jenis_id = "";
  let no_hp = "";
  let kdpoli = "";
  let kd_dokter = "";
  let no_kontrol = "";
  let quota_dokter = "";
  let quota_berjalan_dokter = 0;
  let quota_berjalan_dokter_bpjs = 0;
  let quota = null;
  return models.kalender_libur
    .findOne({
      where: {
        kal_libur_tgl: tanggal,
      },
    })
    .then((libur) => {
      hariPeriksa = getHari(moment(tanggal, "YYYY-MM-DD").format("dddd"));
      if (libur || hariPeriksa === "Minggu") {
        throw new Error("Poli Tutup");
      }
    })
    .then(() => {
      return models.pasien.findOne({
        where: {
          ps_mrn: {
            [Op.eq]: sequelize.literal(`mrn_decoded('${mr}')`),
          },
        },
      });
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien tidak ditemukan");
      }
      no_mr = pasien.ps_mrn;
      nama_pasien = pasien.ps_namalengkap;
      return models.asp_pasien
        .findOne({
          where: {
            ps_id: pasien.ps_id,
          },
          attributes: [
            [sequelize.literal("is_lansia(ps_tgllahir)"), "lansia"],
            "ps_id",
            "ps_no_jmn_non_cash",
            "ps_telpon",
            "ps_jenis_nomor_identitas",
            "ps_nomor_identitas",
          ],
        })
        .then((asp_pasien) => {
          return asp_pasien.dataValues;
        });
    })
    .then((pasien) => {
      return models.dokter_bpjs
        .findOne({
          where: {
            dr_bpjs_id_peg: doctor_id,
          },
        })
        .then((dokter) => {
          if (doctor_id == "100080") {
            nama_dokter = "DOKTER RSUDC";
            kd_dokter = 0;
          } else if (!dokter) {
            throw new Error("Dokter tidak ditemukan");
          } else {
            nama_dokter = dokter.dr_bpjs_nama;
            kd_dokter = dokter.dr_bpjs_kode;
          }
          return pasien;
        });
    })
    .then((pasien) => {
      return models.refpoli_bpjs
        .findOne({
          where: {
            kd_layananpoli_rsc: id_layanan,
          },
        })
        .then((layanan) => {
          if (doctor_id == "100080") {
            if (Number(id_layanan) === 51) {
              nama_layanan = "Rehab Medik Fisiotherapy";
            } else {
              nama_layanan = "MCU";
            }
            kdpoli = "";
          } else if (!layanan) {
            throw new Error("Poli tidak ditemukan");
          } else {
            nama_layanan = layanan.nmpoli;
            kdpoli = kd_poli ? kd_poli : layanan.kdpoli;
          }
          return pasien;
        });
    })
    .then((pasien) => {
      return models.rencana_kunjungan
        .findOne({
          where: {
            rkun_reservasi: true,
            rkun_batal: {
              [Op.or]: [false, null],
            },
            rkun_id_pasien: pasien.ps_id,
            rkun_tgl_visit: tanggal,
          },
          order: [["rkun_tgl_visit", "DESC"]],
        })
        .then((kunjungan) => {
          if (kunjungan) {
            throw new Error(
              "Nomor antrian hanya dapat diambil 1 kali pada tanggal yang sama"
            );
          }
          return pasien;
        });
    })
    .then((pasien) => {
      if (doctor_id !== "100080") {
        return quotaDokterHFIS(
          kdpoli,
          tanggal,
          kd_dokter,
          waktu,
          doctor_id,
          id_layanan
        ).then((c) => {
          if (is_bpjs) {
            if (c.sisa_bpjs === 0) {
              throw new Error("Quota Full");
            }
          } else if (c.sisa_umum === 0) {
            throw new Error("Quota Full");
          }
          quota = c;
          return pasien;
        });
      }
      quota = 0;
      return pasien;
    })
    .then((payload) => {
      if (kd_poli === kd_poli_rujukan) {
        return axios
          .get(
            `http://192.168.200.103:5001/api/bpjs/historysep?noka=${no_kartu}&tgl1=${tanggal}`
          )
          .then((sep) => {
            if (sep.data.metaData && sep.data.metaData.code === 200) {
              const rujukan_found = sep.data.response.find(
                (e) => e.noRujukan === no_rujukan && e.poli === nama_layanan
              );
              if (rujukan_found) {
                return axios
                  .get(
                    `http://192.168.200.8:8080/RsudcApi/insertrencanakontrol?nosep=${rujukan_found.noSep}&kodedokter=${kd_dokter}&polikontrol=${kd_poli}&tglrencanakontrol=${tanggal}&user=rsudc_mobile`
                  )
                  .then((kontrol) => {
                    if (
                      kontrol.data.metaData &&
                      kontrol.data.metaData.code === 200
                    ) {
                      jenis_kunjungan = 3;
                      return {
                        ...payload,
                        no_kontrol: kontrol.data.response.noSuratKontrol,
                      };
                    } else if (kontrol.data.metaData) {
                      throw new Error(
                        `${kontrol.data.metaData.message}, Mohon coba lagi atau lakukan pendaftaran offline pada hari H oleh Admin`
                      );
                    }
                  });
              }
              return payload;
            }
            if (sep.data.metaData) {
              throw new Error(
                `${sep.data.metaData.message}, Mohon coba lagi atau lakukan pendaftaran offline pada hari H oleh Admin`
              );
            }
            throw new Error(
              "Gagal Membuat Surat Kontrol, Mohon coba lagi atau lakukan pendaftaran offline pada hari H oleh Admin"
            );
          });
      }
      return payload;
    })
    .then((pasien) => {
      is_lansia = pasien.lansia;
      no_kartu = no_kartu || pasien.ps_no_jmn_non_cash;
      nik = nik || pasien.ps_nomor_identitas;
      jenis_id = nik ? 1 : pasien.ps_jenis_nomor_identitas;
      no_hp = no_telp;
      no_kontrol = pasien.no_kontrol;
      const query =
        "select fnoantri(:idLayanan,:date,1,:psID, :doctorId) as data";
      return models.sequelize
        .query(query, {
          type: QueryTypes.SELECT,
          replacements: {
            idLayanan: id_layanan,
            date: tanggal,
            psID: pasien.ps_id,
            doctorId: doctor_id,
          },
        })
        .then((payload) => {
          if (payload.length === 0) {
            throw new Error("Gagal Mendaftar");
          }
          return payload[0];
        });
    })
    .then((payload) => {
      let resultTwo = payload.data.split("_");
      return models.rencana_kunjungan
        .update(
          {
            rkun_png_noncash: penanggung_id ? penanggung_id : null,
            is_lansia: is_lansia,
            is_bpjs: is_bpjs,
          },
          {
            where: {
              rkun_id: resultTwo[1],
            },
          }
        )
        .then(() => {
          return payload;
        });
    })
    .then((payload) => {
      let resultTwo = payload.data.split("_");
      let rkunId = null;
      let rkunNo = null;
      rkunId = resultTwo[1];
      rkunNo = resultTwo[2];
      return getVisitTime(rkunNo, id_layanan, hariPeriksa).then((waktu) => {
        return {
          no_mr: no_mr,
          no_antri: rkunNo,
          no_kartu: no_kartu,
          nik: nik,
          no_hp: no_hp,
          kdpoli: kdpoli,
          jenis_id: jenis_id,
          rkun_id: rkunId,
          nama_layanan: nama_layanan,
          nama_pasien: nama_pasien,
          nama_dokter: nama_dokter,
          kd_dokter: kd_dokter,
          is_lansia: is_lansia,
          is_bpjs: is_bpjs,
          estimasi: waktu.one
            ? `Pkl ${waktu.one} s/d ${waktu.two} WIB`
            : `Pkl 07:00 s/d 12:00 WIB`,
          pesanfoot2: waktu.one
            ? `Pkl ${waktu.one} s/d ${waktu.two} WIB`
            : JSON.stringify(waktu),
        };
      });
    })
    .then((payload) => {
      return models.jml_nelp
        .create({
          nmpasien: payload.nama_pasien,
          no_telp: no_telp,
          mrn: payload.no_mr,
          proses: true,
          id_jns_app_layanan: 3,
          status_id: 1,
          rkunid: payload.rkun_id,
          is_lansia: payload.is_lansia,
          poli: nama_layanan,
          nm_dokter: nama_dokter,
          is_bpjs: payload.is_bpjs,
          pesanfoot1: payload.estimasi,
          pesanfoot2: payload.pesanfoot2,
          tglkunjung: tanggal,
          reg: "REG",
          noantri: payload.no_antri,
          no_rujukan: no_rujukan,
          jeniskunjungan: jenis_kunjungan || 1,
          kdpoli_bpjs: kd_poli || null,
          no_surat_kontrol: no_kontrol || null,
          nobpjs: no_kartu || null,
        })
        .then(() => {
          return payload;
        });
    })
    .then((payload) => {
      if (doctor_id != "100080") {
        let localWaktu = waktu || "08:00-14:00";
        let parseWaktu = localWaktu.split("-")[0];
        return axiosBPJS
          .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/add`, {
            kodebooking: `${payload.rkun_id}`,
            jenispasien: is_bpjs ? "JKN" : "NON JKN",
            nomorkartu: payload.no_kartu,
            nik: payload.jenis_id == 1 ? payload.nik : "",
            nohp: phoneParser(payload.no_hp),
            kodepoli: payload.kdpoli,
            namapoli: payload.nama_layanan,
            pasienbaru: 0,
            norm: payload.no_mr,
            tanggalperiksa: tanggal,
            kodedokter: `${payload.kd_dokter}`,
            namadokter: `${payload.nama_dokter}`,
            jampraktek: localWaktu,
            jeniskunjungan: jenis_kunjungan || 1,
            nomorreferensi: `${no_rujukan}`,
            nomorantrean: `${payload.no_antri}`,
            angkaantrean: payload.no_antri,
            estimasidilayani: Number(
              moment(`${tanggal} ${parseWaktu}`, "YYYY-MM-DD hh:mm")
                .add(payload.no_antri * 6, "minutes")
                .format("x")
            ),
            sisakuotajkn: is_bpjs ? quota.sisa_bpjs - 1 : quota.sisa_bpjs,
            kuotajkn: quota.quota_bpjs,
            sisakuotanonjkn: !is_bpjs ? quota.sisa_umum - 1 : quota.sisa_umum,
            kuotanonjkn: quota.quota_umum,
            keterangan:
              "Peserta harap 30 menit lebih awal guna pencatatan administrasi.",
          })
          .then((bpjs) => {
            if (!bpjs.metadata || bpjs.metadata.code !== 200) {
              return models.jml_nelp.update(
                {
                  task_id: 0,
                  error_jkn: bpjs.metadata
                    ? bpjs.metadata.message
                    : "Gagal Insert JKN",
                },
                {
                  where: {
                    rkunid: payload.rkun_id,
                  },
                }
              );
            } else {
              if (getDiffDate(tanggal) === 0) {
                return axiosBPJS
                  .post(
                    `/${process.env.BPJS_ANTRIAN_URL}/antrean/updatewaktu`,
                    {
                      kodebooking: `${payload.rkun_id}`,
                      taskid: 3,
                      waktu: moment.utc().format("x"),
                    }
                  )
                  .then(() => {
                    return models.jml_nelp
                      .update(
                        {
                          task_id: 3,
                          error_jkn: null,
                        },
                        {
                          where: {
                            rkunid: payload.rkun_id,
                          },
                        }
                      )
                      .then(() => {
                        return payload;
                      });
                  })
                  .catch((err) => {
                    return models.jml_nelp
                      .update(
                        {
                          error_jkn: `Gagal Update Task ID : 3`,
                        },
                        {
                          where: {
                            rkunid: payload.rkun_id,
                          },
                        }
                      )
                      .then(() => {
                        return payload;
                      });
                  });
              } else {
                return payload;
              }
            }
          })
          .catch((err) => {
            return models.jml_nelp
              .update(
                {
                  error_jkn: `Gagal Insert JKN`,
                },
                {
                  where: {
                    rkunid: payload.rkun_id,
                  },
                }
              )
              .then(() => {
                return payload;
              });
          });
      } else {
        return payload;
      }
    })
    .then((payload) => {
      return success(
        req,
        res,
        {
          no_mr: payload.no_mr,
          no_antri: payload.no_antri,
          rkun_id: payload.rkun_id,
          nama_layanan: payload.nama_layanan,
          nama_dokter: payload.nama_dokter,
          estimasi: payload.estimasi,
          is_lansia: payload.is_lansia,
          is_bpjs: payload.is_bpjs,
          is_lansia: payload.is_lansia,
        },
        "Berhasil Mendaftar."
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal mendaftar", 500, err);
    });
};

exports.ambilAntrian = (req, res) => {
  let {
    id_layanan,
    tanggal,
    doctor_id,
    is_bpjs,
    no_rujukan,
    // jenis_kunjungan,
    no_kartu,
    nik,
    waktu,
    penanggung_id,
    kd_poli,
    kd_poli_rujukan,
  } = req.body;
  const { mr, no_telp } = req.user;
  if (!id_layanan || !tanggal || !doctor_id || !mr) {
    return error(req, res, {}, "Invalid Parameters", 400, null);
  }
  if (doctor_id !== "100080" && !kd_poli) {
    return error(req, res, {}, "Pilih Poli", 400, null);
  }
  const isDateValid = moment(tanggal, "YYYY-MM-DD", true).isValid();
  if (!isDateValid) {
    return error(req, res, {}, "Date Format : YYYY-MM-DD", 400, null);
  }
  // if (getDiffDate(tanggal) >= 0) {
  //   return error(req, res, {}, "Hanya Untuk Hari Mendatang", 400, null);
  // }
  return this.createAntrian({
    mr: mr,
    id_layanan: id_layanan,
    tanggal: tanggal,
    doctor_id: doctor_id,
    is_bpjs: no_kartu ? true : false,
    no_rujukan: no_rujukan,
    // jenis_kunjungan,
    no_kartu: no_kartu,
    nik: nik,
    waktu: waktu,
    penanggung_id: penanggung_id,
    kd_poli: kd_poli,
    kd_poli_rujukan: kd_poli_rujukan,
    no_telp,
  })
    .then((payload) => {
      return success(
        req,
        res,
        {
          no_mr: payload.no_mr,
          no_antri: payload.no_antri,
          rkun_id: payload.rkun_id,
          nama_layanan: payload.nama_layanan,
          nama_dokter: payload.nama_dokter,
          estimasi: payload.estimasi,
          is_lansia: payload.is_lansia,
          is_bpjs: payload.is_bpjs,
          is_lansia: payload.is_lansia,
        },
        "Berhasil Mendaftar."
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal mendaftar", 500, err);
    });
};

exports.funCariRujukan = (noka, active = false) => {
  return Promise.all([
    axios.get("http://192.168.200.8:8080/RsudcApi/CariRujukanByNokaMRF1", {
      params: {
        noka: noka,
      },
    }),
    axios.get("http://192.168.200.8:8080/RsudcApi/CariRujukanByNokaMRF2", {
      params: {
        noka: noka,
      },
    }),
  ]).then((payload) => {
    let arr = [];
    let err = "";
    if (payload[0].data.metaData && payload[0].data.metaData.code === 200) {
      if (active) {
        arr.push(
          ...payload[0].data.response.rujukan.filter(
            (el) => getDiffDate(el.tglKunjungan) <= 90
          )
        );
      } else {
        arr.push(...payload[0].data.response.rujukan);
      }
    } else {
      err = payload[0].data.metaData.message;
    }
    if (payload[1].data.metaData && payload[1].data.metaData.code === 200) {
      if (active) {
        arr.push(
          ...payload[1].data.response.rujukan.filter(
            (el) => getDiffDate(el.tglKunjungan) <= 90
          )
        );
      } else {
        arr.push(...payload[1].data.response.rujukan);
      }
    } else {
      err = payload[1].data.metaData.message;
    }
    if (arr.length == 0) {
      throw new Error(
        "Rujukan tidak ditemukan, atau masa berlaku habis. Perpanjang atau reservasi Umum"
      );

      // if (err) {
      //   throw new Error(err);
      // } else {
      //   throw new Error("Rujukan tidak ditemukan, atau masa berlaku habis.");
      // }
    }
    return arr;
  });
};

exports.cariRujukan = (req, res) => {
  const { noka, jenis_kunjungan, active } = req.query;
  return (
    this.funCariRujukan(noka, active ? true : false)
      // return axios
      //   .get("http://192.168.200.8:8080/RsudcApi/CariRujukanByNokaMRF1", {
      //     params: {
      //       noka: noka,
      //     },
      //   })
      //   .then((payload) => {
      //     return axios
      //       .get("http://192.168.200.8:8080/RsudcApi/CariRujukanByNokaMRF2", {
      //         params: {
      //           noka: noka,
      //         },
      //       })
      //       .then((mrf2) => {
      //         if (payload.data.metaData && payload.data.metaData.code === 200) {
      //           if (mrf2.data.metaData && mrf2.data.metaData.code === 200) {
      //             payload.data.response.rujukan.push(...mrf2.data.response.rujukan);
      //           }
      //           return payload;
      //         }
      //         return mrf2;
      //       });
      //   })
      .then((payload) => {
        return success(req, res, payload, "", 200);
      })
      .catch((err) => {
        return error(req, res, {}, "Gagal cari", 500, err);
      })
  );
};

exports.checkPBIPeserta = (no_kartu) => {
  return axios
    .get(`http://192.168.200.8:8080/RsudcApi/pesertanoka?noka=${no_kartu}`)
    .then((info_pasien) => {
      const jns_peserta =
        info_pasien.data.response.peserta.jenisPeserta.keterangan;
      return models.jnspeserta_bpjs
        .findOne({
          where: {
            ketjnspeserta: jns_peserta,
          },
        })
        .then((jns) => {
          return jns.kd_penanggung;
        });
    });
};

exports.hapusRencanaKontrolSebelumnya = (noka, cb) => {
  let i = 0;
  const cariKontrol = (tanggal, resolve, reject) => {
    const _tanggal = tanggal.split("-");
    const _date = moment(tanggal, "YYYY-MM-DD")
      .subtract(1, "month")
      .format("YYYY-MM-DD");

    if (i == 3) {
      return reject(
        "Jadwal kontrol sudah pernah dibuat, mohon batalkan janji sebelumnya."
      );
    }
    return axios
      .get(
        `http://192.168.200.8:8080/RsudcApi/carinomorkontrolbynoka?noka=${noka}&thn=${_tanggal[0]}&bln=${_tanggal[1]}&filter=1`
      )
      .then((carinomor) => {
        if (carinomor.data.metaData && carinomor.data.metaData.code !== 200) {
          i++;
          return cariKontrol(_date, resolve, reject);
        }
        let data = carinomor.data.response.list;
        const find_belum_terbit = data.find(
          (el) =>
            el.terbitSEP == "Belum" && getDiffDate(el.tglRencanaKontrol) > 0
        );
        if (!find_belum_terbit) {
          i++;
          return cariKontrol(tanggal, resolve, reject);
        }
        return axios
          .get(
            `http://192.168.200.8:8080/RsudcApi/hapusrencanakontrol?nosuratkontrol=${find_belum_terbit.noSuratKontrol}&user=rsudc_mobile`
          )
          .then((kontrol) => {
            if (kontrol.data.metaData && kontrol.data.metaData.code !== 200) {
              return reject(kontrol.data.metaData.message);
            }
            resolve(cb());
          });
      });
  };
  const tgl = moment().format("YYYY-MM-DD");

  const myPromise = new Promise((resolve, reject) => {
    return cariKontrol(tgl, resolve, reject);

    // if (Math.random() > 0) {
    //   resolve("Hello, I am positive number!");
    // }
    // reject(new Error("I failed some times"));
  });
  return myPromise;
};

exports.createAntrian = ({
  mr,
  id_layanan,
  tanggal,
  doctor_id,
  is_bpjs,
  no_rujukan,
  // jenis_kunjungan,
  no_kartu,
  nik,
  waktu,
  penanggung_id,
  kd_poli,
  kd_poli_rujukan,
  no_telp = "",
  jenis_reservasi = 2,
}) => {
  console.log("lololol " + kd_poli);
  let jenis_kunjungan = cekKunjungan(no_rujukan, kd_poli, kd_poli_rujukan);
  let nama_dokter = "";
  let nama_layanan = "";
  let nama_pasien = "";
  let hariPeriksa = "";
  let is_lansia = false;
  let no_mr = "";
  no_kartu = no_kartu;
  nik = nik;
  let jenis_id = "";
  let no_hp = "";
  let kdpoli = "";
  let kd_dokter = "";
  let no_kontrol = "";
  let quota_dokter = "";
  let quota_berjalan_dokter = 0;
  let quota_berjalan_dokter_bpjs = 0;
  let quota = null;
  return models.kalender_libur
    .findOne({
      where: {
        kal_libur_tgl: tanggal,
      },
    })
    .then((libur) => {
      hariPeriksa = getHari(moment(tanggal, "YYYY-MM-DD").format("dddd"));
      if (libur || hariPeriksa === "Minggu") {
        throw new Error("Poli Tutup");
      }
    })
    .then(() => {
      return models.pasien.findOne({
        where: {
          ps_mrn: {
            [Op.eq]: sequelize.literal(`mrn_decoded('${mr}')`),
          },
        },
      });
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien tidak ditemukan");
      }
      no_mr = pasien.ps_mrn;
      nama_pasien = pasien.ps_namalengkap;
      return models.asp_pasien
        .findOne({
          where: {
            ps_id: pasien.ps_id,
          },
          attributes: [
            [sequelize.literal("is_lansia(ps_tgllahir)"), "lansia"],
            "ps_id",
            "ps_no_jmn_non_cash",
            "ps_telpon",
            "ps_jenis_nomor_identitas",
            "ps_nomor_identitas",
          ],
        })
        .then((asp_pasien) => {
          return asp_pasien.dataValues;
        });
    })
    .then((pasien) => {
      return models.dokter_bpjs
        .findOne({
          where: {
            dr_bpjs_id_peg: doctor_id,
          },
        })
        .then((dokter) => {
          if (doctor_id == "100080") {
            nama_dokter = "DOKTER RSUDC";
            kd_dokter = 0;
          } else if (!dokter) {
            throw new Error("Dokter tidak ditemukan");
          } else {
            nama_dokter = dokter.dr_bpjs_nama;
            kd_dokter = dokter.dr_bpjs_kode;
          }
          return pasien;
        });
    })
    .then((pasien) => {
      return models.refpoli_bpjs
        .findOne({
          where: {
            kd_layananpoli_rsc: id_layanan,
            kdpoli: {
              [Op.notIn]: [
                "097",
                "034",
                // "017",
                "005",
                "007",
                "UGD",
                "APT",
                "LAB",
                "IGD",
                "RAD",
                "HDL",
                "PTD",
                // "BDM",
                "GAS",
                "ESW",
                "DRH",
              ],
            },
          },
        })
        .then((layanan) => {
          if (doctor_id == "100080") {
            if (Number(id_layanan) === 51) {
              nama_layanan = "Rehab Medik Fisiotherapy";
            } else {
              nama_layanan = "MCU";
            }
            kdpoli = "";
          } else if (!layanan) {
            throw new Error("Poli tidak ditemukan");
          } else {
            nama_layanan = layanan.nmpoli;
            kdpoli = kd_poli ? kd_poli : layanan.kdpoli;
          }
          return pasien;
        });
    })
    .then((pasien) => {
      // if (!is_bpjs) {
      //   return models.rencana_kunjungan
      //     .findOne({
      //       where: {
      //         rkun_id_layanan: id_layanan,
      //         // rkun_reservasi: true,
      //         rkun_batal: {
      //           [Op.or]: [false, null],
      //         },
      //         rkun_id_pasien: pasien.ps_id,
      //         rkun_tgl_visit: tanggal,
      //       },
      //       order: [["rkun_tgl_visit", "DESC"]],
      //     })
      //     .then((kunj) => {
      //       if (!kunj) {
      //         return pasien;
      //       }
      //       throw new Error(
      //         `Anda telah terdaftar, nomor antri anda : ${kunj.rkun_nomor}`
      //       );
      //     });
      // }
      return models.rencana_kunjungan
        .findOne({
          where: {
            rkun_id_layanan: id_layanan,
            // rkun_reservasi: true,
            rkun_batal: {
              [Op.or]: [false, null],
            },
            rkun_id_pasien: pasien.ps_id,
            rkun_tgl_visit: {
              [Op.gt]: moment().format("YYYY-MM-DD"),
            },
          },
          order: [["rkun_tgl_visit", "ASC"]],
        })
        .then((kunjungan) => {
          if (kunjungan) {
            throw new Error(
              `Anda telah memiliki janji pada poli ini ${kunjungan.rkun_tgl_visit} dengan nomor antri : ${kunjungan.rkun_nomor} silahkan selesaikan/batalkan janji tersebut terlebih dahulu.`
            );
            // throw new Error(
            //   "Nomor antrian hanya dapat diambil 1 kali pada tanggal yang sama"
            // );
          }
          return pasien;
        });
    })
    .then((pasien) => {
      if (doctor_id !== "100080") {
        return quotaDokterHFIS(
          kdpoli,
          tanggal,
          kd_dokter,
          waktu,
          doctor_id,
          id_layanan
        ).then((c) => {
          if (is_bpjs) {
            if (c.sisa_bpjs <= 0) {
              throw new Error(
                `Kuota Full, sisa BPJS : ${c.sisa_bpjs} dan Umum: ${c.sisa_umum}`
              );
            }
          } else if (c.sisa_umum <= 0) {
            throw new Error(
              `Kuota Full, sisa BPJS : ${c.sisa_bpjs} dan Umum: ${c.sisa_umum}`
            );
          }
          quota = c;
          return pasien;
        });
      }
      quota = 0;
      return pasien;
    })
    .then((payload) => {
      console.log("----", kd_poli);
      console.log("----", kd_poli_rujukan);
      if (kd_poli === kd_poli_rujukan) {
        return axios
          .get(
            `http://192.168.200.103:5001/api/bpjs/historysep?noka=${no_kartu}&tgl1=${tanggal}`
          )
          .then((sep) => {
            if (sep.data.metaData && sep.data.metaData.code === 200) {
              const rujukan_found = sep.data.response.find(
                (e) => e.noRujukan === no_rujukan && e.poli === nama_layanan
              );
              if (rujukan_found) {
                return axios
                  .get(
                    `http://192.168.200.8:8080/RsudcApi/insertrencanakontrol?nosep=${rujukan_found.noSep}&kodedokter=${kd_dokter}&polikontrol=${kd_poli}&tglrencanakontrol=${tanggal}&user=rsudc_mobile`
                  )
                  .then((kontrol) => {
                    if (
                      kontrol.data.metaData &&
                      kontrol.data.metaData.code === 200
                    ) {
                      jenis_kunjungan = 3;
                      return {
                        ...payload,
                        no_kontrol: kontrol.data.response.noSuratKontrol,
                      };
                    } else if (kontrol.data.metaData) {
                      const rgx = /nomor sep sudah pernah digunakan/gi;
                      const rgxResult = rgx.test(kontrol.data.metaData.message);
                      if (rgxResult) {
                        return this.hapusRencanaKontrolSebelumnya(
                          no_kartu,
                          () => {
                            return payload;
                          }
                        ).catch((err) => {
                          throw new Error(err);
                        });
                        // throw new Error(
                        //   `${kontrol.data.metaData.message}, Selesaikan atau batalkan janji kontrol terlebih dahulu!.`
                        // );
                      }
                      throw new Error(
                        `${kontrol.data.metaData.message}, Mohon coba lagi atau lakukan pendaftaran offline pada hari H oleh Admin`
                      );
                    }
                  });
              }
              return payload;
            }
            if (sep.data.metaData) {
              if (
                sep.data.metaData.message.toLowerCase() === "data tidak ada"
              ) {
                return payload;
              }
              throw new Error(
                `${sep.data.metaData.message}, Mohon coba lagi atau lakukan pendaftaran offline pada hari H oleh Admin`
              );
            }
            throw new Error(
              "Gagal Membuat Surat Kontrol, Mohon coba lagi atau lakukan pendaftaran offline pada hari H oleh Admin"
            );
          });
      }
      return payload;
    })
    .then((pasien) => {
      is_lansia = pasien.lansia;
      no_kartu = no_kartu || pasien.ps_no_jmn_non_cash;
      nik = nik || pasien.ps_nomor_identitas;
      jenis_id = nik ? 1 : pasien.ps_jenis_nomor_identitas;
      no_hp = no_telp;
      no_kontrol = pasien.no_kontrol;
      // let is_siang = isSiang(waktu);
      let is_siang = id_layanan == 87 ? true : false;
      const query = `select fnoantri(:idLayanan,:date,:tipe,:psID, :doctorId) as data`;
      return models.sequelize
        .query(query, {
          type: QueryTypes.SELECT,
          replacements: {
            idLayanan: id_layanan,
            date: tanggal,
            psID: pasien.ps_id,
            doctorId: doctor_id,
            tipe: is_siang ? 2 : 1,
          },
        })
        .then((payload) => {
          if (payload.length === 0) {
            throw new Error("Gagal Mendaftar");
          }
          return payload[0];
        });
    })
    .then((payload) => {
      let resultTwo = payload.data.split("_");
      if (is_bpjs) {
        return this.checkPBIPeserta(no_kartu).then((png) => {
          return models.rencana_kunjungan
            .update(
              {
                rkun_png_noncash: png,
                is_lansia: is_lansia,
                is_bpjs: is_bpjs,
              },
              {
                where: {
                  rkun_id: resultTwo[1],
                },
              }
            )
            .then(() => {
              return payload;
            });
        });
      } else {
        return models.rencana_kunjungan
          .update(
            {
              rkun_png_noncash: -1,
              is_lansia: is_lansia,
              is_bpjs: is_bpjs,
              rkun_tgl_daftar: moment().format("YYYY-MM-DD"),
            },
            {
              where: {
                rkun_id: resultTwo[1],
              },
            }
          )
          .then(() => {
            return payload;
          });
      }
    })
    .then((payload) => {
      let resultTwo = payload.data.split("_");
      let rkunId = null;
      let rkunNo = null;
      rkunId = resultTwo[1];
      rkunNo = resultTwo[2];
      return getVisitTime(rkunNo, id_layanan, hariPeriksa).then((waktu) => {
        return {
          no_mr: no_mr,
          no_antri: rkunNo,
          no_kartu: no_kartu,
          nik: nik,
          no_hp: no_hp,
          kdpoli: kdpoli,
          jenis_id: jenis_id,
          rkun_id: rkunId,
          nama_layanan: nama_layanan,
          nama_pasien: nama_pasien,
          nama_dokter: nama_dokter,
          kd_dokter: kd_dokter,
          is_lansia: is_lansia,
          is_bpjs: is_bpjs,
          estimasi: waktu.one
            ? `Pkl ${waktu.one} s/d ${waktu.two} WIB`
            : `Pkl 07:00 s/d 12:00 WIB`,
          pesanfoot2: waktu.one
            ? `Pkl ${waktu.one} s/d ${waktu.two} WIB`
            : JSON.stringify(waktu),
        };
      });
    })
    .then((payload) => {
      return models.jml_nelp
        .create({
          nmpasien: payload.nama_pasien,
          no_telp: no_telp,
          mrn: payload.no_mr,
          proses: true,
          id_jns_app_layanan: 3,
          status_id: 1,
          rkunid: payload.rkun_id,
          is_lansia: payload.is_lansia,
          poli: nama_layanan,
          nm_dokter: nama_dokter,
          is_bpjs: payload.is_bpjs,
          pesanfoot1: payload.estimasi,
          pesanfoot2: payload.pesanfoot2,
          tglkunjung: tanggal,
          reg: "REG",
          noantri: payload.no_antri,
          no_rujukan: no_rujukan,
          jeniskunjungan: jenis_kunjungan || 1,
          kdpoli_bpjs: kd_poli || null,
          no_surat_kontrol: no_kontrol || null,
          nobpjs: no_kartu || null,
          jenis_reservasi: jenis_reservasi,
        })
        .then(() => {
          return payload;
        });
    })
    .then((payload) => {
      if (doctor_id != "100080") {
        let localWaktu = waktu || "08:00-14:00";
        let parseWaktu = localWaktu.split("-")[0];
        return axiosBPJS
          .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/add`, {
            kodebooking: `${payload.rkun_id}`,
            jenispasien: is_bpjs ? "JKN" : "NON JKN",
            nomorkartu: payload.no_kartu,
            nik: payload.jenis_id == 1 ? payload.nik : "",
            nohp: phoneParser(payload.no_hp),
            kodepoli: payload.kdpoli,
            namapoli: payload.nama_layanan,
            pasienbaru: 0,
            norm: payload.no_mr,
            tanggalperiksa: tanggal,
            kodedokter: `${payload.kd_dokter}`,
            namadokter: `${payload.nama_dokter}`,
            jampraktek: localWaktu,
            jeniskunjungan: jenis_kunjungan || 1,
            nomorreferensi: `${no_rujukan}`,
            nomorantrean: `${payload.no_antri}`,
            angkaantrean: payload.no_antri,
            estimasidilayani: Number(
              moment(`${tanggal} ${parseWaktu}`, "YYYY-MM-DD hh:mm")
                .add(payload.no_antri * 6, "minutes")
                .format("x")
            ),
            sisakuotajkn: is_bpjs ? quota.sisa_bpjs - 1 : quota.sisa_bpjs,
            kuotajkn: quota.quota_bpjs,
            sisakuotanonjkn: !is_bpjs ? quota.sisa_umum - 1 : quota.sisa_umum,
            kuotanonjkn: quota.quota_umum,
            keterangan:
              "Peserta harap 30 menit lebih awal guna pencatatan administrasi.",
          })
          .then((bpjs) => {
            return funcAddEncounter({ rkun_id: payload.rkun_id })
              .then(() => {
                return bpjs;
              })
              .catch(() => {
                return bpjs;
              });
          })
          .then((bpjs) => {
            if (!bpjs.metadata || bpjs.metadata.code !== 200) {
              return models.jml_nelp
                .update(
                  {
                    task_id: 0,
                    error_jkn: bpjs.metadata
                      ? bpjs.metadata.message
                      : "Gagal Insert JKN",
                  },
                  {
                    where: {
                      rkunid: payload.rkun_id,
                    },
                  }
                )
                .then(() => {
                  return payload;
                });
            } else {
              if (getDiffDate(tanggal) === 0) {
                return axiosBPJS
                  .post(
                    `/${process.env.BPJS_ANTRIAN_URL}/antrean/updatewaktu`,
                    {
                      kodebooking: `${payload.rkun_id}`,
                      taskid: 3,
                      waktu: moment.utc().format("x"),
                    }
                  )
                  .then(() => {
                    return models.jml_nelp
                      .update(
                        {
                          task_id: 3,
                          error_jkn: null,
                        },
                        {
                          where: {
                            rkunid: payload.rkun_id,
                          },
                        }
                      )
                      .then(() => {
                        return payload;
                      });
                  })
                  .catch((err) => {
                    return models.jml_nelp
                      .update(
                        {
                          error_jkn: `Gagal Update Task ID : 3`,
                        },
                        {
                          where: {
                            rkunid: payload.rkun_id,
                          },
                        }
                      )
                      .then(() => {
                        return payload;
                      });
                  });
              } else {
                return payload;
              }
            }
          })
          .catch((err) => {
            return models.jml_nelp
              .update(
                {
                  error_jkn: `Gagal Insert JKN`,
                },
                {
                  where: {
                    rkunid: payload.rkun_id,
                  },
                }
              )
              .then(() => {
                return payload;
              });
          });
      } else {
        return payload;
      }
    });
};

exports.findHargaPoli = (req, res) => {
  const { id_layanan } = req.query;
  return models.ref_produk
    .findOne({
      attributes: ["ref_prod_hargajual"],
      order: [["ref_prod_id", "desc"]],
      where: {
        ref_prod_is_registrasi: true,
        ref_prod_id_grup: 3,
        ref_prod_id_layanan: id_layanan,
        ref_prod_is_active: true,
        ref_prod_code: sequelize.literal(
          "SUBSTRING(ref_prod_code, 1, 2) = '01'"
        ),
        // substring(ref_prod_code from 1 for 2)='01',
        ref_prod_nama: {
          [Op.iLike]: "pemeriksaan%",
        },
      },
    })
    .then((harga) => {
      if (!harga) {
        throw new Error("Harga tidak terseida");
      }
      return success(req, res, harga, "Harga termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal mendaftar", 500, err);
    });
};

exports.findTutupPoli = (req, res) => {
  const { tanggal, id_layanan } = req.query;
  if (!tanggal) {
    return error(req, res, {}, "Isi Tanggal", 400, null);
  }
  return models.history_ubah_activenonactive_poli
    .findOne({
      where: {
        id_poli: id_layanan,
        tgl_nonactive: tanggal,
        status: false,
      },
    })
    .then((tutup) => {
      if (tutup) {
        throw new Error("Poli Tutup");
      }
      return success(req, res, "", "Poli Buka.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.latestErrorMobile = (req, res) => {
  return models.trx_notif_error_mobile
    .findOne({
      order: [["notif_error_mobile_id", "DESC"]],
    })
    .then((payload) => {
      return success(req, res, payload, "Loaded");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.checkPasien = (req, res) => {
  const { no_ktp } = req.query;
  if (!no_ktp) {
    return error(req, res, {}, "Isi nomer MR atau no KTP", 400, null);
  }

  return models.v_pasien
    .findOne({
      where: {
        ps_nomor_identitas: no_ktp,
        ps_jenis_nomor_identitas: 1,
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien Tidak Ditemukan");
      }
      return {
        ps_namalengkap: removeVocal(pasien.ps_namalengkap),
        ps_mrn: pasien.ps_mrn,
        ps_kecamatan: pasien.ps_kecamatan,
      };
    })
    .then((payload) => {
      return success(req, res, payload, "Berhasil");
    })
    .catch((err) => {
      if (err && err.message == "Pasien Tidak Ditemukan") {
        return error(req, res, {}, "Pasien Tidak Ditemukan", 401, null);
      }
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.daftarIGDLama = (req, res) => {
  const { no_ktp, keluhan } = req.body;
  if (!no_ktp) {
    return error(req, res, {}, "Isi nomer MR atau no KTP", 400, null);
  }

  return models.v_pasien
    .findOne({
      where: {
        ps_nomor_identitas: no_ktp,
        ps_jenis_nomor_identitas: 1,
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien Tidak Ditemukan");
      }
      return models.formtriase.create({
        ps_id: pasien.ps_id,
        tanggaldatang: moment().format(),
        namapasien: pasien.ps_namalengkap,
        jeniskelamin: pasien.ps_jeniskelamin == 2 ? "PEREMPUAN" : "LAKI-LAKI",
        keluhanutama: keluhan,
        usia: moment().diff(pasien.ps_tgllahir, "years"),
      });
    })
    .then(() => {
      return success(req, res, "", "Berhasil Terdaftar, Mohon tunggu dokter");
    })
    .catch((err) => {
      if (err && err.message == "Pasien Tidak Ditemukan") {
        return error(req, res, {}, "Pasien Tidak Ditemukan", 401, null);
      }
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.daftarIGDBaru = (req, res) => {
  let {
    jenisId,
    jenisIdnomor,
    namaLengkap,
    namaPanggilan,
    tempatLahir,
    tglLahir,
    jenisKelamin,
    alamat,
    rt,
    rw,
    kelurahan,
    kecamatan,
    kotaDati,
    kodePos,
    propinsi,
    noTelpon,
    agama,
    nilaiYakin,
    textNilaiYakin,
    statusNikah,
    statusWarganegara,
    infoIbu,
    infoAyah,
    infoIstriSuami,
    noPenjamin,
    namaWaliDarurat,
    telponWaliDarurat,
    fileUpload,
    filePhoto,
    noTelpon2,
    alamatDomisili,
    statusPendidikan,
    penjamin,
    bahasa,
    infoKerja,
    infoKerjaLainnya,
    penjaminSubjenis,
    produkId,
    tglKunjungan,
    suku,
    keluhan,
  } = req.body;

  alamat = alamat ? alamat.toUpperCase() : "";
  rt = rt ? rt.toUpperCase() : "";
  rw = rw ? rw.toUpperCase() : "";
  kelurahan = kelurahan ? kelurahan.toUpperCase() : "";
  kecamatan = kecamatan ? kecamatan.toUpperCase() : "";
  kotaDati = kotaDati ? kotaDati.toUpperCase() : "";
  propinsi = propinsi ? propinsi.toUpperCase() : "";
  kodePos = kodePos ? kodePos.toUpperCase() : "";

  namaLengkap = namaLengkap ? namaLengkap.toUpperCase() : "";
  namaPanggilan = namaPanggilan ? namaPanggilan.toUpperCase() : "";
  tempatLahir = tempatLahir ? tempatLahir.toUpperCase() : "";
  infoAyah = infoAyah ? infoAyah.toUpperCase() : "";
  infoIstriSuami = infoIstriSuami ? infoIstriSuami.toUpperCase() : "";
  namaWaliDarurat = namaWaliDarurat ? namaWaliDarurat.toUpperCase() : "";
  alamatDomisili = alamatDomisili ? alamatDomisili.toUpperCase() : "";
  bahasa = bahasa ? bahasa.toUpperCase() : "";

  const daftarBaru = () => {
    return models.pasienonline
      .create({
        regpsonline_id_jns_id: jenisId || null,
        regpsonline_id_jns_id_nomor: jenisIdnomor || null,
        regpsonline_namalengkap: namaLengkap || null,
        regpsonline_namapanggilan: namaPanggilan || "-",
        regpsonline_tmptlahir: tempatLahir || null,
        regpsonline_tgllahir: tglLahir || null,
        regpsonline_jnskelamin: jenisKelamin || null,
        regpsonline_alamat:
          `${alamat} ${rt}/${rw} ${kelurahan} ${kecamatan} ${kotaDati} ${propinsi} ${kodePos}` ||
          null,
        regpsonline_rtrw: rt + "/" + rw || null,
        regpsonline_kelurahan: kelurahan || null,
        regpsonline_kecamatan: kecamatan || null,
        regpsonline_kotadati: kotaDati || null,
        regpsonline_kdpos: kodePos || null,
        regpsonline_propinsi: propinsi || null,
        regpsonline_notelpon: noTelpon || null,
        regpsonline_agama: agama || null,
        regpsonline_nilaiyakin: nilaiYakin || null,
        regpsonline_textnilaiyakin: textNilaiYakin || null,
        regpsonline_stsnikah: statusNikah || null,
        regpsonline_stswarganegara: statusWarganegara || null,
        regpsonline_infoibu: infoIbu || "-",
        regpsonline_infoayah: infoAyah || "-",
        regpsonline_infoistrisuami: infoIstriSuami || "-",
        regpsonline_nopenjamin: noPenjamin || null,
        regpsonline_nmwalidarurat: namaWaliDarurat || "-",
        regpsonline_telponwalidarurat: telponWaliDarurat || "-",
        regpsonline_fileupload: req.fileName || "-",
        regpsonline_filephoto: req.fileName || "-",
        regpsonline_flig_flag: false,
        regpasienonline_notelpon2: noTelpon2 || null,
        regpsonline_alamat_domisili: alamatDomisili || null,
        regpsonline_stspendidikan: statusPendidikan || null,
        regpsonline_penjamin: penjamin || null,
        regpsonline_bahasa: bahasa || null,
        regpsonline_infokerja: infoKerja || null,
        regpsonline_infokerja_lainnya: infoKerjaLainnya || null,
        regpsonline_produk_id: produkId || null,
        regpsonline_tgl_berkunjung: tglKunjungan || null,
        regpsonline_tribe: suku || null,
      })
      .then((pasien) => {
        if (pasien) {
          return models.formtriase.create({
            tanggaldatang: moment().format(),
            namapasien: pasien.regpsonline_namalengkap,
            jeniskelamin:
              pasien.regpsonline_jnskelamin == 2 ? "PEREMPUAN" : "LAKI-LAKI",
            usia: moment().diff(pasien.regpsonline_tgllahir, "years"),
            regpsonline_id_reg: pasien.regpsonline_id_reg,
            keluhanutama: keluhan,
          });
        }
        throw new Error("Gagal Daftar");
      })
      .catch((err) => {
        throw new Error(err);
      });
  };

  return models.v_pasien
    .findOne({
      where: {
        ps_jenis_nomor_identitas: 1,
        ps_nomor_identitas: jenisIdnomor,
      },
    })
    .then((pasien) => {
      if (!pasien) {
        return daftarBaru();
      }
      if (pasien.ps_tgllahir != tglLahir) {
        throw new Error("Tanggal lahir tidak sesuai");
      }
      return models.formtriase.create({
        ps_id: pasien.ps_id,
        tanggaldatang: moment().format(),
        namapasien: pasien.ps_namalengkap,
        jeniskelamin: pasien.ps_jeniskelamin == 2 ? "PEREMPUAN" : "LAKI-LAKI",
        usia: moment().diff(pasien.ps_tgllahir, "years"),
      });
    })
    .then(() => {
      return success(req, res, "", "Berhasil Terdaftar, Mohon tunggu dokter");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.poliTutupMendadak = (req, res) => {
  const { tgl, id_layanan } = req.body;
  return models.rencana_kunjungan
    .findAll({
      include: [
        {
          model: models.jml_nelp,
          required: true,
          as: "jml_nelp",
        },
      ],
      where: {
        rkun_tgl_visit: tgl,
        rkun_id_layanan: id_layanan,
      },
    })
    .then((payload) => {
      let arr = [];
      let text =
        "Halo, ini adalah pesan otomatis RSUD Cengkareng dikarenakan anda memiliki reservasi POLI ORTHO 30 Des 2022. Kami menginfokan bahwa. 1. poli Orthopedi tanggal 30 Des 2022 Tutup. 2. Untuk kontrol obat rutin, silahkran mendaftar langsung ke KIOS-K ke Poli BEDAH UMUM 3. Hari Sabtu 31 Des 2022 buka dengan Dr. Nucky Indra. Mohon maaf atas ketidaknyamanannya. Untuk informasi lebih lanjut hubungi rscengkareng@jakarta.go.id. Salam Sehat DATIN RSUD Cengkareng.";
      payload.map((item, i) => {
        if (item.jml_nelp.no_telp) {
          if (i == 0) {
            arr.push(sendWA("6285779181788", text));
          }
          return arr.push(sendWA(item.jml_nelp.no_telp, text));

          // if (i == 0) {
          //   return arr.push(sendWA("6285779181788", text));

          //   // return arr.push("6285779181788");
          // }
          // return arr.push(item.jml_nelp.no_telp);
        }
        return;
      });
      return Promise.all(arr);
    })
    .then(() => {
      return success(req, res, "", "Berhasil Terdaftar, Mohon tunggu dokter");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
  // Promise.all([this.sendWA(payload.no_telp, link)]);
};
