const models = require("../../models");
const { Op } = require("sequelize");
const { success, error } = require("../../helpers/utility/response");
const axios = require("axios");
const md5 = require("md5");
const moment = require("moment");
const convert = require("xml-js");
let province_json = require("../../public/geography/jkn/province.json");
let regency_json = require("../../public/geography/jkn/regency.json");
let district_json = require("../../public/geography/jkn/district.json");
let village_json = require("../../public/geography/jkn/village.json");
const { getProvinceRegency } = require("../../helpers/utility/geoJKN");

exports.pendidikan = (req, res) => {
  return models.asp_ref_pendidikan
    .findAll({
      order: [["pend_id", "ASC"]],
    })
    .then((payload) => {
      return success(req, res, payload, "Pendidikan termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.agama = (req, res) => {
  return models.ref_agama
    .findAll({
      order: [["ref_agama_id", "ASC"]],
    })
    .then((payload) => {
      return success(req, res, payload, "Agama termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.pekerjaan = (req, res) => {
  return models.ref_pekerjaan
    .findAll({
      order: [["ref_pkrjn_id", "ASC"]],
    })
    .then((payload) => {
      return success(req, res, payload, "Pekerjaan termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.jenisIdentitas = (req, res) => {
  return models.asp_ref_jenis_kartu_identitas
    .findAll({
      order: [["ref_jki_id", "ASC"]],
    })
    .then((payload) => {
      return success(req, res, payload, "Jenis ID termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.statusNikah = (req, res) => {
  return models.asp_ref_status_nikah
    .findAll({
      order: [["stat_id", "ASC"]],
    })
    .then((payload) => {
      return success(req, res, payload, "Status Nikah termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.produk = (req, res) => {
  const { category } = req.query;

  let whereAddOn = {};
  if (process.env.NODE_ENV === "production") {
    whereAddOn = {
      ref_prod_nama: ["Vaksinasi Meningitis", "Vaksinasi Influenza"],
    };
    // Object.assign(whereAddOn, {
    //   ref_prod_nama: [
    //     "Vaksinasi Meningitis",
    //     "Vaksinasi Influenza",
    //     "Chiropraksi",
    //   ],
    // });
  } else {
    whereAddOn = {
      ref_prod_nama: [
        "Vaksinasi Meningitis",
        "Vaksinasi Influenza",
        "Chiropraksi",
      ],
    };
  }
  return models.ref_produk
    .findAll({
      where: {
        ...whereAddOn,
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Produk termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.getNIK = (req, res) => {
  const { nik } = req.query;
  let uname = "wsrsudckrg";
  let pass = "GWCkrgRSUDW5";
  let pkey = md5("RSUD" + md5(moment().format("DDMMYYYY")) + "CENGKARENG");

  let encodedNIK = encodeURIComponent(nik.trim());
  // console.log(moment().format("DDMMYYYY"));
  let url = "http://10.0.0.20/rsudcengkareng/xml.jsp";
  return axios
    .get(url, {
      params: {
        usernm: uname,
        pass: pass,
        app: "SILaporLahir",
        pget: "Kelahiran",
        pusr: "admin",
        proc: "GETNIK",
        nik: encodedNIK,
        pkey: pkey,
      },
    })
    .then((payload) => {
      let result1 = convert.xml2json(payload.data, {
        spaces: 4,
        compact: true,
      });
      let data = JSON.parse(result1);
      let identitas = data.DATA;
      if (identitas) {
        return success(req, res, identitas, "Identitas termuat.");
      } else {
        return error(req, res, {}, "Gagal mendapatkan NIK", 200, err);
      }
    })
    .catch((err) => {
      if (err.response) {
        if (err.response.status === 404) {
          return error(req, res, {}, "Ada Kesalahan dari DUKCAPIL", 200, err);
        }
      }
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.getTipeBerkas = (req, res) => {
  return models.mst_tipe_berkas
    .findAll()
    .then((payload) => {
      return success(req, res, payload, "Berkas termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.addTipeBerkas = (req, res) => {
  const { namaBerkas } = req.body;
  return models.mst_tipe_berkas
    .create({
      nama_berkas: namaBerkas,
    })
    .then((payload) => {
      if (payload) {
        return success(req, res, payload, "Berkas berhasil ditambahkan.");
      }
      throw new Error("Gagal Insert Berkas");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getPenanggung = (req, res) => {
  return models.asp_penanggung
    .findAll({
      order: [
        // Will escape title and validate DESC against a list of valid direction parameters
        ["png_nama", "ASC"],
      ],
      where: {
        id_header_png: {
          [Op.not]: 2,
        },
        png_id: {
          // [Op.notIn]: ["0"],
          [Op.notIn]: ["85966", "0", "85935", "86106", "85882", "85931"],
        },
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Penjamin termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getPropinsi = (req, res) => {
  return models.asp_ref_propinsi
    .findAll({
      // where: {
      //   ref_propinsi_nama: "",
      // },
    })
    .then((payload) => {
      return success(req, res, payload, "Provinsi termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getKotamadya = (req, res) => {
  const { propinsi_id } = req.query;
  if (!propinsi_id) {
    return res.status(400).json({
      status: 400,
      message: "Isi ID Propinsi",
      data: [],
    });
  }
  return models.asp_ref_kotamadya_dati2
    .findAll({
      where: {
        ref_kotadati2_propinsi_id: propinsi_id,
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Kotamadya termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getKecamatan = (req, res) => {
  const { kotamadya_id } = req.query;
  if (!kotamadya_id) {
    return res.status(400).json({
      status: 400,
      message: "Isi ID Kotamadya",
      data: [],
    });
  }
  return models.asp_ref_kecamatan
    .findAll({
      where: {
        ref_kcamatan_kotadati2_id: kotamadya_id,
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Kecamatan termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getKelurahan = (req, res) => {
  const { kecamatan_id } = req.query;

  if (!kecamatan_id) {
    return res.status(400).json({
      status: 400,
      message: "Isi ID Kecamatan",
      data: [],
    });
  }

  return models.asp_ref_kelurahan
    .findAll({
      where: {
        ref_klurahan_camat_id: kecamatan_id,
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Kelurahan termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getPoliBPJS = (req, res) => {
  const { kdpoli, jenis_kunjungan } = req.query;
  if (!kdpoli) {
    return error(req, res, {}, "Isi Kode Poli", 400, null);
  }
  let whr = kdpoli;

  if (jenis_kunjungan == 2) {
    whr = {
      [Op.notIn]: [kdpoli, "LAB", "RAD", "UGD", "APT", "DRH"],
    };
  }
  return models.refpoli_bpjs
    .findAll({
      include: {
        model: models.ref_layanan,
        as: "ref_layanan",
        required: true,
        where: {
          ref_layanan_nama: {
            [Op.not]: "---",
          },
        },
      },
      where: {
        kdpoli: whr,
      },
      group: [
        "kd_layananpoli_rsc",
        "nmpoli",
        "kdpoli",
        "ref_layanan_nama",
        "ref_layanan_id",
        "id_refpoli",
      ],
    })
    .then((payload) => {
      if (payload.length === 0) {
        throw new Error("Poli Tidak Ditemukan");
      }
      let arr = [];
      payload.map((item) => {
        return arr.push({
          id_refpoli: item.id_refpoli,
          id_poli: item.kd_layananpoli_rsc,
          ref_layanan_nama: `${item.kdpoli} - ${item.ref_layanan.ref_layanan_nama}`,
          kd_poli: item.kdpoli,

          // kd_layananpoli_rsc: item.kd_layananpoli_rsc,
          // nmpoli: item.ref_layanan.ref_layanan_nama,
          // kd_poli: item.kdpoli,
        });
      });
      return success(req, res, arr, "Poli termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getGeoLocation = (req, res) => {
  const { tipe, id } = req.query;
  if (tipe == "provinsi") {
    return res.json(province_json);
  } else if (tipe == "kota") {
    let items = regency_json.filter(
      (item) => String(item.regency_id).substring(0, 2) == id
    );
    return res.json(items);
  } else if (tipe == "kecamatan") {
    let items = regency_json.filter((item) => item.regency_id == id);
    return res.json(items);
  } else if (tipe == "kelurahan") {
    let items = village_json.filter((item) => item.district_id == id);
    return res.json(items);
  }
  return res.json([]);
};
exports.findMaintenance = (req, res) => {
  const { app_name } = req.query;
  return models.mst_maintenance
    .findOne({
      where: {
        mntce_app_name: app_name,
        mntce_start: {
          [Op.lte]: moment().format(),
        },
        mntce_end: {
          [Op.gte]: moment().format(),
        },
        mntce_completed: {
          [Op.not]: true,
        },
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Maintenance termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
