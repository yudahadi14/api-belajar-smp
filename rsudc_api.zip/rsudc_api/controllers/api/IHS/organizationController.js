const axiosIHS = require("../../../helpers/axios/axiosIHS");
const { success, error } = require("../../../helpers/utility/response");
const { organizationType } = require("./variables");
const models = require("../../../models");

exports.funcAddOrganization = async ({
  organization_name,
  organization_code,
  root_organization_id,
}) => {
  // --A. Kegunaan : Untuk nambah struktur organisasi
  // --B. HOW TO :
  // 1. Semua field wajib kecuali root_organization_id
  // 2. Isi root_organization_id jika sebagai anak (organization id IHS)
  // 3. Isi organization_code (lihat manual PDF IHS)
  // --C. MINUS :
  // 1. Telcom field belum
  // 2. Address field belum

  if (!organization_name) {
    throw new Error("Isi Org ID");
  }
  if (!organization_code) {
    throw new Error("Isi Org Code");
  }

  const body = {
    resourceType: "Organization",
    active: true,
    type: [
      {
        coding: [
          organizationType({ type: organization_code }),
          // {
          //   system: "http://terminology.hl7.org/CodeSystem/organization-type",
          //   code: organization_code,
          //   display: "Hospital Department",
          // },
        ],
      },
    ],
    name: organization_name,
    // telecom: [
    //   {
    //     system: "phone",
    //     value: "+6221-54372874",
    //     use: "work",
    //   },
    //   {
    //     system: "email",
    //     value: "simcrew@gmail.com",
    //     use: "work",
    //   },
    //   {
    //     system: "url",
    //     value: "www.rsudcengkareng.com",
    //     use: "work",
    //   },
    // ],
    address: [
      {
        use: "work",
        type: "both",
        line: [
          "Jalan kamal raya bumi cengkareng indah cengkareng timur jakarta barat 11730",
        ],
        city: "Jakarta",
        postalCode: "11730",
        country: "ID",
        extension: [
          {
            url: "https://fhir.kemkes.go.id/r4/StructureDefinition/administrativeCode",
            extension: [
              {
                url: "province",
                valueCode: "31",
              },
              {
                url: "city",
                valueCode: "3173",
              },
              {
                url: "district",
                valueCode: "317301",
              },
              {
                url: "village",
                valueCode: "3173011001",
              },
            ],
          },
        ],
      },
    ],
    partOf: {
      reference: `Organization/${process.env.IHS_ORGANIZATION}`,
      display: "RSUD Cengkareng",
    },
  };
  const url = `/Organization`;
  if (root_organization_id) {
    return models.ihs_organization
      .findOne({
        where: {
          organization_id: root_organization_id,
        },
      })
      .then((org) => {
        if (!org) {
          throw new Error("Root organization tidak ditemukan");
        }
        return axiosIHS
          .post(url, {
            ...body,
            partOf: {
              reference: `Organization/${org.organization_id}`,
              display: `${organization_name}`,
            },
          })
          .then((payload) => {
            if (Number(payload.status) !== 201) {
              throw new Error("Gagal Insert Organization");
            }
            return models.ihs_organization.create({
              ihs_organization_name: organization_name,
              organization_id: payload.data.id,
              root_organization_id: org.ihs_organization_id,
            });
          });
      });
  } else {
    return axiosIHS.post(url, body).then((payload) => {
      if (Number(payload.status) !== 201) {
        throw new Error("Gagal Insert Organization");
      }
      return models.ihs_organization.create({
        ihs_organization_name: organization_name,
        organization_id: payload.data.id,
      });
    });
  }
};

exports.addOrganization = (req, res) => {
  const { organization_name, organization_code, root_organization_id } =
    req.body;

  if (!organization_name) {
    return error(req, res, "", "Isi Organization Name", 400);
  }
  if (!organization_code) {
    return error(req, res, "", "Isi Organization Code", 400);
  }
  return this.funcAddOrganization({
    organization_name,
    organization_code,
    root_organization_id,
  })
    .then((payload) => {
      if (!payload) {
        throw new Error("Gagal memuat organisasi");
      }
      return success(req, res, payload, "Berhasil tambah organisasi");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal tambah organisasi", 500, err);
    });
};

exports.funcGetOrganization = ({ organization_id }) => {
  if (!organization_id) {
    throw new Error("Isi Organisasi ID");
  }
  const url = `/Location/${organization_id}`;
  return axiosIHS.get(url);
};

exports.getOrganization = (req, res) => {
  const { organization_id } = req.query;
  if (!organization_id) {
    return error(req, res, "", "Isi Organisasi ID", 400);
  }
  return this.funcGetOrganization({ organization_id })
    .then((payload) => {
      if (!payload.data) {
        throw new Error("Gagal memuat organisasi");
      }
      return success(req, res, payload.data, "Berhasil tambah organisasi");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal tambah organisasi", 500, err);
    });
};
