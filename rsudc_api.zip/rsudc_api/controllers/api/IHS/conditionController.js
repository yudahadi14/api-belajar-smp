const axiosIHS = require("../../../helpers/axios/axiosIHS");
const moment = require("moment");
const { error, success } = require("../../../helpers/utility/response");
const models = require("../../../models");

exports.funcAddCondition = ({ kun_id }) => {
  if (!kun_id) {
    throw new Error("Isi KUN ID");
  }

  let body = {
    resourceType: "Condition",
    clinicalStatus: {
      coding: [
        {
          system: "http://terminology.hl7.org/CodeSystem/condition-clinical",
          code: "active",
          display: "Active",
        },
      ],
    },
    category: [
      {
        coding: [
          {
            system: "http://terminology.hl7.org/CodeSystem/condition-category",
            code: "encounter-diagnosis",
            display: "Encounter Diagnosis",
          },
        ],
      },
    ],
    // code: {
    //   coding: [
    //     {
    //       system: "http://hl7.org/fhir/sid/icd-10",
    //       code: "A15.0",
    //       display:
    //         "Tuberculosis of lung, confirmed by sputum microscopy with or without culture",
    //     },
    //   ],
    // },
    // subject: {
    //   reference: "Patient/100000030009",
    //   display: "Budi Santoso",
    // },
    // encounter: {
    //   reference: "Encounter/38550d29-059c-4e60-8929-534b82c9ea8b",
    // },
  };
  return models.kunjungan
    .findOne({
      attributes: [
        "kun_id",
        "kun_id_rencana_kunjungan",
        "kun_id_pasien",
        "kun_id_dokter",
      ],
      where: {
        kun_id: kun_id,
      },
      include: [
        {
          model: models.icd,
          as: "icd",
          include: {
            model: models.ref_icd10,
            as: "icd_ten",
            // required: true,
          },
        },
        {
          model: models.rencana_kunjungan,
          required: true,
          as: "rencana_kunjungan",
          attributes: ["rkun_id", "rkun_id_dokter"],
          include: [
            {
              model: models.ihs_encounter,
              as: "ihs_encounter",
              required: true,
            },
            {
              model: models.ihs_pasien,
              as: "ihs_pasien",
              required: true,
              include: {
                as: "asp_pasien",
                model: models.asp_pasien,
                attributes: ["ps_id", "ps_namalengkap"],
              },
            },
            {
              model: models.ihs_practioner,
              as: "ihs_practioner",
              required: true,
            },
          ],
        },
      ],
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Data Tidak Ditemukan!");
      }
      let promises = [];
      const sendCondition = (body, icd_id) => {
        let url = "/Condition";
        return axiosIHS.post(url, body).then((payload) => {
          if (!payload.data || !payload.data.id) {
            throw new Error("Gagal tambah diagnosa");
          }
          return models.icd
            .findOne({
              where: {
                icd_id,
              },
            })
            .then((icd) => {
              if (icd) {
                icd.ihs_condition_id = payload.data.id;
                icd.save();
              }
              return payload.data;
            })
            .catch((err) => {
              console.log("--err", err.response);
            });
        });
      };
      payload.icd.map((item) => {
        body = {
          ...body,
          encounter: {
            reference: `Encounter/${payload.rencana_kunjungan.ihs_encounter.encounter_id}`,
          },
          subject: {
            reference: `Patient/${payload.rencana_kunjungan.ihs_pasien.pasien_id}`,
            display: `${payload.rencana_kunjungan.ihs_pasien.asp_pasien.ps_namalengkap}`,
          },
          code: {
            coding: [
              {
                system: "http://hl7.org/fhir/sid/icd-10",
                code: item.icd_code,
                display: item.icd_ten ? item.icd_ten.ref_icd10_deskripsi : "No display",
              },
            ],
          },
        };
        promises.push(sendCondition(body, item.icd_id));
        // promises.push(body);
      });
      return Promise.all(promises);
    });
  return models.icd
    .findOne({
      where: {
        icd_id,
      },
      include: [
        {
          model: models.kunjungan,
          as: "kunjungan",
          required: true,
          include: {
            model: models.rencana_kunjungan,
            required: true,
            as: "rencana_kunjungan",
          },
        },
        {
          model: models.ref_icd10,
          as: "icd_ten",
        },
      ],
    })
    .then((icd) => {
      if (!icd) {
        throw new Error("ICD Tidak ditemukan");
      }
      return models.ihs_encounter
        .findOne({
          where: {
            rkun_id: icd.kunjungan.kun_id_rencana_kunjungan,
          },
          include: {
            model: models.rencana_kunjungan,
            required: true,
            as: "rencana_kunjungan",
            attributes: ["rkun_id", "rkun_id_pasien"],
            include: {
              model: models.ihs_pasien,
              required: true,
              as: "ihs_pasien",
              include: {
                model: models.asp_pasien,
                required: true,
                attributes: ["ps_id", "ps_namalengkap"],
                as: "asp_pasien",
              },
            },
          },
        })
        .then((encounter) => {
          body = {
            ...body,
            encounter: {
              reference: `Encounter/${encounter.encounter_id}`,
            },
            subject: {
              reference: `Patient/${encounter.rencana_kunjungan.ihs_pasien.pasien_id}`,
              display: `${encounter.rencana_kunjungan.ihs_pasien.asp_pasien.ps_namalengkap}`,
            },
            code: {
              coding: [
                {
                  system: "http://hl7.org/fhir/sid/icd-10",
                  code: icd.icd_code,
                  display: item.icd_ten ? item.icd_ten.ref_icd10_deskripsi : "No display",
                },
              ],
            },
          };
          let url = "/Condition";
          return axiosIHS.post(url, body).then((payload) => {
            if (!payload.data || payload.status !== 201) {
              throw new Error("Gagal tambah diagnosa");
            }
            icd.ihs_condition_id = payload.data.id;
            icd.save();
            return payload.data;
          });
        });
    });
};

exports.addCondition = (req, res) => {
  const { kun_id } = req.body;
  if (!kun_id) {
    return error(req, res, "", "Isi Parmeter", 400, null);
  }
  let promiseTambah = new Promise((resolve, reject) => {
    resolve(
      this.funcAddCondition({
        kun_id,
      })
    );
  });

  return promiseTambah
    .then((payload) => {
      return success(req, res, payload, "Berhasil menambah diagnosa");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal menambah diagnosa", 500, err);
    });
};
