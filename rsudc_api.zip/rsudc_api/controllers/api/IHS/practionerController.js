const { Op } = require("sequelize");
const axiosIHS = require("../../../helpers/axios/axiosIHS");
const CustomError = require("../../../helpers/utility/customError");
const { success, error } = require("../../../helpers/utility/response");
const models = require("../../../models");

exports.funcGetPractionerByNIK = ({ nik }) => {
  if (!nik) {
    throw new Error("Isi NIK");
  }
  const url = `/Practitioner?identifier=https://fhir.kemkes.go.id/id/nik|${nik}`;

  return models.pegawai
    .findOne({
      where: {
        peg_ktp: nik,
      },
    })
    .then((pegawai) => {
      if (!pegawai) {
        throw new Error("NIK Pegawai tidak ditemukan.");
      } else if (!pegawai.peg_ihs_practioner_id) {
        return axiosIHS.get(url).then((payload) => {
          if (
            !payload.data ||
            payload.data.total === 0
            // ||
            // payload.status !== 201
          ) {
            throw new Error("Gagal memuat pegawai");
          }
          return models.pegawai
            .update(
              {
                peg_ihs_practioner_id: payload.data.entry[0].resource.id,
              },
              {
                where: {
                  peg_id: pegawai.peg_id,
                },
              }
            )
            .then((pegawai) => {
              return {
                id: payload.data.entry[0].resource.id,
                nama: payload.data.entry[0].resource.name[0],
              };
            });
        });
      } else if (pegawai.peg_ihs_practioner_id) {
        return {
          id: pegawai.peg_ihs_practioner_id,
        };
      } else {
        throw new Error("Ada kesalahan.");
      }
    });
};

exports.getPractionerByNIK = (req, res) => {
  const { nik } = req.query;
  if (!nik) {
    return error(req, res, "", "Isi NIK", 400);
  }
  return this.funcGetPractionerByNIK({ nik })
    .then((payload) => {
      if (!payload) {
        throw new Error("Gagal memuat Practioner");
      }
      return success(req, res, payload, "Berhasil mendapatkan Practioner");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal mendaptkan Practioner", 500, err);
    });
};

exports.funcGetPractionerByID = ({ peg_id }) => {
  if (!peg_id) {
    throw new Error("Input ID");
  }
  return models.pegawai
    .findOne({
      where: {
        peg_id,
        // peg_ktp: {
        //   [Op.not]: null,
        // },
      },
      include: {
        model: models.ihs_practioner,
        as: "ihs_practioner",
      },
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Practioner Tidak Ditemukan");
      }
      let pasien = payload.get({ plain: true });
      if (pasien.ihs_practioner) {
        return {
          peg_id: pasien.ihs_practioner.practioner_id,
          peg_nama: pasien.peg_nama,
        };
      }
      if (!pasien.ihs_practioner && pasien.peg_ktp) {
        return this.funcGetPractionerByNIK({
          nik: pasien.peg_ktp,
        }).then((ps) => {
          return {
            peg_id: ps.id,
            peg_nama: pasien.peg_nama,
          };
        });
      } else {
        throw new Error("Data Pegawai kosong");
      }
    });
};
