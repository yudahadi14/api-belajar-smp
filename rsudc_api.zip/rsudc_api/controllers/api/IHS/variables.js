const moment = require("moment");

exports.organizationType = ({ type }) => {
  let data = {
    system: "http://terminology.hl7.org/CodeSystem/organization-type",
    code: "other",
    display: "Other",
  };

  switch (type) {
    case "prov":
      data = {
        ...data,
        code: type,
        display: "Healthcare Provider",
      };
      break;
    case "dept":
      data = {
        ...data,
        code: type,
        display: "Hospital Department",
      };
      break;
    case "team":
      data = {
        ...data,
        code: type,
        display: "Organizational team",
      };
      break;
    case "govt":
      data = {
        ...data,
        code: type,
        display: "Government",
      };
      break;
    case "ins":
      data = {
        ...data,
        code: type,
        display: "Insurance Company",
      };
      break;
    case "pay":
      data = {
        ...data,
        code: type,
        display: "Payer",
      };
      break;
    case "edu":
      data = {
        ...data,
        code: type,
        display: "Educational Institute",
      };
      break;
    case "reli":
      data = {
        ...data,
        code: type,
        display: "Religious Institution",
      };
      break;
    case "crs":
      data = {
        ...data,
        code: type,
        display: "Clinical Research Sponsor",
      };
      break;
    case "cg":
      data = {
        ...data,
        code: type,
        display: "Community Group",
      };
      break;
    case "bus":
      data = {
        ...data,
        code: type,
        display: "Non-Healthca re Business or Corporation",
      };
      break;
    default:
      data = {
        ...data,
        code: "other",
        display: "Other",
      };
      break;
  }
  return data;
};

exports.locationType = ({ type }) => {
  let data = {
    system: "http://terminology.hl7.org/CodeSystem/location-physical-type",
    code: "ro",
    display: "Room",
  };

  switch (type) {
    case "si":
      data = {
        ...data,
        code: type,
        display: "Site",
      };
      break;
    case "bu":
      data = {
        ...data,
        code: type,
        display: "Building",
      };
      break;
    case "wi":
      data = {
        ...data,
        code: type,
        display: "Wing",
      };
      break;
    case "wa":
      data = {
        ...data,
        code: type,
        display: "Ward",
      };
      break;
    case "lvl":
      data = {
        ...data,
        code: type,
        display: "Level",
      };
      break;
    case "co":
      data = {
        ...data,
        code: type,
        display: "Corridor",
      };
      break;
    case "ro":
      data = {
        ...data,
        code: type,
        display: "Room",
      };
      break;
    case "bd":
      data = {
        ...data,
        code: type,
        display: "Bed",
      };
      break;
    case "ve":
      data = {
        ...data,
        code: type,
        display: "Vehicle",
      };
      break;
    case "ho":
      data = {
        ...data,
        code: type,
        display: "House",
      };
      break;
    case "ca":
      data = {
        ...data,
        code: type,
        display: "Cabinet",
      };
      break;
    case "rd":
      data = {
        ...data,
        code: type,
        display: "Road",
      };
      break;
    case "area":
      data = {
        ...data,
        code: type,
        display: "Area",
      };
      break;
    case "jdn":
      data = {
        ...data,
        code: type,
        display: "Jurisdiction",
      };
      break;
    case "vir":
      data = {
        ...data,
        code: type,
        display: "Virtual",
      };
      break;
    default:
      data = data;
      break;
  }
  return data;
};

exports.diagnosisType = ({ type }) => {
  let data = {
    system: "http://terminology.hl7.org/CodeSystem/diagnosis-role",
    code: "CC",
    display: "Chief complaint",
  };
  switch (type) {
    case "cc":
      data = {
        ...data,
        code: "CC",
        display: "Chief complaint",
      };
      break;
    case "cm":
      data = {
        ...data,
        code: "CM",
        display: "Comorbidity diagnosis",
      };
      break;
    case "ad":
      data = {
        ...data,
        code: "AD",
        display: "Admission diagnosis",
      };
      break;
    case "dd":
      data = {
        ...data,
        code: "DD",
        display: "Discharge diagnosis",
      };
      break;
    case "pre-op":
      data = {
        ...data,
        code: "pre-op",
        display: "pre-op diagnosis",
      };
      break;
    case "post-op":
      data = {
        ...data,
        code: "post-op",
        display: "post-op diagnosis",
      };
      break;
    case "billing":
      data = {
        ...data,
        code: "billing",
        display: "Billing",
      };
      break;
    default:
      data = data;
      break;
  }
  return data;
};

exports.statusHistory = ({ type, arr }) => {
  let data = {
    status: "arrived",
    period: {
      start: moment().format(),
      end: moment().format(),
    },
  };
  switch (type) {
    case 1:
      data = {
        status: "arrived",
        period: {
          start: moment().format(),
          end: moment().format(),
        },
      };
      break;

    default:
      break;
  }
};
