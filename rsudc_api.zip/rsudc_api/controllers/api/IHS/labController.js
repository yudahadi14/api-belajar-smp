const {
  funcGetPasienByNIK,
  funcGetPasienByID,
} = require("./patientController");
const axiosIHS = require("../../../helpers/axios/axiosIHS");
// const CustomError = require("../../../helpers/utility/customError");
const { success, error } = require("../../../helpers/utility/response");
const models = require("../../../models");
const moment = require("moment");
const { Op } = require("sequelize");
const sequelize = require("sequelize");
const {
  funcGetPractionerByNIK,
  funcGetPractionerByID,
} = require("./practionerController");
exports.serviceRequest = (req, res) => {
  const { mintalab_id } = req.query;
  if (!mintalab_id) {
    return error(req, res, "", "Isi Lab ID", 400, null);
  }
  const body = {
    resourceType: "ServiceRequest",
    status: "active",
    intent: "original-order",
    priority: "routine",
    occurrenceDateTime: moment().format(),
    authoredOn: moment().format(),
  };

  return models.permintaan_lab_header
    .findOne({
      where: {
        mintalab_id,
      },
      include: [
        {
          model: models.ihs_encounter,
          as: "ihs_encounter",
          required: true,
        },
        {
          model: models.permintaan_lab_detail,
          as: "permintaan_detail",
          required: true,
          include: {
            model: models.lab_ihs,
            required: true,
            as: "lab_ihs",
          },
        },
      ],
    })
    .then((encounter) => {
      if (!encounter) {
        throw new Error("Encounter tidak ditemukan");
      }
      body.encounter = {
        reference: `Encounter/${encounter.ihs_encounter.encounter_id}`,
        display: `Permintaan Pemeriksaan Golongan Darah ${moment().format(
          "YYYY-MM-DD hh:mm:ss"
        )}`,
      };

      return Promise.all([
        funcGetPasienByID({
          ps_id: encounter.mintalab_id_pasien,
        }).then((ps) => {
          body.subject = {
            reference: `Patient/${ps.ps_id}`,
            display: ps.ps_nama,
          };
        }),
        funcGetPractionerByID({
          peg_id: encounter.mintalab_id_dokter,
        }).then((dokter) => {
          body.requester = {
            reference: `Practitioner/${dokter.peg_id}`,
            display: dokter.peg_nama,
          };
        }),
        funcGetPractionerByID({
          peg_id: encounter.mintalab_id_dokter,
          // peg_id: encounter.mintalab_id_pemeriksa,
        }).then((pemeriksa) => {
          body.performer = [
            {
              reference: `Practitioner/${pemeriksa.peg_id}`,
              display: pemeriksa.peg_nama,
            },
          ];
        }),
      ]).then(() => {
        let arr = [];
        encounter.permintaan_detail.map((item) => {
          arr.push({
            ...body,
            identifier: [
              {
                system:
                  "http://sys-ids.kemkes.go.id/servicerequest/" +
                  process.env.IHS_ORGANIZATION,
                value: item.mintalab_dt_id,
              },
            ],
            code: {
              coding: [
                {
                  system: "http://loinc.org",
                  code: item.lab_ihs.lab_ihs_kode_loinc,
                  display: item.lab_ihs.lab_ihs_metode,
                },
              ],
              text: "Pemeriksaan Golongan Darah",
            },
          });
        });
        return arr;
      });
    })
    .then((payload) => {
      const url = "/ServiceRequest";
      return Promise.all(
        payload.map((item) => {
          return axiosIHS.post(url, item).then((ihs) => {
            if (ihs.data && ihs.data.id) {
              return models.ihs_service_request
                .create({
                  srvce_rqst_id: ihs.data.id,
                  mintalab_dt_id: item.identifier[0].value,
                  ihs_pasien_code: item.subject.reference.split("/")[1],
                  ihs_pasien_name: item.subject.display,
                  ihs_practioner_code: item.requester.reference.split("/")[1],
                  ihs_practioner_name: item.requester.display,
                  ihs_encounter_code: item.encounter.reference.split("/")[1],
                })
                .then((data) => {
                  return this.funcSpeciment({
                    mintalab_dt_id: item.identifier[0].value,
                  });
                });
            }
          });
        })
      );
    })
    .then(() => {
      return success(req, res, "", "Berhasil");
    })
    .catch((err) => {
      return error(req, res, "", "Ada Kesalahan", 500, err);
    });
};

exports.funcSpeciment = ({ mintalab_dt_id }) => {
  const body = {
    resourceType: "Specimen",
    identifier: [
      {
        system:
          "http://sys-ids.kemkes.go.id/specimen/" +
          process.env.IHS_ORGANIZATION,
        value: mintalab_dt_id,
        assigner: {
          reference: "Organization/" + process.env.IHS_ORGANIZATION,
        },
      },
    ],
    status: "available",
    receivedTime: moment().format(),
  };

  return models.ihs_service_request
    .findOne({
      where: {
        mintalab_dt_id,
      },
      include: {
        model: models.permintaan_lab_detail,
        required: true,
        include: {
          model: models.lab_ihs,
          required: true,
          as: "lab_ihs",
        },
      },
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Data Kosong");
      }
      body.request = [
        {
          reference: `ServiceRequest/${payload.srvce_rqst_id}`,
        },
      ];
      body.subject = {
        reference: `Patient/${payload.ihs_pasien_code}`,
        display: payload.ihs_pasien_name,
      };
      body.type = {
        coding: [
          {
            system: "http://snomed.info/sct",
            code: payload.permintaan_lab_detail.lab_ihs.lab_ihs_specimen_kode,
            display: payload.permintaan_lab_detail.lab_ihs.lab_ihs_specimen,
          },
        ],
      };
      body.collection = {
        method: {
          coding: [
            {
              system: "https://snomed.info/sct",
              code: payload.permintaan_lab_detail.lab_ihs
                .lab_ihs_specimen_collect_kode,
              display:
                payload.permintaan_lab_detail.lab_ihs.lab_ihs_specimen_collect,
            },
          ],
        },
        collectedDateTime: moment().format(),
      };
      const url = "/Specimen";
      return axiosIHS.post(url, body).then((payload) => {
        if (payload.data && payload.data.id) {
          return models.ihs_specimen
            .create({
              specimen_id: payload.data.id,
              mintalab_dt_id: mintalab_dt_id,
            })
            .then((data) => {
              return data;
            });
        }
      });
    })
    .catch((err) => {
      throw err;
    });
};

exports.observation = (req, res) => {
  const { mintalab_dt_id } = req.query;
  if (!mintalab_dt_id) {
    return error(req, res, "", "Isi ID", 400, null);
  }

  const body = {
    resourceType: "Observation",
    // identifier: [
    //   {
    //     system: "http://sys-ids.kemkes.go.id/observation/10000078",
    //     value: "O111111",
    //   },
    // ],
    status: "final",
    category: [
      {
        coding: [
          {
            system:
              "http://terminology.hl7.org/CodeSystem/observation-category",
            code: "laboratory",
            display: "Laboratory",
          },
        ],
      },
    ],
    // code: {
    //   coding: [
    //     {
    //       system: "http://loinc.org",
    //       code: "57743-7",
    //       display: "ABO group [Type] in Blood by Confirmatory method",
    //     },
    //   ],
    // },

    effectiveDateTime: moment().format("YYYY-MM-DD"),
    issued: moment().format(),
  };
  return models.v_hasil_lab_rsud_cek_2
    .findOne({
      where: {
        mintalab_dt_id,
        nilai: {
          [Op.or]: ["A", "B", "O", "AB"],
        },
      },
      include: [
        {
          model: models.lab_ihs,
          requred: true,
          as: "lab_ihs",
          attributes: {
            include: [
              [
                sequelize.literal(`(
                    SELECT lab_ihs_kode_loinc from lab_hasil_ihs where lab_ihs_id_prod = lab_ihs.lab_ihs_id_prod and v_hasil_lab_rsud_cek_2.nilai = lab_ihs_hasil
                )`),
                "ihs_hasil_kode",
              ],
              [
                sequelize.literal(`(
                    SELECT lab_ihs_hasil from lab_hasil_ihs where lab_ihs_id_prod = lab_ihs.lab_ihs_id_prod and v_hasil_lab_rsud_cek_2.nilai = lab_ihs_hasil
                )`),
                "ihs_hasil",
              ],
            ],
          },
        },
        {
          model: models.ihs_specimen,
          required: true,
        },
        {
          model: models.ihs_service_request,
          required: true,
        },
      ],
    })
    .then((hasil) => {
      body.valueCodeableConcept = {
        coding: [
          {
            system: "http://loinc.org",
            code: hasil.lab_ihs.ihs_hasil_kode,
            display: hasil.lab_ihs.ihs_hasil,
          },
        ],
      };
      body.performer = [
        {
          reference: `Practitioner/${hasil.ihs_service_request.ihs_practioner_code}`,
        },
        {
          reference: "Organization/" + process.env.IHS_ORGANIZATION,
        },
      ];
      body.specimen = {
        reference: `Specimen/${hasil.ihs_specimen.specimen_id}`,
      };
      body.basedOn = [
        {
          reference: `ServiceRequest/${hasil.ihs_service_request.srvce_rqst_id}`,
        },
      ];
      body.subject = {
        reference: `Patient/${hasil.ihs_service_request.ihs_pasien_code}`,
      };
      body.encounter = {
        reference: `Encounter/${hasil.ihs_service_request.ihs_encounter_code}`,
      };
      body.code = {
        coding: [
          {
            system: "http://loinc.org",
            code: hasil.lab_ihs.lab_ihs_kode_loinc,
            display: hasil.lab_ihs.lab_ihs_metode,
          },
        ],
      };
      body.identifier = [
        {
          system:
            "http://sys-ids.kemkes.go.id/observation/" +
            process.env.IHS_ORGANIZATION,
          value: hasil.id_hasil,
        },
      ];
      return hasil;
    })
    .then((payload) => {
      let hasil = payload.get({ plain: true });
      const url = "/Observation";

      return axiosIHS.post(url, body).then((ihs) => {
        if (ihs.data && ihs.data.id) {
          return models.ihs_observation
            .create({
              observe_id: ihs.data.id,
              mintalab_dt_id: hasil.id_hasil,
            })
            .then((data) => {
              return this.diagnostic({
                id_hasil: hasil.id_hasil,
                category_kode: hasil.lab_ihs.lab_ihs_golongan,
                category_name: "Hematology",
                method_code: hasil.lab_ihs.lab_ihs_kode_loinc,
                method_name: hasil.lab_ihs.lab_ihs_metode,
                result_code: hasil.lab_ihs.ihs_hasil_kode,
                result_name: hasil.lab_ihs.ihs_hasil,
                pasien_code: hasil.ihs_service_request.ihs_pasien_code,
                encounter_code: hasil.ihs_service_request.ihs_encounter_code,
                practioner_code: hasil.ihs_service_request.ihs_practioner_code,
                observation_code: ihs.data.id,
                specimen_code: hasil.ihs_specimen.specimen_id,
                service_request_code: hasil.ihs_service_request.srvce_rqst_id,
              });
            });
        }
      });
    })
    .then(() => {
      return success(req, res, "", "Berhasil");
    });
};

exports.diagnostic = ({
  id_hasil,
  category_kode,
  category_name,
  method_code,
  method_name,
  result_code,
  result_name,
  pasien_code,
  encounter_code,
  practioner_code,
  observation_code,
  specimen_code,
  service_request_code,
}) => {
  const body = {
    resourceType: "DiagnosticReport",
    identifier: [
      {
        system: `http://sys-ids.kemkes.go.id/diagnostic/${process.env.IHS_ORGANIZATION}/lab`,
        use: "official",
        value: id_hasil,
      },
    ],
    status: "final",
    category: [
      {
        coding: [
          {
            system: "http://terminology.hl7.org/CodeSystem/v2-0074",
            code: category_kode,
            display: category_name,
          },
        ],
      },
    ],
    code: {
      coding: [
        {
          system: "http://loinc.org",
          code: method_code,
          display: method_name,
        },
      ],
    },
    subject: {
      reference: `Patient/${pasien_code}`,
    },
    encounter: {
      reference: `Encounter/${encounter_code}`,
    },
    effectiveDateTime: moment().format(),
    issued: moment().format(),
    performer: [
      {
        reference: `Practitioner/${practioner_code}`,
      },
      {
        reference: "Organization/" + process.env.IHS_ORGANIZATION,
      },
    ],
    result: [
      {
        reference: `Observation/${observation_code}`,
      },
    ],
    specimen: [
      {
        reference: `Specimen/${specimen_code}`,
      },
    ],
    basedOn: [
      {
        reference: `ServiceRequest/${service_request_code}`,
      },
    ],
    conclusionCode: [
      {
        coding: [
          {
            system: "http://loinc.org",
            code: result_code,
            display: result_name,
          },
        ],
      },
    ],
  };
  const url = "/DiagnosticReport";
  return axiosIHS.post(url, body).then((ihs) => {
    if (ihs.data && ihs.data.id) {
      return models.ihs_diagnostic_report.create({
        dgnstc_rprt_id: ihs.data.id,
        id_hasil: id_hasil,
      });
    }
  });
};
