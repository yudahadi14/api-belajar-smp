const axiosIHS = require("../../../helpers/axios/axiosIHS");
const moment = require("moment");
const { error, success } = require("../../../helpers/utility/response");
const models = require("../../../models");
const { Op } = require("sequelize");

exports.funcAddComposition = ({ kun_id }) => {
  let body = {
    resourceType: "Composition",
    // identifier: {
    //   system: "http://sys-ids.kemkes.go.id/composition/10000004",
    //   value: "P20240001",
    // },
    status: "final",
    type: {
      coding: [
        {
          system: "http://loinc.org",
          code: "18842-5",
          display: "Discharge summary",
        },
      ],
    },
    category: [
      {
        coding: [
          {
            system: "http://loinc.org",
            code: "LP173421-1",
            display: "Report",
          },
        ],
      },
    ],
    // subject: {
    //   reference: "Patient/100000030009",
    //   display: "Budi Santoso",
    // },
    // encounter: {
    //   reference: "Encounter/2823ed1d-3e3e-434e-9a5b-9c579d192787",
    //   display: "Kunjungan Budi Santoso di hari Selasa, 14 Juni 2022",
    // },
    // date: "2022-06-14",
    // author: [
    //   {
    //     reference: "Practitioner/N10000001",
    //     display: "Dokter Bronsig",
    //   },
    // ],
    // title: "Resume Medis Rawat Jalan",
    // custodian: {
    //   reference: "Organization/10000004",
    // },
    // section: [
    //   {
    //     code: {
    //       coding: [
    //         {
    //           system: "http://loinc.org",
    //           code: "42344-2",
    //           display: "Discharge diet (narrative)",
    //         },
    //       ],
    //     },
    //     text: {
    //       status: "additional",
    //       div: "Rekomendasi diet rendah lemak, rendah kalori",
    //     },
    //   },
    // ],
  };

  let url = "/Composition";
  let promises = [];
  const sendData = (body, kun_id) => {
    return axiosIHS.post(url, body).then((payload) => {
      if (payload.data && payload.data.id) {
        return models.ihs_composition
          .create({
            composition_id: payload.data.id,
            kun_id: kun_id,
          })
          .then((data) => {
            return data;
          })
          .catch((err) => {
            console.log(err);
          });
      }
    });
  };
  return models.kunjungan
    .findOne({
      where: {
        kun_id,
      },
      include: [
        {
          model: models.ihs_encounter,
          required: true,
          as: "ihs_encounter",
        },
        {
          model: models.ihs_pasien,
          required: true,
          as: "ihs_pasien",
          include: [
            {
              model: models.asp_pasien,
              required: true,
              as: "asp_pasien",
            },
          ],
        },
        {
          model: models.ihs_practioner,
          required: true,
          as: "ihs_practioner",
          include: {
            model: models.pegawai,
            as: "pegawai",
            required: true,
          },
        },
        {
          model: models.klinis_anamnesa_teks,
          required: true,
          attributes: ["kli_anam_tks_id_kun", "kli_anam_tks_diet"],
          as: "klinis_anamnesa_teks",
        },
      ],
    })
    .then((kunjungan) => {
      if (!kunjungan) {
        throw new Error("Kunjungan Tidak Ditemukan");
      }
      body = {
        ...body,
        identifier: {
          system: `http://sys-ids.kemkes.go.id/composition/${process.env.IHS_ORGANIZATION}`,
          value: `${kunjungan.ihs_pasien.pasien_id}`,
        },
        subject: {
          reference: `Patient/${kunjungan.ihs_pasien.pasien_id}`,
          display: kunjungan.ihs_pasien.asp_pasien.ps_namalengkap,
        },
        encounter: {
          reference: `Encounter/${kunjungan.ihs_encounter.encounter_id}`,
          display: `Tindakan pada ${moment(kunjungan.bill_waktu).format(
            "YYYY-MM-DD"
          )}`,
        },
        date: moment(kunjungan.bill_waktu).format("YYYY-MM-DD"),
        title: "Resume Medis Rawat Jalan",
        custodian: {
          reference: "Organization/" + process.env.IHS_ORGANIZATION,
        },
        author: [
          {
            reference: `Practitioner/${kunjungan.ihs_practioner.practioner_id}`,
            display: kunjungan.ihs_practioner.pegawai.peg_nama,
          },
        ],
        section: [
          {
            code: {
              coding: [
                {
                  system: "http://loinc.org",
                  code: "42344-2",
                  display: "Discharge diet (narrative)",
                },
              ],
            },
            text: {
              status: "additional",
              div: kunjungan.klinis_anamnesa_teks.kli_anam_tks_diet,
            },
          },
        ],
      };
      if (kunjungan.klinis_anamnesa_teks.kli_anam_tks_diet) {
        return sendData(body, kun_id);
      }
      return;
    });
};

exports.addComposition = (req, res) => {
  const { kun_id } = req.body;
  if (!kun_id) {
    return error(req, res, "", "Isi Kunjungan", 400, null);
  }
  let promiseTambah = new Promise((resolve, reject) => {
    resolve(
      this.funcAddComposition({
        kun_id,
      })
    );
  });

  return promiseTambah
    .then((payload) => {
      return success(req, res, payload, "Berhasil menambah observation");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal menambah observation", 500, err);
    });
};
