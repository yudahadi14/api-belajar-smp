const axiosIHS = require("../../../helpers/axios/axiosIHS");
const moment = require("moment");
const { error, success } = require("../../../helpers/utility/response");
const models = require("../../../models");
const { Op } = require("sequelize");

exports.funcAddProcedure = ({ kun_id }) => {
  let body = {
    resourceType: "Procedure",
    status: "completed",
    category: {
      coding: [
        {
          system: "http://snomed.info/sct",
          code: "103693007",
          display: "Diagnostic procedure",
        },
      ],
      text: "Diagnostic procedure",
    },
    // code: {
    //   coding: [
    //     {
    //       system: "http://hl7.org/fhir/sid/icd-9-cm",
    //       code: "87.44",
    //       display: "Routine chest x-ray, so described",
    //     },
    //   ],
    // },
    // subject: {
    //   reference: "Patient/P00030004",
    //   display: "Budi Santoso",
    // },
    // encounter: {
    //   reference: "Encounter/2823ed1d-3e3e-434e-9a5b-9c579d192787",
    //   display:
    //     "Tindakan Rontgen Dada Budi Santoso pada Selasa tanggal 14 Juni 2022",
    // },
    // performedPeriod: {
    //   start: "2022-06-14T13:31:00+01:00",
    //   end: "2022-06-14T14:27:00+01:00",
    // },
    // performer: [
    //   {
    //     actor: {
    //       reference: "Practitioner/N10000001",
    //       display: "Dokter Bronsig",
    //     },
    //   },
    // ],
    // "reasonCode": [
    //     {
    //         "coding": [
    //             {
    //                 "system": "http://hl7.org/fhir/sid/icd-10",
    //                 "code": "A15.0",
    //                 "display": "Tuberculosis of lung, confirmed by sputum microscopy with or without culture"
    //             }
    //         ]
    //     }
    // ],
    // "bodySite": [
    //     {
    //         "coding": [
    //             {
    //                 "system": "http://snomed.info/sct",
    //                 "code": "302551006",
    //                 "display": "Entire Thorax"
    //             }
    //         ]
    //     }
    // ],
    // note: [
    //   {
    //     text: "Rontgen thorax melihat perluasan infiltrat dan kavitas.",
    //   },
    // ],
  };

  let url = "/Procedure";
  let promises = [];
  const sendData = (body, bill_id_rec, kun_id) => {
    return axiosIHS.post(url, body).then((payload) => {
      if (payload.data && payload.data.id) {
        return models.ihs_procedure
          .create({
            procedure_id: payload.data.id,
            bill_id_rec: bill_id_rec,
            kun_id: kun_id,
          })
          .then((data) => {
            return data;
          })
          .catch((err) => {
            console.log(err.response);
          });
      }
    });
  };
  return models.kunjungan
    .findOne({
      where: {
        kun_id,
      },
      include: [
        {
          model: models.ihs_encounter,
          required: true,
          as: "ihs_encounter",
        },
        {
          model: models.ihs_practioner,
          required: true,
          as: "ihs_practioner",
          include: {
            model: models.pegawai,
            as: "pegawai",
            required: true,
          },
        },
      ],
    })
    .then((kunjungan) => {
      if (!kunjungan) {
        throw new Error("Kunjungan Tidak Ditemukan");
      }
      return models.billing
        .findAll({
          where: {
            bill_tgl: kunjungan.kun_tgl,
            bill_id_pasien: kunjungan.kun_id_pasien,
            bill_tabel: {
              [Op.or]: ["laboratrium", "radiologi"],
            },
          },
          include: [
            {
              model: models.ref_icd9,
              required: true,
            },
            {
              model: models.ihs_pasien,
              required: true,
              include: {
                model: models.asp_pasien,
                as: "asp_pasien",
                required: true,
                attributes: ["ps_id", "ps_namalengkap"],
              },
            },
          ],
        })
        .then((billing) => {
          if (billing.length === 0) {
            throw new Error("Tidak ada prosedur dilakukan terhadap kunjungan");
          }
          let promises = [];
          billing.map((item) => {
            body = {
              ...body,
              code: {
                coding: [
                  {
                    system: "http://hl7.org/fhir/sid/icd-9-cm",
                    code: item.ref_icd9.ref_icd9_kode,
                    display: item.ref_icd9.ref_icd9_deskripsi,
                  },
                ],
              },
              subject: {
                reference: `Patient/${item.ihs_pasien.pasien_id}`,
                display: item.ihs_pasien.asp_pasien.ps_namalengkap,
              },
              encounter: {
                reference: `Encounter/${kunjungan.ihs_encounter.encounter_id}`,
                display: `Tindakan ${
                  item.ref_icd9.ref_icd9_deskripsi
                } pada ${moment(item.bill_waktu).format("YYYY-MM-DD")}`,
              },
              performedPeriod: {
                start: moment(item.bill_waktu).format(),
                end: moment(item.bill_waktu).add(10, "minutes").format(),
              },
              performer: [
                {
                  actor: {
                    reference: `Practitioner/${kunjungan.ihs_practioner.practioner_id}`,
                    display: kunjungan.ihs_practioner.pegawai.peg_nama,
                  },
                },
              ],
            };
            // promises.push(body);
            promises.push(sendData(body, item.bill_id_rec, kun_id));
          });
          //   return promises;
          return Promise.all(promises);
        });
    });
};

exports.addProcedure = (req, res) => {
  const { kun_id } = req.body;
  if (!kun_id) {
    return error(req, res, "", "Isi Kunjungan", 400, null);
  }
  let promiseTambah = new Promise((resolve, reject) => {
    resolve(
      this.funcAddProcedure({
        kun_id,
      })
    );
  });

  return promiseTambah
    .then((payload) => {
      return success(req, res, payload, "Berhasil menambah observation");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal menambah observation", 500, err);
    });
};
