const { sequelize } = require("../../../models");
const { Op } = require("sequelize");
const models = require("../../../models");
const { funcAddCondition } = require("./conditionController");
const { funcAddEncounter } = require("./encounterController");
const { pagination } = require("../../../helpers/utility/common");
const { globalLogger } = require("../../../helpers/utility/logger");
const { success, error } = require("../../../helpers/utility/response");
const { funcAddObservation } = require("./observationController");
const { funcAddComposition } = require("./compositionController");

exports.kunjunganPasien = (tgl, page, limitGlobal) => {
  let cond = {
    include: [
      {
        model: models.ihs_layanan_location,
        as: "ihs_layanan_location",
        required: true,
      },
      {
        model: models.ihs_encounter,
        as: "ihs_encounter",
        // where: sequelize.literal(
        //   "ihs_encounter.ihs_encounter_id IS NOT NULL"
        // ),
      },
    ],
    // limit,
    // offset,
    where: {
      [Op.and]: [
        {
          kun_tgl: tgl,
        },
        {
          [Op.col]: sequelize.literal("ihs_encounter.ihs_encounter_id IS NULL"),
        },
        // {
        //   kun_id: 11088304,
        // },
        // {
        //   kun_id_layanan: 14,
        // },
        {
          kun_id_dokter: { [Op.not]: 100080 },
        },
      ],
    },
  };

  if (page != null) {
    const { limit, offset } = pagination(page > 0 ? page : 1, limitGlobal);
    cond = {
      ...cond,
      limit,
      offset,
    };
  }
  return models.kunjungan[page == null ? "count" : "findAll"](cond);
};

exports.funcSyncAuto = (tgl, succ, fail, page, limit) => {
  console.log("==================" + page + "==================");
  if (page < 0) {
    return "Complete";
  }
  const startKirim = (payload) => {
    return funcAddEncounter({
      rkun_id: payload.kun_id_rencana_kunjungan,
    }).then(() => {
      if (payload.kun_tervalidasi == true) {
        return funcAddCondition({
          kun_id: payload.kun_id,
        })
          .finally(() => {
            return funcAddObservation({
              kun_id: payload.kun_id,
            });
          })
          .finally(() => {
            return funcAddComposition({
              kun_id: payload.kun_id,
            });
          });
      }
    });
  };
  return this.kunjunganPasien(tgl, page, limit)
    .then((payload) => {
      if (!payload) {
        throw new Error("Sudah Encounter");
      }
      let promises = [];
      payload.map((item) => {
        return promises.push(
          startKirim(item)
            .then(() => {
              console.log("BERHASIL SYNC: " + item.kun_id);
              succ({
                kun_id: item.kun_id,
              });
            })
            .catch((err) => {
              console.log("GAGAL SYNC: " + item.kun_id);
              fail({
                kun_id: item.kun_id,
              });
              throw err;
            })
            .finally(() => new Promise((resolve) => setTimeout(resolve, 1000)))
        );
      });
      return Promise.all(promises);
    })
    .then(() => {})
    .catch((err) => {
      globalLogger(err);
    })
    .finally(() => {
      return this.funcSyncAuto(tgl, succ, fail, page - 1, limit);
    });
};

exports.autoSync = (req, res) => {
  const { tgl, limit } = req.query;
  let arr = [];
  let arrFailed = [];
  if (!tgl) {
    return error(req, res, "", "Isi Tgl", 400, null);
  }
  if (!limit) {
    return error(req, res, "", "Isi Limit", 400, null);
  }

  return this.kunjunganPasien(tgl, null, limit).then((payload) => {
    if (payload == 0) {
      return res.json("NO DATA");
    }
    console.log(payload);

    let page = Math.ceil(payload / limit);
    console.log("==================" + "START" + "==================");
    console.log("==================" + page + "==================");

    return this.funcSyncAuto(
      tgl,
      (val) => arr.push(val),
      (val) => arrFailed.push(val),
      page,
      limit
    ).then(() => {
      return res.json({
        messagge: "Completed",
        success: arr,
        failed: arrFailed,
      });
    });
  });
};
