const axiosIHS = require("../../../helpers/axios/axiosIHS");
const moment = require("moment");
const { error, success } = require("../../../helpers/utility/response");
const models = require("../../../models");

const parseLoincTTV = () => {};

exports.funcAddObservation = ({ kun_id }) => {
  if (!kun_id) {
    throw new Error("Isi KUN ID");
  }
  let waktu = moment().format();
  let body = {
    resourceType: "Observation",
    status: "final",
    category: [
      {
        coding: [
          {
            system:
              "http://terminology.hl7.org/CodeSystem/observation-category",
            code: "vital-signs",
            display: "Vital Signs",
          },
        ],
      },
    ],
    code: {
      // coding: [
      //   {
      //     system: "http://loinc.org",
      //     code: loinc_code,
      //     display: "Heart rate",
      //   },
      // ],
    },
    // subject: {
    //     reference: "Patient/P00030004",
    // },
    // encounter: {
    //     reference: "Encounter/2823ed1d-3e3e-434e-9a5b-9c579d192787",
    //     display:
    //         "Pemeriksaan Fisik Nadi Budi Santoso di hari Selasa, 14 Juni 2022",
    // },
    effectiveDateTime: waktu,
    // valueQuantity: {
    //   value: Number(value),
    //   unit: "beats/minute",
    //   system: "http://unitsofmeasure.org",
    //   code: "/min",
    // },
  };
  return (
    models.kunjungan
      .findOne({
        where: {
          kun_id,
        },
        attributes: ["kun_id"],
        include: [
          {
            required: true,
            model: models.asesmen_awal_rajal,
            as: "asesmen_awal_rajal",
            attributes: [
              "assmn_awl_id",
              "assmn_awl_id_kun",
              "assmn_awl_rjl_pf_tknan_drah",
              "assmn_awl_rjl_pf_tknan_drah_2",
              "assmn_awl_rjl_pf_nadi",
              "assmn_awl_rjl_pf_napas",
              "assmn_awl_rjl_pf_suhu",
            ],
          },
          {
            required: true,
            model: models.rencana_kunjungan,
            as: "rencana_kunjungan",
            attributes: [
              "rkun_id",
              "rkun_id_layanan",
              "rkun_tgl_visit",
              "rkun_id_dokter",
            ],
            include: [
              {
                model: models.ihs_encounter,
                as: "ihs_encounter",
                required: true,
              },
              {
                model: models.ihs_pasien,
                as: "ihs_pasien",
                required: true,
                include: {
                  model: models.asp_pasien,
                  required: true,
                  as: "asp_pasien",
                  attributes: ["ps_id", "ps_namalengkap"],
                },
              },
            ],
          },
        ],
      })
      // return models.rencana_kunjungan
      //   .findOne({
      //     where: {
      //       rkun_id: rkun_id,
      //     },
      //     attributes: [
      //       "rkun_id",
      //       "rkun_id_layanan",
      //       "rkun_tgl_visit",
      //       "rkun_id_dokter",
      //     ],
      //     include: [
      //       {
      //         model: models.ihs_encounter,
      //         as: "ihs_encounter",
      //         required: true,
      //       },
      //       {
      //         model: models.ihs_pasien,
      //         as: "ihs_pasien",
      //         required: true,
      //         include: {
      //           model: models.asp_pasien,
      //           required: true,
      //           as: "asp_pasien",
      //           attributes: ["ps_id", "ps_namalengkap"],
      //         },
      //       },
      //     ],
      //   })
      .then((kun) => {
        if (!kun) {
          throw new Error("Kunjungan Tidak ditemukan");
        }

        let url = "/Observation";
        let promises = [];
        const sendData = (body, type) => {
          return axiosIHS
            .post(url, body)
            .then((payload) => {
              return models.ihs_observation
                .create({
                  observe_id: payload.data.id ?? null,
                  kun_id,
                  observe_type: type,
                })
                .then((data) => {
                  return data;
                });
              // .catch((err) => {
              //   console.log(err);
              // });
            })
            .catch((err) => {
              console.log(err);
            });
        };
        if (kun.asesmen_awal_rajal.assmn_awl_rjl_pf_nadi) {
          body = {
            ...body,
            subject: {
              reference: `Patient/${kun.rencana_kunjungan.ihs_pasien.pasien_id}`,
            },
            encounter: {
              reference: `Encounter/${kun.rencana_kunjungan.ihs_encounter.encounter_id}`,
              display: `Pemeriksaan Fisik ${waktu}`,
            },
            code: {
              coding: [
                {
                  system: "http://loinc.org",
                  code: "8867-4",
                  display: "Heart rate",
                },
              ],
            },
            valueQuantity: {
              value: Number(kun.asesmen_awal_rajal.assmn_awl_rjl_pf_nadi),
              unit: "beats/minute",
              system: "http://unitsofmeasure.org",
              code: "/min",
            },
          };
          promises.push(sendData(body, "heart_rate"));
        }

        if (kun.asesmen_awal_rajal.assmn_awl_rjl_pf_suhu) {
          body = {
            ...body,
            subject: {
              reference: `Patient/${kun.rencana_kunjungan.ihs_pasien.pasien_id}`,
            },
            encounter: {
              reference: `Encounter/${kun.rencana_kunjungan.ihs_encounter.encounter_id}`,
              display: `Pemeriksaan Fisik ${waktu}`,
            },
            code: {
              coding: [
                {
                  system: "http://loinc.org",
                  code: "8310-5",
                  display: "Body Temperature",
                },
              ],
            },
            valueQuantity: {
              value: Number(kun.asesmen_awal_rajal.assmn_awl_rjl_pf_nadi),
              unit: "C",
              system: "http://unitsofmeasure.org",
              code: "Cel",
            },
          };
          promises.push(sendData(body, "body_temp"));
        }
        if (kun.asesmen_awal_rajal.assmn_awl_rjl_pf_napas) {
          body = {
            ...body,
            subject: {
              reference: `Patient/${kun.rencana_kunjungan.ihs_pasien.pasien_id}`,
            },
            encounter: {
              reference: `Encounter/${kun.rencana_kunjungan.ihs_encounter.encounter_id}`,
              display: `Pemeriksaan Fisik ${waktu}`,
            },
            code: {
              coding: [
                {
                  system: "http://loinc.org",
                  code: "3151-8",
                  display: "Oxygen",
                },
              ],
            },
            valueQuantity: {
              value: Number(kun.asesmen_awal_rajal.assmn_awl_rjl_pf_napas),
              unit: "beats/minute",
              system: "http://unitsofmeasure.org",
              code: "/min",
            },
          };
          promises.push(sendData(body, "oxygen"));
        }
        if (kun.asesmen_awal_rajal.assmn_awl_rjl_pf_tknan_drah) {
          body = {
            ...body,
            subject: {
              reference: `Patient/${kun.rencana_kunjungan.ihs_pasien.pasien_id}`,
            },
            encounter: {
              reference: `Encounter/${kun.rencana_kunjungan.ihs_encounter.encounter_id}`,
              display: `Pemeriksaan Fisik ${waktu}`,
            },
            code: {
              coding: [
                {
                  system: "http://loinc.org",
                  code: "8480-6",
                  display: "Systolic blood pressure",
                },
              ],
            },
            valueQuantity: {
              value: Number(kun.asesmen_awal_rajal.assmn_awl_rjl_pf_tknan_drah),
              unit: "mm[Hg]",
              system: "http://unitsofmeasure.org",
              code: "mm[Hg]",
            },
          };
          promises.push(sendData(body, "systolic_blood"));
        }
        if (kun.asesmen_awal_rajal.assmn_awl_rjl_pf_tknan_drah_2) {
          body = {
            ...body,
            subject: {
              reference: `Patient/${kun.rencana_kunjungan.ihs_pasien.pasien_id}`,
            },
            encounter: {
              reference: `Encounter/${kun.rencana_kunjungan.ihs_encounter.encounter_id}`,
              display: `Pemeriksaan Fisik ${waktu}`,
            },
            code: {
              coding: [
                {
                  system: "http://loinc.org",
                  code: "8462-4",
                  display: "Diastolic blood pressure",
                },
              ],
            },
            valueQuantity: {
              value: Number(kun.asesmen_awal_rajal.assmn_awl_rjl_pf_tknan_drah),
              unit: "mm[Hg]",
              system: "http://unitsofmeasure.org",
              code: "mm[Hg]",
            },
          };
          promises.push(sendData(body, "diastolic_blood"));
        }
        return Promise.all(promises)
          .then((data) => {
            return data;
          })
          .catch((err) => {
            return [];
          });
      })
  );
};

exports.addObservation = (req, res) => {
  const { kun_id } = req.body;
  if (!kun_id) {
    return error(req, res, "", "Isi Kunjungan", 400, null);
  }
  let promiseTambah = new Promise((resolve, reject) => {
    resolve(
      this.funcAddObservation({
        kun_id,
      })
    );
  });

  return promiseTambah
    .then((payload) => {
      return success(req, res, payload, "Berhasil menambah observation");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal menambah observation", 500, err);
    });
};
