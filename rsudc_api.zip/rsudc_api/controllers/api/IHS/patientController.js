const axiosIHS = require("../../../helpers/axios/axiosIHS");
const CustomError = require("../../../helpers/utility/customError");
const { success, error } = require("../../../helpers/utility/response");
const models = require("../../../models");
const { Op } = require("sequelize");

exports.funcGetPasienByID = ({ ps_id }) => {
  if (!ps_id) {
    throw new Error("Input ID");
  }
  return models.asp_pasien
    .findOne({
      where: {
        ps_id,
        // ps_nomor_identitas: {
        //   [Op.not]: null,
        // },
      },
      include: {
        model: models.ihs_pasien,
        as: "ihs_pasien",
      },
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Pasien Tidak Ditemukan");
      }
      let pasien = payload.get({ plain: true });
      if (pasien.ihs_pasien) {
        return {
          ps_id: pasien.ihs_pasien.pasien_id,
          ps_nama: payload.ps_namalengkap,
        };
      } else if (!pasien.ihs_pasien && pasien.ps_nomor_identitas) {
        return this.funcGetPasienByNIK({
          nik: pasien.ps_nomor_identitas,
        }).then((ps) => {
          return {
            ps_id: ps.id,
            ps_nama: pasien.ps_namalengkap,
          };
        });
      } else {
        throw new Error("Data Pasien Kosong");
      }
    });
};

exports.funcGetPasienByNIK = ({ nik }) => {
  if (!nik) {
    throw new Error("Isi NIK");
  }
  const url = `/Patient?identifier=https://fhir.kemkes.go.id/id/nik|${nik}`;

  return models.asp_pasien
    .findOne({
      where: {
        ps_nomor_identitas: nik,
      },
      include: {
        model: models.ihs_pasien,
        required: false,
        as: "ihs_pasien",
      },
    })
    .then((asp_pasien) => {
      if (!asp_pasien) {
        throw new Error("NIK Pasien tidak ditemukan.");
      } else if (!asp_pasien.ihs_pasien) {
        return axiosIHS.get(url).then((payload) => {
          // console.log(payload.data)
          if (
            !payload.data ||
            payload.data.total === 0
            // || payload.status !== 201
          ) {
            throw new Error("Gagal memuat pasien");
          }
          return models.ihs_pasien
            .findOne({
              where: {
                ps_id: asp_pasien.ps_id,
              },
            })
            .then((ps) => {
              if (!ps) {
                return models.ihs_pasien
                  .create({
                    ps_id: asp_pasien.ps_id,
                    pasien_id: payload.data.entry[0].resource.id,
                  })
                  .then((ihs_pasien) => {
                    return {
                      id: ihs_pasien.pasien_id,
                    };
                  });
              }
              ps.pasien_id = payload.data.entry[0].resource.id;
              ps.save();
              return {
                id: ps.pasien_id,
              };
            });
        });
      } else if (asp_pasien.ihs_pasien) {
        return {
          id: asp_pasien.ihs_pasien.pasien_id,
        };
      } else {
        throw new Error("Ada kesalahan.");
      }
    });
};

exports.getPasienByNIK = (req, res) => {
  const { nik } = req.query;
  if (!nik) {
    return error(req, res, "", "Isi NIK", 400);
  }

  return this.funcGetPasienByNIK({ nik })
    .then((payload) => {
      return success(req, res, payload, "Berhasil mendapatkan pasien");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal mendaptkan pasien", 500, err);
    });
};

exports.funcGetPasienData = ({ patient_id }) => {
  if (!patient_id) {
    throw new Error("Isi ID Pasien");
  }
  const url = `/Patient/${patient_id}`;
  return axiosIHS.get(url);
};

exports.getPasienData = (req, res) => {
  const { patient_id } = req.query;
  if (!patient_id) {
    return error(req, res, "", "Gagal mendaptkan pasien", 400, err);
  }
  return this.funcGetPasienData({ patient_id })
    .then((payload) => {
      if (!payload.data) {
        throw new Error("Gagal memuat pasien");
      }
      return success(req, res, payload.data, "Berhasil mendapatkan pasien");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal mendaptkan pasien", 500, err);
    });
};
