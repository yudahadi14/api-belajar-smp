const {
  funcGetPasienByNIK,
  funcGetPasienByID,
} = require("./patientController");
const axiosIHS = require("../../../helpers/axios/axiosIHS");
// const CustomError = require("../../../helpers/utility/customError");
const { success, error } = require("../../../helpers/utility/response");
const models = require("../../../models");
const moment = require("moment");
const { Op } = require("sequelize");
const sequelize = require("sequelize");
const {
  funcGetPractionerByNIK,
  funcGetPractionerByID,
} = require("./practionerController");
const { response } = require("express");

exports.reqMedication = (req, res) => {
  const { rsp_poli_id } = req.query;
  const body = {
    resourceType: "Medication",
    meta: {
      profile: ["https://fhir.kemkes.go.id/r4/StructureDefinition/Medication"],
    },
    identifier: [
      {
        system: `http://sys-ids.kemkes.go.id/medication/${process.env.IHS_ORGANIZATION}`,
        use: "official",
        value: rsp_poli_id,
      },
    ],
    status: "active",
    manufacturer: {
      reference: `Organization/${process.env.IHS_ORGANIZATION}`,
    },
    extension: [
      {
        url: "https://fhir.kemkes.go.id/r4/StructureDefinition/MedicationType",
        valueCodeableConcept: {
          coding: [
            {
              system:
                "https://terminology.kemkes.go.id/CodeSystem/medication-type",
              code: "NC",
              display: "Non-compound",
            },
          ],
        },
      },
    ],
  };
  return models.resep_poli
    .findOne({
      where: {
        rsp_poli_id,
      },
      include: [
        {
          model: models.icd,
          required: true,
          as: "icd",
        },
        {
          model: models.obat_ihs,
          required: true,
          as: "obat_ihs",
        },
        {
          model: models.ref_produk,
          required: true,
          as: "ref_produk",
        },
        {
          model: models.kunjungan,
          required: true,
          as: "kunjungan",
          include: {
            model: models.ihs_encounter,
            required: true,
            as: "ihs_encounter",
          },
        },
      ],
    })
    .then((resep) => {
      return res.json(resep);
      body.code = {
        coding: [
          {
            system: "http://sys-ids.kemkes.go.id/kfa",
            code: resep.obat_ihs.obat_ihs_kode_ingredients,
            display: resep.ref_prod_nama,
            // display:
          },
        ],
      };
      body.form = {
        coding: [
          {
            system:
              "https://terminology.kemkes.go.id/CodeSystem/medication-form",
            code: resep.obat_ihs.obat_ihs_bentuk_ihs,
            display: resep.obat_ihs.obat_ihs_bentuk,
          },
        ],
      };
      body.ingredient = [
        {
          itemCodeableConcept: {
            coding: [
              {
                system: "http://sys-ids.kemkes.go.id/kfa",
                code: resep.obat_ihs.obat_ihs_bentuk_ihs,
                display: resep.obat_ihs.obat_ihs_bentuk,
              },
            ],
          },
          isActive: true,
          strength: {
            numerator: {
              value: Number(resep.obat_ihs.obat_ihs_numerator_val),
              system: "http://unitsofmeasure.org",
              code: resep.obat_ihs.obat_ihs_numerator,
            },
            denominator: {
              value: resep.obat_ihs.obat_ihs_denominator_val
                ? resep.obat_ihs.obat_ihs_denominator_val
                : 1,
              system:
                "http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm",
              code: resep.obat_ihs.obat_ihs_denominator
                ? resep.obat_ihs.obat_ihs_denominator
                : "TAB",
            },
          },
        },
      ];
      const url = "/Medication";
      return axiosIHS.post(url, body).then((ihs) => {
        if (ihs.data && ihs.data.id) {
          return models.ihs_medication
            .create({
              medication_id: ihs.data.id,
              rsp_poli_id,
              ihs_medication_type: 1,
            })
            .then(() => {
              return Promise.all([
                funcGetPasienByID({
                  ps_id: "314525",
                }).then((ps) => {
                  return {
                    reference: ps.ps_id,
                    display: ps.ps_nama,
                  };
                }),
                funcGetPractionerByID({
                  peg_id: "100248",
                }).then((dokter) => {
                  return {
                    reference: dokter.peg_id,
                    display: dokter.peg_nama,
                  };
                }),
              ]);
            })
            .then((data) => {
              return this.funcRequestMed({
                rsp_poli_id,
                medication_id: ihs.data.id,
                medication_display: resep.ref_prod_nama,
                rute_obat_code: resep.obat_ihs.obat_ihs_rute,
                rute_obat_display: resep.obat_ihs.obat_ihs_rute,
                icd_10: resep.icd.icd_code,
                icd_10_display: resep.icd.icd_catatan,
                patient_id: data[0].reference,
                patient_name: data[0].display,
                practioner_id: data[1].reference,
                practioner_name: data[1].display,
                rsp_hari: resep.rsp_hari,
                rsp_qty_prod: resep.rsp_qty_prod,
                rsp_jml_mnum: resep.rsp_jml_mnum,
                encounter_id: resep.kunjungan.ihs_encounter.encounter_id,
                rsp_wkt_mnum: resep.rsp_wkt_mnum,
                obat_ihs_denominator: resep.obat_ihs.obat_ihs_denominator
                  ? resep.obat_ihs.obat_ihs_denominator
                  : "TAB",
              });

              //   return this.funcRequestMed({
              //     rsp_poli_id,
              //     medication_id: ihs.data.id,
              //     medication_display: resep.ref_prod_nama,
              //     rute_obat_code: resep.obat_ihs.obat_ihs_rute,
              //     rute_obat_display: resep.obat_ihs.obat_ihs_rute,
              //     icd_10: resep.icd.icd_code,
              //     icd_10_display: resep.icd.icd_catatan,
              //     patient_id: data[0].reference,
              //     patient_name: data[0].display,
              //     practioner_id: data[1].reference,
              //     practioner_name: data[1].display,
              //     rsp_hari: resep.rsp_hari,
              //     rsp_qty_prod: resep.rsp_qty_prod,
              //     rsp_jml_mnum: resep.rsp_jml_mnum,
              //     encounter_id: "326733f1-eb2d-4088-9add-e500ab1b0981",
              //     rsp_wkt_mnum: resep.rsp_wkt_mnum,
              //   });
            });
        }
      });
    })
    .then((payload) => {
      return success(req, res, payload, "Berhasil");
    })
    .catch((err) => {
      // console.log(rsp_poli_id);
      // console.log(err.response.data.issue);
      // return res.json(err.response.data);
      return error(req, res, "", "Ada Kesalahan", 500, err);
    });
};

exports.funcRequestMed = ({
  rsp_poli_id,
  medication_id,
  medication_display,
  rute_obat_code,
  rute_obat_display,
  icd_10,
  icd_10_display,
  patient_id,
  patient_name,
  practioner_id,
  practioner_name,
  rsp_hari,
  rsp_qty_prod,
  rsp_jml_mnum,
  encounter_id,
  rsp_wkt_mnum,
  obat_ihs_denominator,
}) => {
  const body = {
    resourceType: "MedicationRequest",
    identifier: [
      {
        system: `http://sys-ids.kemkes.go.id/prescription/${process.env.IHS_ORGANIZATION}`,
        use: "official",
        value: rsp_poli_id,
      },
      {
        system: `http://sys-ids.kemkes.go.id/prescription-item/${process.env.IHS_ORGANIZATION}`,
        use: "official",
        value: rsp_poli_id,
      },
    ],
    status: "completed",
    intent: "order",
    category: [
      {
        coding: [
          {
            system:
              "http://terminology.hl7.org/CodeSystem/medicationrequest-category",
            code: "outpatient",
            display: "Outpatient",
          },
        ],
      },
    ],
    priority: "routine",
    medicationReference: {
      reference: `Medication/${medication_id}`,
      display: medication_display,
    },
    subject: {
      reference: `Patient/${patient_id}`,
      display: patient_name,
    },
    encounter: {
      reference: `Encounter/${encounter_id}`,
    },
    authoredOn: moment().format("YYYY-MM-DD"),
    requester: {
      reference: `Practitioner/${practioner_id}`,
      display: practioner_name,
    },
    reasonCode: [
      {
        coding: [
          {
            system: "http://hl7.org/fhir/sid/icd-10",
            code: icd_10,
            display: icd_10_display,
          },
        ],
      },
    ],
    courseOfTherapyType: {
      coding: [
        {
          system:
            "http://terminology.hl7.org/CodeSystem/medicationrequest-course-of-therapy",
          code: "continuous",
          display: "Continuing long term therapy",
        },
      ],
    },
    dosageInstruction: [
      {
        sequence: 1,
        text: `${rsp_wkt_mnum} tablet per hari`,
        additionalInstruction: [
          {
            text: "Diminum setiap hari",
          },
        ],
        patientInstruction: "Diminum",
        timing: {
          repeat: {
            frequency: rsp_wkt_mnum,
            period: 1,
            periodUnit: "d",
          },
        },
        route: {
          coding: [
            {
              system: "http://www.whocc.no/atc",
              code: rute_obat_code,
              display: rute_obat_display,
            },
          ],
        },
        doseAndRate: [
          {
            type: {
              coding: [
                {
                  system:
                    "http://terminology.hl7.org/CodeSystem/dose-rate-type",
                  code: "ordered",
                  display: "Ordered",
                },
              ],
            },
            doseQuantity: {
              value: rsp_jml_mnum,
              unit: obat_ihs_denominator,
              system:
                "http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm",
              code: obat_ihs_denominator,
            },
          },
        ],
      },
    ],
    dispenseRequest: {
      dispenseInterval: {
        value: 1,
        unit: "days",
        system: "http://unitsofmeasure.org",
        code: "d",
      },
      validityPeriod: {
        start: moment().format("YYYY-MM-DD"),
        end: moment().add(rsp_hari, "days").format("YYYY-MM-DD"),
      },
      numberOfRepeatsAllowed: 0,
      quantity: {
        value: rsp_qty_prod,
        unit: obat_ihs_denominator,
        system: "http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm",
        code: obat_ihs_denominator,
      },
      expectedSupplyDuration: {
        value: rsp_hari,
        unit: "days",
        system: "http://unitsofmeasure.org",
        code: "d",
      },
      performer: {
        reference: `Organization/${process.env.IHS_ORGANIZATION}`,
      },
    },
  };
  const url = "/MedicationRequest";
  return axiosIHS.post(url, body).then((ihs) => {
    if (ihs.data && ihs.data.id) {
      return models.ihs_req_medication.create({
        req_medication_id: ihs.data.id,
        rsp_poli_id,
      });
      // .then((data) => {
      //   return this.funcSpeciment({
      //     mintalab_dt_id: item.identifier[0].value,
      //   });
      // });
    }
  });
  // .catch((err) => {
  //   console.log("ini", obat_ihs_denominator);
  //   console.log(err.response.data.issue);
  // });
};

exports.dispenseMedication = (req, res) => {
  const { rsp_poli_id } = req.query;
  const body = {
    resourceType: "Medication",
    meta: {
      profile: ["https://fhir.kemkes.go.id/r4/StructureDefinition/Medication"],
    },
    identifier: [
      {
        system: `http://sys-ids.kemkes.go.id/medication/${process.env.IHS_ORGANIZATION}`,
        use: "official",
        value: rsp_poli_id,
      },
    ],
    status: "active",
    manufacturer: {
      reference: `Organization/${process.env.IHS_ORGANIZATION}`,
    },
    extension: [
      {
        url: "https://fhir.kemkes.go.id/r4/StructureDefinition/MedicationType",
        valueCodeableConcept: {
          coding: [
            {
              system:
                "https://terminology.kemkes.go.id/CodeSystem/medication-type",
              code: "NC",
              display: "Non-compound",
            },
          ],
        },
      },
    ],
  };
  return models.resep_poli
    .findOne({
      where: {
        rsp_poli_id,
      },
      include: [
        {
          model: models.icd,
          required: true,
          as: "icd",
        },
        {
          model: models.obat_ihs,
          required: true,
          as: "obat_ihs",
        },
        {
          model: models.ref_produk,
          required: true,
          as: "ref_produk",
        },
        {
          model: models.kunjungan,
          required: true,
          as: "kunjungan",
          include: {
            model: models.ihs_encounter,
            required: true,
            as: "ihs_encounter",
          },
        },
        {
          model: models.ihs_req_medication,
          required: true,
          as: "ihs_req_medication",
        },
      ],
    })
    .then((resep) => {
      body.code = {
        coding: [
          {
            system: "http://sys-ids.kemkes.go.id/kfa",
            code: resep.obat_ihs.obat_ihs_kode_ingredients,
            display: resep.ref_prod_nama,
            // display:
          },
        ],
      };
      body.form = {
        coding: [
          {
            system:
              "https://terminology.kemkes.go.id/CodeSystem/medication-form",
            code: resep.obat_ihs.obat_ihs_bentuk_ihs,
            display: resep.obat_ihs.obat_ihs_bentuk,
          },
        ],
      };
      body.ingredient = [
        {
          itemCodeableConcept: {
            coding: [
              {
                system: "http://sys-ids.kemkes.go.id/kfa",
                code: resep.obat_ihs.obat_ihs_bentuk_ihs,
                display: resep.obat_ihs.obat_ihs_bentuk,
              },
            ],
          },
          isActive: true,
          strength: {
            numerator: {
              value: Number(resep.obat_ihs.obat_ihs_numerator_val),
              system: "http://unitsofmeasure.org",
              code: resep.obat_ihs.obat_ihs_numerator,
            },
            denominator: {
              value: resep.obat_ihs.obat_ihs_denominator_val
                ? resep.obat_ihs.obat_ihs_denominator_val
                : 1,
              system:
                "http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm",
              code: resep.obat_ihs.obat_ihs_denominator
                ? resep.obat_ihs.obat_ihs_denominator
                : "TAB",
            },
          },
        },
      ];
      const url = "/Medication";
      return axiosIHS.post(url, body).then((ihs) => {
        if (ihs.data && ihs.data.id) {
          return models.ihs_medication
            .create({
              medication_id: ihs.data.id,
              rsp_poli_id,
              ihs_medication_type: 1,
            })
            .then(() => {
              return Promise.all([
                funcGetPasienByID({
                  ps_id: "314525",
                }).then((ps) => {
                  return {
                    reference: ps.ps_id,
                    display: ps.ps_nama,
                  };
                }),
                funcGetPractionerByID({
                  peg_id: "100248",
                }).then((dokter) => {
                  return {
                    reference: dokter.peg_id,
                    display: dokter.peg_nama,
                  };
                }),
              ]);
            })
            .then((data) => {
              return this.dispense({
                rsp_poli_id,
                medication_id: ihs.data.id,
                medication_display: resep.ref_prod_nama,
                patient_id: data[0].reference,
                patient_name: data[0].display,
                encounter_id: resep.kunjungan.ihs_encounter.encounter_id,
                practioner_id: data[1].reference,
                practioner_name: data[1].display,
                medicaton_req_id: resep.ihs_req_medication.req_medication_id,
                rsp_jml_mnum: resep.rsp_jml_mnum,
                rsp_hari: resep.rsp_hari,
                obat_ihs_denominator: resep.obat_ihs.obat_ihs_denominator
                  ? resep.obat_ihs.obat_ihs_denominator
                  : "TAB",
                rsp_wkt_mnum: resep.rsp_wkt_mnum,
                rsp_qty_prod: resep.rsp_qty_prod,
              });

              //   return this.funcRequestMed({
              //     rsp_poli_id,
              //     medication_id: ihs.data.id,
              //     medication_display: resep.ref_prod_nama,
              //     rute_obat_code: resep.obat_ihs.obat_ihs_rute,
              //     rute_obat_display: resep.obat_ihs.obat_ihs_rute,
              //     icd_10: resep.icd.icd_code,
              //     icd_10_display: resep.icd.icd_catatan,
              //     patient_id: data[0].reference,
              //     patient_name: data[0].display,
              //     practioner_id: data[1].reference,
              //     practioner_name: data[1].display,
              //     rsp_hari: resep.rsp_hari,
              //     rsp_qty_prod: resep.rsp_qty_prod,
              //     rsp_jml_mnum: resep.rsp_jml_mnum,
              //     encounter_id: "326733f1-eb2d-4088-9add-e500ab1b0981",
              //     rsp_wkt_mnum: resep.rsp_wkt_mnum,
              //   });
            });
        }
      });
    })
    .then((payload) => {
      return success(req, res, payload, "Berhasil");
    })
    .catch((err) => {
      return error(req, res, "", "Ada Kesalahan", 500, err);
    });
};

exports.dispense = ({
  rsp_poli_id,
  medication_id,
  medication_display,
  patient_id,
  patient_name,
  encounter_id,
  practioner_id,
  practioner_name,
  medicaton_req_id,
  rsp_jml_mnum,
  rsp_hari,
  obat_ihs_denominator,
  rsp_wkt_mnum,
  rsp_qty_prod,
}) => {
  const body = {
    resourceType: "MedicationDispense",
    identifier: [
      {
        system: `http://sys-ids.kemkes.go.id/prescription/${process.env.IHS_ORGANIZATION}`,
        use: "official",
        value: rsp_poli_id,
      },
      {
        system: `http://sys-ids.kemkes.go.id/prescription-item/${process.env.IHS_ORGANIZATION}`,
        use: "official",
        value: rsp_poli_id,
      },
    ],
    status: "completed",
    category: {
      coding: [
        {
          system:
            "http://terminology.hl7.org/fhir/CodeSystem/medicationdispense-category",
          code: "outpatient",
          display: "Outpatient",
        },
      ],
    },
    medicationReference: {
      reference: `Medication/${medication_id}`,
      display: medication_display,
    },
    subject: {
      reference: `Patient/${patient_id}`,
      display: patient_name,
    },
    context: {
      reference: `Encounter/${encounter_id}`,
    },
    performer: [
      {
        actor: {
          reference: `Practitioner/${practioner_id}`,
          display: practioner_name,
        },
      },
    ],
    location: {
      reference: "Location/52e135eb-1956-4871-ba13-e833e662484d",
      display: "Apotek RSUD Jati Asih",
    },
    authorizingPrescription: [
      {
        reference: `MedicationRequest/${medicaton_req_id}`,
      },
    ],
    quantity: {
      system: "http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm",
      code: obat_ihs_denominator ? obat_ihs_denominator : "TAB",
      value: rsp_qty_prod,
    },
    daysSupply: {
      value: rsp_hari,
      unit: "Day",
      system: "http://unitsofmeasure.org",
      code: "d",
    },
    whenPrepared: moment().format(),
    whenHandedOver: moment().format(),
    dosageInstruction: [
      {
        sequence: 1,
        text: "Diminum",
        timing: {
          repeat: {
            frequency: rsp_wkt_mnum,
            period: 1,
            periodUnit: "d",
          },
        },
        doseAndRate: [
          {
            type: {
              coding: [
                {
                  system:
                    "http://terminology.hl7.org/CodeSystem/dose-rate-type",
                  code: "ordered",
                  display: "Ordered",
                },
              ],
            },
            doseQuantity: {
              value: rsp_jml_mnum,
              unit: "TAB",
              system:
                "http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm",
              code: obat_ihs_denominator ? obat_ihs_denominator : "TAB",
            },
          },
        ],
      },
    ],
  };
  const url = "/MedicationDispense";
  return axiosIHS.post(url, body).then((ihs) => {
    if (ihs.data && ihs.data.id) {
      return models.ihs_dispense_medication.create({
        dispense_medication_id: ihs.data.id,
        rsp_poli_id,
      });
      // .then((data) => {
      //   return this.funcSpeciment({
      //     mintalab_dt_id: item.identifier[0].value,
      //   });
      // });
    }
  });
};
