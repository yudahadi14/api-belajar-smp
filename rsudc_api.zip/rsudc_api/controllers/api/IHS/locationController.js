const axiosIHS = require("../../../helpers/axios/axiosIHS");
const { success, error } = require("../../../helpers/utility/response");
const models = require("../../../models");
const { locationType } = require("./variables");

exports.funcAddLocation = ({
  ref_layanan_id,
  organization_id,
  root_location_id,
  location_code,
}) => {
  // --A. Kegunaan : Untuk nambah struktur lokasi
  // --B. HOW TO :
  // 1. Semua field wajib kecuali root_location_id
  // 2. Isi root_location_id jika sebagai anak (location id IHS)
  // 3. Isi location_code (lihat manual PDF IHS)
  // --C. MINUS :
  // 1. optional valu belum

  if (!ref_layanan_id) {
    throw new Error("Isi Layanan ID!");
  }
  if (!organization_id) {
    throw new Error("Isi Orgnaization ID!");
  }
  if (!location_code) {
    throw new Error("Isi Location Code!");
  }
  let body = {
    resourceType: "Location",
    // identifier: [
    //   {
    //     system: "http://sys-ids.kemkes.go.id/location/1000001",
    //     value: "G-2-R-1A",
    //   },
    // ],
    status: "active",
    // operationalStatus: {
    //   system: "http://terminology.hl7.org/CodeSystem/v2-0116",
    //   code: "io",
    //   display: "room",
    // },
    // name: "Poli Jantung",
    // description: "Poli Jantung",
    // mode: "instance",
    // telecom: [
    //   {
    //     system: "phone",
    //     value: "+6221-54372874",
    //     use: "work",
    //   },
    //   {
    //     system: "email",
    //     value: "simcrew@gmail.com",
    //     use: "work",
    //   },
    //   {
    //     system: "url",
    //     value: "www.rsudcengkareng.com",
    //     use: "work",
    //   },
    // ],
    physicalType: {
      coding: [locationType({ type: location_code })],
    },
    position: {
      longitude: -6.142857563575358,
      latitude: 106.73471631969804,
      altitude: 0,
    },
    // managingOrganization: {
    //   reference: `Organization/${organization_id}`,
    // },
    // partOf: {
    //   reference: "Organization/10000182",
    //   display: "RSUD Cengkareng",
    // },
  };
  const url = "/Location";
  return models.ref_layanan
    .findOne({
      where: {
        ref_layanan_id,
      },
      // include: {
      //   model: models.ihs_layanan_location,
      //   as: "layanan_location",
      //   required: true,
      //   // include: {
      //   //   model: models.ihs_location,
      //   //   as: "location",
      //   //   required: true,
      //   //   // include: {
      //   //   //   model: models.ihs_organization,
      //   //   //   as: "organization",
      //   //   //   required: true,
      //   //   // },
      //   // },
      // },
    })
    .then((layanan) => {
      if (!layanan) {
        throw new Error("Data tidak ditemukan");
      }
      if (root_location_id) {
        body = {
          ...body,
          partOf: {
            reference: `Location/${root_location_id}`,
            // display: "RSUD Cengkareng",
          },
        };
      }
      return models.ihs_organization
        .findOne({
          where: {
            ihs_organization_id: organization_id,
          },
        })
        .then((org) => {
          if (!org) {
            throw new Error("Organization tidak ditemukan");
          }
          return axiosIHS.post(url, {
            ...body,
            name: layanan.ref_layanan_nama,
            description: layanan.ref_layanan_nama,
            managingOrganization: {
              reference: `Organization/${org.organization_id}`,
            },
          });
        })
        .then((payload) => {
          if (Number(payload.status) !== 201) {
            throw new Error("Gagal Insert Lokasi");
          }
          return models.ihs_location.create(
            {
              location_id: payload.data.id,
              location_name: layanan.ref_layanan_nama,
              root_location_id: layanan.layanan_location
                ? layanan.layanan_location.ihs_location_id
                : null,
              ihs_organization_id: organization_id,
              layanan_location: {
                ref_layanan_id: ref_layanan_id,
              },
            },
            {
              include: [
                {
                  association:
                    models.ihs_location.associations.layanan_location,
                  //   as: "layanan_location",
                },
              ],
            }
          );
        });
    });
};

exports.addLocation = (req, res) => {
  const { ref_layanan_id, organization_id, location_code, root_location_id } =
    req.body;
  if (!ref_layanan_id) {
    return error(req, res, "", "Isi Layanan ID", 400);
  }
  if (!organization_id) {
    return error(req, res, "", "Isi org ID", 400);
  }
  if (!location_code) {
    return error(req, res, "", "Isi loc Code", 400);
  }

  return this.funcAddLocation({
    ref_layanan_id,
    organization_id,
    root_location_id,
    location_code,
  })
    .then((payload) => {
      if (!payload) {
        throw new Error("Gagal memuat lokasi");
      }
      // console.log(payload);
      return success(req, res, payload, "Berhasil menambahkan lokasi");
    })
    .catch((err) => {
      // console.log(err.request);
      console.log(err);
      return error(req, res, "", "Gagal menambahkan lokasi", 500, err);
    });
};

exports.funcGetLocation = ({ ref_layanan_id }) => {
  if (!ref_layanan_id) {
    throw new Error("Isi Ref Layanan ID");
  }
  return models.ihs_layanan_location
    .findOne({
      where: {
        ref_layanan_id,
      },
      include: {
        model: models.ihs_location,
        required: true,
        as: "location",
      },
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Lokasi tidak ditemukan");
      }
      const url = `/Location/${payload.location.location_id}`;
      return axiosIHS.get(url);
    });
};

exports.getLocation = (req, res) => {
  const { ref_layanan_id } = req.query;
  if (!ref_layanan_id) {
    return error(req, res, "", "Isi Layanan ID", 400, null);
  }
  return this.funcGetLocation({ ref_layanan_id })
    .then((payload) => {
      if (!payload.data) {
        throw new Error("Gagal memuat lokasi");
      }
      return success(req, res, payload.data, "Berhasil memuat lokasi");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal memuat lokasi", 500, err);
    });
};

exports.testC = (req, res) => {
  return axiosIHS
    .get("/")
    .then((payload) => {
      return success(req, res, payload, "Berhasil memuat lokasi");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal memuat lokasi", 500, err);
    });
};
