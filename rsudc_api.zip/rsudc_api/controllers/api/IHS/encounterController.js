const moment = require("moment");
const axiosIHS = require("../../../helpers/axios/axiosIHS");
const { error, success } = require("../../../helpers/utility/response");
const models = require("../../../models");
const { fundAddCondition } = require("./conditionController");
const {
  funcGetPasienByNIK,
  funcGetPasienByID,
} = require("./patientController");
const {
  funcGetPractionerByNIK,
  funcGetPractionerByID,
} = require("./practionerController");
const { diagnosisType } = require("./variables");

exports.funcAddEncounter = ({ rkun_id }) => {
  if (!rkun_id) {
    throw new Error("Isi Parameter");
  }
  const url = `/Encounter`;

  return models.rencana_kunjungan
    .findOne({
      where: {
        rkun_id: rkun_id,
      },
      attributes: [
        "rkun_id",
        "rkun_id_layanan",
        "rkun_tgl_visit",
        "rkun_id_dokter",
      ],
      include: [
        {
          model: models.asp_pasien,
          as: "asp_pasien",
          required: true,
        },
        {
          model: models.pegawai,
          as: "dokter",
          required: true,
        },
        // {
        //   model: models.ihs_pasien,
        //   as: "ihs_pasien",
        //   required: true,
        //   include: {
        //     model: models.asp_pasien,
        //     required: true,
        //     as: "asp_pasien",
        //     attributes: ["ps_id", "ps_namalengkap"],
        //   },
        // },
        // {
        //   model: models.ihs_practioner,
        //   as: "ihs_practioner",
        //   required: true,
        //   include: {
        //     model: models.pegawai,
        //     required: true,
        //     as: "pegawai",
        //     attributes: ["peg_id", "peg_nama"],
        //   },
        // },
        {
          model: models.ihs_layanan_location,
          as: "ihs_layanan_location",
          required: true,
          include: [
            {
              model: models.ihs_location,
              required: true,
              as: "location",
            },
            {
              model: models.ref_layanan,
              required: true,
              as: "layanan",
              attributes: ["ref_layanan_id", "ref_layanan_nama"],
            },
          ],
        },
      ],
    })
    .then((rkun) => {
      if (!rkun) {
        throw new Error("Data tidak ditemukan");
      }
      // if (!rkun.dokter.peg_ktp) {
      //   throw new Error(`Data ${rkun.dokter.peg_nama} KTP pegawai Kosong`);
      // }
      // if (!rkun.asp_pasien.ps_nomor_identitas) {
      //   throw new Error(
      //     `Data ${rkun.asp_pasien.ps_namalengkap} KTP Pasien Kosong`
      //   );
      // }
      let variables = {
        ihs_pasien_id: "",
        ihs_practioner_id: "",
      };
      return Promise.all([
        funcGetPasienByID({
          ps_id: rkun.asp_pasien.ps_id,
        }).then((ps) => {
          variables = {
            ...variables,
            ihs_pasien_id: ps.ps_id,
          };
        }),
        funcGetPractionerByID({
          peg_id: rkun.dokter.peg_id,
        }).then((ps) => {
          variables = {
            ...variables,
            ihs_practioner_id: ps.peg_id,
          };
        }),
      ]).then(() => {
        return {
          ...rkun.dataValues,
          ...variables,
        };
      });
    })
    .then((rkun) => {
      let body = {
        identifier: [
          {
            system:
              "http://sys-ids.kemkes.go.id/encounter/" +
              process.env.IHS_ORGANIZATION,
            value: `${rkun.ihs_pasien_id}`,
          },
        ],
        resourceType: "Encounter",
        status: "planned",
        class: {
          system: "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          code: "AMB",
          display: "ambulatory",
        },
        subject: {
          reference: `Patient/${rkun.ihs_pasien_id}`,
          display: `${rkun.asp_pasien.ps_namalengkap}`,
        },
        participant: [
          {
            type: [
              {
                coding: [
                  {
                    system:
                      "http://terminology.hl7.org/CodeSystem/v3-ParticipationType",
                    code: "ATND",
                    display: "attender",
                  },
                ],
              },
            ],
            individual: {
              reference: `Practitioner/${rkun.ihs_practioner_id}`,
              display: `${rkun.dokter.peg_nama}`,
            },
          },
        ],
        period: {
          start: moment().format(),
          //   end: "2022-06-30T09:00:00+07:00",
        },
        location: [
          {
            location: {
              reference: `Location/${rkun.ihs_layanan_location.location.location_id}`,
              display: `${rkun.ihs_layanan_location.layanan.ref_layanan_nama}`,
            },
          },
        ],
        statusHistory: [
          {
            status: "planned",
            period: {
              start: moment().format(),
            },
          },
        ],
        serviceProvider: {
          reference: "Organization/" + process.env.IHS_ORGANIZATION,
        },
      };
      return axiosIHS.post(url, body);
    })
    .then((payload) => {
      if (!payload.data || payload.status !== 201) {
        return models.ihs_encounter
          .findOne({
            where: {
              rkun_id,
            },
          })
          .then((ihs) => {
            if (ihs) {
              return ihs;
            }
            return models.ihs_encounter.create({
              rkun_id,
            });
          });
        throw new Error("Gagal encounter.");
      }
      return models.ihs_encounter
        .findOne({
          where: {
            rkun_id,
          },
        })
        .then((ihs) => {
          if (ihs) {
            ihs.encounter_id = payload.data.id;
            ihs.save();
            return ihs.reload();
          }
          return models.ihs_encounter.create({
            rkun_id,
            encounter_id: payload.data.id,
          });
        });
    });
};

exports.addEncounter = (req, res) => {
  const { rkun_id } = req.body;
  if (!rkun_id) {
    return error(req, res, "", "Isi Rencana Kunjungan", 400);
  }
  return this.funcAddEncounter({
    rkun_id,
  })
    .then((payload) => {
      return success(req, res, payload, "Berhasil encounter");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal encounter", 500, err);
    });
};

exports.funcPutEncounter = ({ rkun_id }) => {
  return models.ihs_encounter
    .findOne({
      where: {
        rkun_id: rkun_id,
      },
      include: [
        {
          model: models.trx_history_rajal,
          required: false,
          as: "history_rajal",
        },
        {
          model: models.kunjungan,
          required: true,
          as: "kunjungan",
          attributes: [
            "kun_id",
            "kun_id_layanan",
            "kun_id_pasien",
            "kun_id_dokter",
          ],
          include: [
            {
              model: models.icd,
              required: false,
              as: "icd",
              include: {
                model: models.ref_icd10,
                // required: true,
                as: "icd_ten",
              },
            },
            {
              model: models.pegawai,
              required: true,
              as: "pegawai",
              attributes: ["peg_id", "peg_ihs_practioner_id"],
            },
            {
              model: models.ihs_layanan_location,
              required: true,
              as: "ihs_layanan_location",
              include: {
                model: models.ihs_location,
                required: true,
                as: "location",
              },
            },
            {
              model: models.ref_layanan,
              required: true,
              as: "layanan",
              attributes: ["ref_layanan_id", "ref_layanan_nama"],
            },
            {
              model: models.ihs_pasien,
              required: true,
              as: "ihs_pasien",
              attributes: ["pasien_id", "ps_id", "ihs_pasien_id"],
              include: {
                model: models.asp_pasien,
                required: true,
                as: "asp_pasien",
                attributes: ["ps_id", "ps_namalengkap"],
              },
            },
          ],
        },
      ],
    })
    .then((encounter) => {
      if (!encounter) {
        throw new Error("Data Tidak Ada");
      }
      let arr_practioner = [];
      let arr_location = [];
      let arr_diagnosa = [];
      let arr_history = [];
      encounter.history_rajal.map((item) => {
        parseHistoryRajal(item)
          ? arr_history.push(parseHistoryRajal(item))
          : null;
      });
      encounter.kunjungan.map((item) => {
        arr_practioner.push({
          type: [
            {
              coding: [
                {
                  system:
                    "http://terminology.hl7.org/CodeSystem/v3-ParticipationType",
                  code: "ATND",
                  display: "attender",
                },
              ],
            },
          ],
          individual: {
            reference: `Practitioner/${item.pegawai.peg_ihs_practioner_id}`,
          },
        });
        arr_location.push({
          location: {
            reference: `Location/${item.ihs_layanan_location.location.location_id}`,
            display: `${item.ihs_layanan_location.location.location_name}`,
          },
        });
        item.icd.map((icd) => {
          if (icd.ihs_condition_id) {
            return arr_diagnosa.push({
              condition: {
                reference: `Condition/${icd.ihs_condition_id}`,
                display: icd.icd_ten ? `${icd.icd_ten.ref_icd10_deskripsi}` : "No Display",
              },
              use: {
                coding: [
                  diagnosisType({
                    type: icd.ihs_condition_id.icd_sekunder ? "cm" : "cc",
                  }),
                ],
              },
            });
          }
          return;
        });
        return;
      });

      let period_start = arr_history.find((e) => e.status === "arrived");
      let period_end = arr_history.find((e) => e.status === "finished");

      let body = {
        id: encounter.encounter_id,
        resourceType: "Encounter",
        status: "finished",
        class: {
          system: "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          code: "AMB",
          display: "ambulatory",
        },
        subject: {
          reference: `Patient/${encounter.kunjungan[0].ihs_pasien.pasien_id}`,
          display: encounter.kunjungan[0].ihs_pasien.ps_namalengkap,
        },
        participant: arr_practioner,
        period: {
          start: period_start ? period_start.period.start : "",
          end: period_end ? period_end.period.start : "",
        },
        location: arr_location,
        // diagnosis: arr_diagnosa ,
        statusHistory: arr_history,
      };
      if (arr_diagnosa.length > 0) {
        body = {
          ...body,
          diagnosis: arr_diagnosa,
        };
      }
      return body;
    });
};

exports.putEncounter = (req, res) => {
  const { rkun_id } = req.body;
  if (!rkun_id) {
    return error(req, res, "", "Isi Rencana Kunjungan", 400);
  }

  return this.funcPutEncounter({
    rkun_id,
  })
    .then((payload) => {
      return success(req, res, payload, "Berhasil encounter");
    })
    .catch((err) => {
      return error(req, res, "", "Gagal encounter", 500, err);
    });
};

const parseHistoryRajal = (data) => {
  let val = {
    status: "",
    period: {
      start: "",
      // end: "2022-06-14T08:00:00+07:00",
    },
  };
  switch (data.hist_rajal_type) {
    // 1. planned 2. arrived 3. triage 4. process 5. farmasi 6. kasir 7. done 8. cancel
    case 1:
      val = {
        status: "planned",
        period: {
          start: moment(data.created_at).format(),
          end: moment(data.created_at).format(),
        },
      };
      break;
    case 2:
      val = {
        status: "arrived",
        period: {
          start: moment(data.created_at).format(),
          end: moment(data.created_at).format(),
        },
      };
      break;
    case 3:
      val = {
        status: "triaged",
        period: {
          start: moment(data.created_at).format(),
          end: moment(data.created_at).add(5, "minutes").format(),
        },
      };
      break;
    case 4:
      val = {
        status: "in-progress",
        period: {
          start: moment(data.created_at).format(),
          // end: moment(data.created_at).add(5, "minutes").format(),
        },
      };
      break;
    // case 5:
    //   break;
    // case 6:
    //   break;
    case 7:
      val = {
        status: "finished",
        period: {
          start: moment(data.created_at).format(),
          end: moment(data.created_at).format(),
        },
      };
      break;
    case 8:
      val = {
        status: "cancelled",
        period: {
          start: moment(data.created_at).format(),
          end: moment(data.created_at).format(),
        },
      };
      break;
    default:
      val = null;
      break;
  }
  return val;
};
