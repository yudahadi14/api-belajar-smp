const axiosHEPI = require("../../../helpers/axios/axiosHepi");
const {
  error,
  success,
  logging,
} = require("../../../helpers/utility/response");
const models = require("../../../models");
const { Op } = require("sequelize");
const moment = require("moment");

exports.updateTes = (req, res) => {
  const { ps_mrn, kode_tes, tanggal_tes, hasil_tes, asal_poli } = req.body;
  const payload = {
    key: process.env.HEPI_TOKEN,
    kode_tes,
    nik: "",
    nama: "",
    tanggal_tes,
    hasil_tes,
    // kode_tes: "vl / antihcv / hiv / hbsag / antihbs / antibc / antihbcigm",
    // nik: "16-digit nik",
    // nama: "(optional)",
    // tanggal_tes: "YYYY-MM-DD",
    // hasil_tes: "1",
  };

  return models.v_pasien
    .findOne({
      where: {
        ps_mrn: ps_mrn,
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien Tidak Ditemukan");
      }
      if (!pasien.ps_nomor_identitas) {
        throw new Error("Pasien NIK Tidak Ditemukan");
      }

      payload["nik"] = pasien.ps_nomor_identitas;
      payload["nama"] = pasien.ps_namalengkap;

      return axiosHEPI
        .post("/hepc/sihc/api/akses/updatetes", payload)
        .then((data) => {
          if (data.data.error) {
            throw new Error(data.data.error);
          }
          return Promise.all([
            registerPasien({ ps_mrn, asal_poli }).catch((err) => {
              logging(err);
            }),
            updateFaktorResiko(ps_mrn).catch((err) => {
              logging(err);
            }),
          ]).then(() => {
            return models.hepi_c_tes
              .create({
                kode_tes,
                nik: payload.nik,
                nama: payload.nama,
                tanggal_tes,
                hasil_tes,
              })
              .then(() => {
                return data.data;
              });
          });
        });
    })
    .then((data) => {
      return success(req, res, data, "Berhasil Tambah");
    })
    .catch((err) => {
      return error(req, res, null, "", 500, err);
    });
};

const registerPasien = (body) => {
  const { ps_mrn, asal_poli } = body;
  const payload = {
    key: process.env.HEPI_TOKEN,
    data: {
      nik: "",
      asal_poli: asal_poli,
      nama: "",
      jk: "p atau l",
      tgl_lahir: {
        dd: "",
        mm: "",
        yyyy: "",
      },
      status_nikah: "",
      pendidikan: "",
      // "status_nikah" : "
      //     Kawin
      //     Belum Kawin
      //     Cerai Hidup
      //     Cerai Mati
      // ",
      // "pendidikan" : "
      //     Tidak Sekolah
      //     SD
      //     SMP
      //     SMA
      //     Akademi / Perguruan Tinggi
      // ",
      pekerjaan: "Lain-lain",
      alamat: "",
      alamat_prov: "",
      alamat_kota: "",
      no_hp: "",
    },
  };

  return models.v_pasien
    .findOne({
      where: {
        ps_mrn: ps_mrn,
      },
    })
    .then((pasien) => {
      payload["data"]["nik"] = pasien.ps_nomor_identitas;
      payload["data"]["nama"] = pasien.ps_namalengkap;
      payload["data"]["jk"] = pasien.ps_jeniskelamin == 1 ? "l" : "p";
      payload["data"]["tgl_lahir"]["dd"] = moment(pasien.ps_tgllahir).format(
        "DD"
      );
      payload["data"]["tgl_lahir"]["mm"] = moment(pasien.ps_tgllahir).format(
        "MM"
      );
      payload["data"]["tgl_lahir"]["yyyy"] = moment(pasien.ps_tgllahir).format(
        "YYYY"
      );
      payload["data"]["alamat"] = pasien.ps_alamat ?? "-";
      payload["data"]["alamat_prov"] = pasien.ps_propinsi ?? "-";
      payload["data"]["alamat_kota"] = pasien.ps_kota_kab ?? "-";
      payload["data"]["alamat_kec"] = pasien.ps_kecamatan ?? "-";
      payload["data"]["alamat_kel"] = pasien.ps_kelurahan ?? "-";
      payload["data"]["no_hp"] = pasien.ps_telpon ?? "-";
      payload["data"]["status_nikah"] =
        pasien.ps_id_statusnikah == 2 ? "Kawin" : "Belum Kawin";
      payload["data"]["pendidikan"] = "Dll";
      return models.hepi_c_pasien
        .findOne({
          where: {
            ps_mrn: ps_mrn,
          },
        })
        .then((pasien) => {
          if (!pasien) {
            return axiosHEPI
              .post("/hepc/sihc/api/akses/registerpasien", payload)
              .then((data) => {
                if (data.data.error) {
                  throw new Error(data.data.error);
                }
                return models.hepi_c_pasien
                  .create({
                    ps_mrn,
                    nik: payload.data.nik,
                    hepi_c_ps_code: data.data.id,
                    asal_poli: asal_poli,
                    nama: payload.data.nama,
                    jk: payload.data.jk,
                    tgl_lahir_dd: payload.data.tgl_lahir.dd,
                    tgl_lahir_mm: payload.data.tgl_lahir.mm,
                    tgl_lahir_yyyy: payload.data.tgl_lahir.yyyy,
                    status_nikah: payload.data.status_nikah,
                    pendidikan: payload.data.pendidikan,
                    pekerjaan: payload.data.pekerjaan,
                    alamat: payload.data.alamat,
                    alamat_prov: payload.data.alamat_prov,
                    alamat_kota: payload.data.alamat_kota,
                    no_hp: payload.data.no_hp,
                  })
                  .then(() => {
                    return data.data;
                  });
              });
          }
        });
    })
    .then((data) => {
      return true;
      // return success(req, res, data, "Berhasil Tambah");
    });
};

const updateFaktorResiko = (ps_mrn) => {
  const payload = {
    key: process.env.HEPI_TOKEN,
    nik: "",
    data: {
      // fr1: "",
      fr2: "",
      // fr3: "",
      // fr4: "",
      fr5: "",
      fr6: "",
      fr7: "",
      // fr8: "",
      // fr9: "",
      // fr10: "",
      fr11: "",
      // fr12: "",
      // fr12_b: "",
      fr13: "",
      fr14: "",
      fr15: "",
    },
  };

  return models.v_pasien
    .findOne({
      where: {
        ps_mrn: ps_mrn,
      },
    })
    .then((pasien) => {
      payload["nik"] = pasien.ps_nomor_identitas;
      return models.temp_si_hepi
        .findOne({
          where: {
            ps_mrn: ps_mrn,
          },
          order: [["id", "DESC"]],
        })
        .then((tmp) => {
          if (!tmp) {
            throw new Error("Faktor Resiko Belum Ada");
          }
          payload["data"]["fr2"] = tmp.fr2;
          payload["data"]["fr6"] = tmp.fr6;
          payload["data"]["fr5"] = tmp.fr5;
          payload["data"]["fr7"] = tmp.fr7;
          payload["data"]["fr11"] = tmp.fr11;
          payload["data"]["fr13"] = tmp.fr13;
          payload["data"]["fr14"] = tmp.fr14;
          payload["data"]["fr15"] = tmp.fr15;

          // payload["data"]["fr1"] = "Ya";
          // payload["data"]["fr3"] = "Ya";
          // payload["data"]["fr4"] = "Ya";
          // payload["data"]["fr8"] = "Ya";
          // payload["data"]["fr9"] = "Ya";
          // payload["data"]["fr10"] = "Ya";
          // payload["data"]["fr16"] = "Ya";
          payload["data"]["fr12"] = "Tidak tahu";
          // payload["data"]["fr12"] = "Ya";

          return axiosHEPI
            .post("/hepc/sihc/api/akses/updatefaktorresiko", payload)
            .then((data) => {
              if (data.data.error) {
                throw new Error(data.data.error);
              }
              return models.hepi_c_fr
                .create({
                  hepi_c_fr_code: data.data.id,
                  ps_mrn,
                  // fr1,
                  fr2: payload.data.fr2,
                  // fr3: payload.data.fr2,
                  // fr4: payload.data.fr2,
                  fr5: payload.data.fr5,
                  fr6: payload.data.fr6,
                  fr7: payload.data.fr7,
                  // fr8: payload.data.fr2,
                  // fr9: payload.data.fr2,
                  // fr10: payload.data.fr2,
                  fr11: payload.data.fr11,
                  // fr12: payload.data.fr2,
                  // fr12_b: payload.data.fr2,
                  fr13: payload.data.fr13,
                  fr14: payload.data.fr14,
                  fr15: payload.data.fr15,
                })
                .then(() => {
                  // tmp.destroy();
                  return data.data;
                });
            });
        });
    })
    .then((data) => {
      return true;
    });
};

exports.tempC = (req, res) => {
  const {
    ps_mrn,
    fr1,
    fr2,
    fr3,
    fr4,
    fr5,
    fr6,
    fr7,
    fr8,
    fr9,
    fr10,
    fr11,
    fr12,
    fr12_b,
    fr13,
    fr14,
    fr15,
    g,
    p,
    a,
    kode_provinsi,
    kode_kecamatan,
    kode_kelurahan,
    kelompok_resiko,
    is_hamil,
  } = req.body;
  return models.temp_si_hepi
    .create({
      ps_mrn,
      fr1,
      fr2,
      fr3,
      fr4,
      fr5,
      fr6,
      fr7,
      fr8,
      fr9,
      fr10,
      fr11,
      fr12,
      fr12_b,
      fr13,
      fr14,
      fr15,
      g: g || null,
      p: p || null,
      a: a || null,
      kode_provinsi,
      kode_kecamatan,
      kode_kelurahan,
      kelompok_resiko,
      is_hamil: is_hamil || null,
    })
    .then((data) => {
      return success(req, res, data, "Berhasil Tambah");
    })
    .catch((err) => {
      console.log(err);
      return error(req, res, null, "", 500, err);
    });
};

exports.checkPasien = (req, res) => {
  const { ps_mrn } = req.query;

  return models.v_pasien
    .findOne({
      where: {
        ps_mrn: ps_mrn,
      },
      attributes: ["ps_id", "ps_mrn", "ps_jeniskelamin", "ps_namalengkap"],
    })
    .then((pasien) => {
      return models.kunjungan
        .findOne({
          include: {
            model: models.icd,
            as: "icd",
            where: {
              icd_code: {
                [Op.or]: ["B18.0", "B18.1", "B18.2", "B18.9"],
              },
            },
          },
          where: {
            kun_id_pasien: pasien.ps_id,
            // kun_tgl: moment().format("YYYY-MM-DD"),
          },
        })
        .then((kun) => {
          let icd = kun?.icd.map((a) => {
            return a.icd_code;
          });
          let tipe = 0;
          if (icd) {
            let is_b = icd.some((r) => ["B18.0", "B18.1"].includes(r));
            let is_c = icd.some((r) => ["B18.2"].includes(r));
            if (is_b && is_c) {
              tipe = 0;
            } else if (is_b) {
              tipe = 1;
            } else if (is_c) {
              tipe = 2;
            }
          }
          return {
            ...pasien.get({ plain: true }),
            tipe,
          };
        });
    })
    .then((data) => {
      return success(req, res, data, "Berhasil Load");
    })
    .catch((err) => {
      console.log(err);
      return error(req, res, null, "", 500, err);
    });
};

const checkPasienHepi = (nik) => {
  return axiosHEPI
    .post("/hepc/sihc/api/akses/checkpasien", {
      key: `${process.env.HEPI_TOKEN}`,
      nik: nik,
    })
    .then((payload) => {
      let data = payload.data;
      if (!data) {
        return null;
      }
      return data;
    });
};

const registerPasienHepi = (ps_id) => {
  let layanan_awal = "";
  return models.v_pasien
    .findOne({
      where: {
        ps_id: ps_id,
      },
      include: {
        model: models.ref_layanan,
        as: "layanan_awal",
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien tidak ditemukan");
      }
      layanan_awal = pasien.layanan_awal?.ref_layanan_nama;
      return checkPasienHepi(pasien.ps_nomor_identitas).then((pasien_hepi) => {
        if (pasien_hepi.model) {
          return {
            id: pasien_hepi.model.id,
            nik: pasien_hepi.model.nik,
          };
        } else {
          return registerPasien({
            ps_mrn: pasien.ps_mrn,
            asal_poli: layanan_awal,
          }).then((register_pasien_hepi) => {
            return {
              id: register_pasien_hepi.id,
              nik: register_pasien_hepi.nik,
            };
          });
        }
      });
    })
    .then((pasien_hepi) => {
      return pasien_hepi;
    });
};

exports.updateFRHepC = (req, res) => {
  const {
    ps_id,
    fr1,
    fr2,
    fr3,
    fr4,
    fr5,
    fr6,
    fr7,
    fr8,
    fr9,
    fr10,
    fr11,
    fr12,
    fr12_b,
    fr13,
    fr14,
    fr15,
  } = req.body;
  const payload = {
    key: process.env.HEPI_TOKEN,
    nik: "",
    data: {
      fr5: fr5,
      fr7: fr7,
      fr11: fr11,
      fr13: fr13,
      fr14: fr14,
      fr15: fr15,
      // fr2: fr2,
    },
  };

  return registerPasienHepi(ps_id)
    .then((pasien_hepi) => {
      payload["nik"] = pasien_hepi.nik;
      return axiosHEPI
        .post("/hepc/sihc/api/akses/updatefaktorresiko", payload)
        .then((data) => {
          if (data.data.error) {
            throw new Error(data.data.error);
          }
          return models.hepi_c_fr
            .findOne({
              where: {
                ps_id,
              },
            })
            .then((fr) => {
              if (!fr) {
                return models.hepi_c_fr
                  .create({
                    hepi_c_fr_code: data.data.id,
                    ps_id,
                    // fr1,
                    fr2: payload.data.fr2,
                    // fr3: payload.data.fr2,
                    // fr4: payload.data.fr2,
                    fr5: payload.data.fr5,
                    fr6: payload.data.fr6,
                    fr7: payload.data.fr7,
                    // fr8: payload.data.fr2,
                    // fr9: payload.data.fr2,
                    // fr10: payload.data.fr2,
                    fr11: payload.data.fr11,
                    // fr12: payload.data.fr2,
                    // fr12_b: payload.data.fr2,
                    fr13: payload.data.fr13,
                    fr14: payload.data.fr14,
                    fr15: payload.data.fr15,
                  })
                  .then(() => {
                    return data.data;
                  });
              } else {
                fr.fr2 = payload.data.fr2;
                fr.fr5 = payload.data.fr5;
                fr.fr6 = payload.data.fr6;
                fr.fr7 = payload.data.fr7;
                fr.fr11 = payload.data.fr11;
                fr.fr13 = payload.data.fr13;
                fr.fr14 = payload.data.fr14;
                fr.fr15 = payload.data.fr15;
                fr.save();
                return data.data;
              }
            });
        });
    })
    .then((data) => {
      return success(req, res, data, "Berhasil Faktor Resiko");
    })
    .catch((err) => {
      return error(req, res, null, "", 500, err);
    });
};

exports.updateTesHepC = (req, res) => {
  const { ps_id, kode_tes, tanggal_tes, hasil_tes, hsl_lab_dt_id } = req.body;

  // kode_tes "vl / antihcv / hiv / hbsag / antihbs / antibc / antihbcigm"

  const payload = {
    key: process.env.HEPI_TOKEN,
    kode_tes,
    nik: "",
    nama: "",
    tanggal_tes,
    hasil_tes,
    // kode_tes: "vl / antihcv / hiv / hbsag / antihbs / antibc / antihbcigm",
    // nik: "16-digit nik",
    // nama: "(optional)",
    // tanggal_tes: "YYYY-MM-DD",
    // hasil_tes: "1 / 0",
  };

  return models.v_pasien
    .findOne({
      where: {
        ps_id,
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien tidak ditemukan");
      } else if (!pasien.ps_nomor_identitas) {
        throw new Error("Nomor identitas pasien kosong");
      }
      payload["nama"] = pasien.ps_namalengkap;
      payload["nik"] = pasien.ps_nomor_identitas;
      return axiosHEPI
        .post("/hepc/sihc/api/akses/updatetes", payload)
        .then((data) => {
          if (data.data.error) {
            throw new Error(data.data.error);
          }
          return models.hepi_c_tes
            .create({
              kode_tes,
              nik: pasien.ps_nomor_identitas,
              nama: pasien.ps_namalengkap,
              tanggal_tes,
              hasil_tes,
              hsl_lab_dt_id,
            })
            .then(() => {
              return data.data;
            });
        });
    })
    .then((data) => {
      return success(req, res, data, "Berhasil Update Tes");
    })
    .catch((err) => {
      return error(req, res, null, "", 500, err);
    });
};
