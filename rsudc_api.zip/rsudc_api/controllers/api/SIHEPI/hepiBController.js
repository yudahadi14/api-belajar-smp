const axiosHEPI = require("../../../helpers/axios/axiosHepi");
const { success, error } = require("../../../helpers/utility/response");
const models = require("../../../models");

const tambahBumil = (body, tmp) => {
  const {
    ps_mrn,
    tanggal_hbsag,
    kode_hbsag,
    hasil_hbsag,
    tanggal_anti_hbs,
    hasil_anti_hbs,
    kode_spesimen_anti_hbs,
  } = body;
  const payload = {
    nik: "36042851030111",
    nama_lengkap: "ROHIMAH",
    tanggal_lahir: "2001-03-11",
    tempat_lahir: "SERANG",
    status_pernikahan: "Menikah",
    status_gpa: "",
    jenis_kelamin: "P",
    alamat: "JL.RAWSARI TIMUR I DALAM RT 011 RW 002",
    nomor_hp: "087711063287",
    // pendidikan: "TDK TAHU",
    // pekerjaan: "IBU R.TANGGA",
    // nomor_kartu_keluarga: "3604285103011175",
    // tanggal_skrining_hiv: "2022-03-10",
    // kode_spesimen_hiv: "Rapid 1 HIV Virocek",
    // hasil_skrining_hiv: "nonreaktif",
    // tanggal_skrining_sifilis: "2022-03-10",
    // kode_spesimen_sifilis: "TPHA Syphilis",
    // hasil_skrining_sifilis: "nonreaktif",
    // tanggal_jam_persalinan: "",
    // tempat_persalinan: "",
    wilayah_kerja: 1,
    kode_propinsi_pasien: "",
    kode_kabupaten_pasien: "",
    kode_kelurahan_pasien: "",
    // propinsi: "DKI JAKARTA",
    // umur_kehamilan: 35,
    // tanggal_tafsiran_partus: "2022-04-13",
    // tanggal_masuk_pdp: "2021-07-06",
    // tanggal_mulai_art: "2022-03-17",
    // sifilis_ditangani: "Y",
    // sifilis_diobati_adequat: "Y",
    // hepatitis_tatalaksana: "Y",
    // pasangan_ketahui_status_hiv: "",
    // pasangan_diperiksa_sifilis: "",
    // tanggal_pemberian_arv: "",
    // tanggal_dbseid_6_8: "",
    // hasil_dbseid_6_8: "",
    // tanggal_konfirmasi_eid_12: "",
    // hasil_konfirmasi_eid_12: "",
    // tanggal_balita_terdeteksi_hiv: "",
    // hasil_balita_terdeteksi_hiv: "",
    // tanggal_balita_masuk_pdp: "",
    // tanggal_balita_pengobatan_arv: "",
    // bayi_ibu_sifilis_rujuk: "",
    // kurang_2tahun_periksa_sifilis: "",
    // tanggal_kurang_2tahun_periksa_sifilis: "",
    // hasil_kurang_2tahun_periksa_sifilis: "",
    data_aksi: "data_baru",
    // tanggal_hb0_bayi: "",
    // tanggal_hb1_bayi: "",
    // tanggal_hb2_bayi: "",
    // status_hbsag_anak: "",
    // tanggal_hbig_anak: "",
    // tanggal_antihbs: "",
    // screening_triple_eliminasi: "T",
    tanggal_skrining_hbsag: tanggal_hbsag,
    hasil_skrining_hbsag: hasil_hbsag,
    kode_spesimen_hbsag: kode_hbsag,
    // tanggal_persalinan: "2022-03-10",
  };
  return models.v_pasien
    .findOne({
      where: {
        ps_mrn: ps_mrn,
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien tidak ditemukan");
      }
      payload["nik"] = pasien.ps_nomor_identitas;
      payload["nama_lengkap"] = pasien.ps_nomor_identitas;
      payload["tanggal_lahir"] = pasien.ps_tgllahir;
      payload["tempat_lahir"] = pasien.ps_tempatlahir;
      payload["status_pernikahan"] =
        pasien.ps_id_statusnikah == 2 ? "Menikah" : "Belum Menikah";
      payload["jenis_kelamin"] = pasien.ps_jeniskelamin == 1 ? "L" : "P";
      //   payload["status_gpa"] = pasien.ps_nomor_identitas;
      payload["alamat"] = pasien.ps_alamat;
      payload["nomor_hp"] = pasien.ps_telpon;
      if (hasil_anti_hbs) {
        payload["pemeriksaan_anti_hbs"] = "Y";
        payload["kode_spesimen_anti_hbs"] = "HBS";
        payload["tanggal_pemeriksaan_anti_hbs"] = tanggal_anti_hbs;
        payload["hasil_pemeriksaan_anti_hbs"] = hasil_anti_hbs;
      }
      return models.temp_si_hepi
        .findOne({
          where: {
            ps_mrn: ps_mrn,
          },
          order: [["id", "DESC"]],
        })
        .then((tmp) => {
          if (tmp) {
            payload["kode_propinsi_pasien"] = tmp.kode_provinsi;
            payload["kode_kabupaten_pasien"] = tmp.kode_kecamatan;
            payload["kode_kelurahan_pasien"] = tmp.kode_kelurahan_pasien;
            payload["status_gpa"] = `G${tmp.g || 0}P${tmp.p || 0}A${
              tmp.a || 0
            }`;
          }
        });
    });
};

const tambahRisti = (body, tmp) => {
  const {
    ps_mrn,
    tanggal_hbsag,
    hasil_hbsag,
    tanggal_anti_hbs,
    hasil_anti_hbs,
    kode_spesimen_anti_hbs,
    kode_hbsag,
  } = body;

  let payload = {
    nik: null,
    nama_lengkap: null,
    tanggal_lahir: null,
    tempat_lahir: null,
    status_pernikahan: null,
    jenis_kelamin: null,
    status_gpa: null,
    alamat: null,
    nomor_hp: null,
    pendidikan: null,
    pekerjaan: null,
    nomor_kartu_keluarga: null,
    tanggal_skrining_hbsag: null,
    kode_spesimen_hbsag: null,
    hasil_skrining_hbsag: null,
    wilayah_kerja: null,
    kode_propinsi_pasien: null,
    kode_kabupaten_pasien: null,
    kode_kelurahan_pasien: null,
    propinsi: null,
    kelompok_risiko: null,
    pernah_imunisasi_hepatitis_b: null,
    hepb_dalam_keluarga: null,
    hepb_hubungan: null,
    hepb_rujuk: null,
    konseling_hepb: null,
    pemeriksaan_anti_hbs: null,
    tanggal_pemeriksaan_anti_hbs: null,
    kode_spesimen_anti_hbs: null,
    hasil_pemeriksaan_anti_hbs: null,
    tindak_lanjut_imunisasi_1: null,
    tanggal_tindak_lanjut_imunisasi_1: null,
    tindak_lanjut_imunisasi_2: null,
    tanggal_tindak_lanjut_imunisasi_2: null,
    tindak_lanjut_imunisasi_3: null,
    tanggal_tindak_lanjut_imunisasi_3: null,
    data_aksi: "data_baru",
    screening_triple_eliminasi: null,
  };

  return models.v_pasien
    .findOne({
      where: {
        ps_mrn: ps_mrn,
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Pasien tidak ditemukan");
      }

      payload["nik"] = pasien.ps_nomor_identitas;
      payload["nama_lengkap"] = pasien.ps_nomor_identitas;
      payload["tanggal_lahir"] = pasien.ps_tgllahir;
      payload["tempat_lahir"] = pasien.ps_tempatlahir;
      payload["status_pernikahan"] =
        pasien.ps_id_statusnikah == 2 ? "Menikah" : "Belum Menikah";
      payload["jenis_kelamin"] = pasien.ps_jeniskelamin == 1 ? "L" : "P";
      //   payload["status_gpa"] = pasien.ps_nomor_identitas;
      payload["alamat"] = pasien.ps_alamat;
      payload["nomor_hp"] = pasien.ps_telpon;
      payload["tanggal_skrining_hbsag"] = tanggal_hbsag;
      payload["kode_spesimen_hbsag"] = "HBsAg";
      payload["hasil_skrining_hbsag"] = hasil_hbsag;
      payload["wilayah_kerja"] = "1";
      payload["kelompok_risiko"] = "14";
      payload["pernah_imunisasi_hepatitis_b"] = "tidak_tahu_lupa";
      payload["pemeriksaan_anti_hbs"] = "T";
      if (hasil_anti_hbs) {
        payload["pemeriksaan_anti_hbs"] = "Y";
        payload["kode_spesimen_anti_hbs"] = "HBS";
        payload["tanggal_pemeriksaan_anti_hbs"] = tanggal_anti_hbs;
        payload["hasil_pemeriksaan_anti_hbs"] = hasil_anti_hbs;
      }
      return axiosHEPI.post("/api-simpus/save_risti", payload).then((data) => {
        return models.hepi_b_risti.create({
          hepi_b_risti_code: data.data.data.unique_id,
          hepi_b_risti_nik: payload.nik,
          hepi_b_risti_nama_lengkap: payload.nama_lengkap,
          hepi_b_risti_tanggal_lahir: payload.tanggal_lahir,
          hepi_b_risti_tempat_lahir: payload.tempat_lahir,
          hepi_b_risti_status_pernikahan: payload.status_pernikahan,
          hepi_b_risti_jenis_kelamin: payload.jenis_kelamin,
          hepi_b_risti_status_gpa: payload.status_gpa,
          hepi_b_risti_alamat: payload.alamat,
          hepi_b_risti_nomor_hp: payload.nomor_hp,
          hepi_b_risti_pendidikan: payload.pendidikan,
          hepi_b_risti_pekerjaan: payload.pekerjaan,
          hepi_b_risti_nomor_kartu_keluarga: payload.nomor_kartu_keluarga,
          hepi_b_risti_tanggal_skrining_hbsag: payload.tanggal_skrining_hbsag,
          hepi_b_risti_kode_spesimen_hbsag: payload.kode_spesimen_hbsag,
          hepi_b_risti_hasil_skrining_hbsag: payload.hasil_skrining_hbsag,
          hepi_b_risti_wilayah_kerja: payload.wilayah_kerja,
          hepi_b_risti_kode_propinsi_pasien: payload.kode_propinsi_pasien,
          hepi_b_risti_kode_kabupaten_pasien: payload.kode_kabupaten_pasien,
          hepi_b_risti_kode_kelurahan_pasien: payload.kode_kelurahan_pasien,
          hepi_b_risti_propinsi: payload.propinsi,
          hepi_b_risti_kelompok_risiko: payload.kelompok_risiko,
          hepi_b_risti_pernah_imunisasi_hepatitis_b:
            payload.pernah_imunisasi_hepatitis_b,
          hepi_b_risti_hepb_dalam_keluarga: payload.hepb_dalam_keluarga,
          hepi_b_risti_hepb_hubungan: payload.hepb_hubungan,
          hepi_b_risti_hepb_rujuk: payload.hepb_rujuk,
          hepi_b_risti_konseling_hepb: payload.konseling_hepb,
          hepi_b_risti_pemeriksaan_anti_hbs: payload.hasil_anti_hbs,
          hepi_b_risti_tanggal_pemeriksaan_anti_hbs:
            payload.tanggal_pemeriksaan_anti_hbs || null,
          hepi_b_risti_kode_spesimen_anti_hbs: payload.kode_spesimen_anti_hbs,
          hepi_b_risti_hasil_pemeriksaan_anti_hbs:
            payload.hasil_pemeriksaan_anti_hbs,
          hepi_b_risti_tindak_lanjut_imunisasi_1:
            payload.tindak_lanjut_imunisasi_1,
          hepi_b_risti_tanggal_tindak_lanjut_imunisasi_1:
            payload.tanggal_tindak_lanjut_imunisasi_1 || null,
          hepi_b_risti_tindak_lanjut_imunisasi_2:
            payload.tindak_lanjut_imunisasi_2,
          hepi_b_risti_tanggal_tindak_lanjut_imunisasi_2:
            payload.tanggal_tindak_lanjut_imunisasi_2 || null,
          hepi_b_risti_tindak_lanjut_imunisasi_3:
            payload.tindak_lanjut_imunisasi_3,
          hepi_b_risti_tanggal_tindak_lanjut_imunisasi_3:
            payload.tanggal_tindak_lanjut_imunisasi_3 || null,
          hepi_b_risti_data_aksi: payload.data_aksi,
          hepi_b_risti_screening_triple_eliminasi:
            payload.screening_triple_eliminasi,
        });
        return data.data.data;
      });

      //   payload["pendidikan"] = pasien.ps_nomor_identitas;
      //   payload["pekerjaan"] = pasien.ps_nomor_identitas;
    });
};

exports.tambahHepB = (req, res) => {
  const {
    ps_mrn,
    tanggal_hbsag,
    hasil_hbsag,
    tanggal_anti_hbs,
    hasil_anti_hbs,
    kode_spesimen_anti_hbs,
    kode_hbsag,
  } = req.body;

  return models.temp_si_hepi
    .findOne({
      where: {
        ps_mrn: ps_mrn,
      },
      order: [["id", "DESC"]],
    })
    .then((tmp) => {
      if (tmp && tmp.is_hamil) {
        return tambahBumil(req.body, tmp);
      } else {
        return tambahRisti(req.body, tmp);
      }
    })
    .then((data) => {
      return success(req, res, data, "Berhasil Tambah");
    })
    .catch((err) => {
      return error(req, res, null, "", 500, err);
    });
};
