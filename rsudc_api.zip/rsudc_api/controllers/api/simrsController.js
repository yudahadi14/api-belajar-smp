var models = require("../../model_simrs");
let models2 = require("../../models");
const { QueryTypes } = require("sequelize");
// const { parseJadwal } = require("../../helpers/parser/doctorParser");
const { success, error } = require("../../helpers/utility/response");

// exports.jadwalDokter = (req, res) => {
//   const query = `
//   select
//   cast(
//     (
//       periodeawal || '-' || periodeakhir || '  ' || thn
//     ) as varchar (100)
//   ) as periode,
//   id,
//   peg_id,
//   peg_nama,
//   ref_layanan_id,
//   ref_layanan_nama,
//   hari_praktek,
//   jam_praktek_mulai,
//   jam_praktek_akhir,
//   jam_praktek_lainnya
// from
//   jadwal_praktek_dokter
//   left join pegawai on peg_id = id_dokter
//   left join ref_layanan on ref_layanan_id = id_poli
// where
//   thn = :tahun
//   and aktif = true
//   and blnint1 = :periode
//   ${req.query.peg_id ? "and peg_id = :peg_id" : ""}
// order by
//   ref_layanan_nama,
//   peg_nama,
//   CASE WHEN hari_praktek = 'Senin' THEN 1 WHEN hari_praktek = 'Selasa' THEN 2 WHEN hari_praktek = 'Rabu' THEN 3 WHEN hari_praktek = 'Kamis' THEN 4 WHEN hari_praktek = 'Jumat' THEN 5 WHEN hari_praktek = 'Sabtu' THEN 6 WHEN hari_praktek = 'Minggu' THEN 7 END ASC
// `;

//   return models.sequelize
//     .query(query, {
//       replacements: {
//         periode: req.query.periode,
//         tahun: req.query.tahun,
//         peg_id: req.query.peg_id,
//       },
//       type: QueryTypes.SELECT,
//     })
//     .then((payload) => {
//       let result = parseJadwal(payload);
//       return success(req, res, result);
//     })
//     .catch((err) => {
//       return error(req, res, err, null);
//     });
// };

exports.listDatakamar = (req, res) => {
  const query = `
  select			
  ruang
  ,kelas
  ,sum(kapasitas) as kapasitas
  ,sum(terisi) as terisi
  ,(sum(kapasitas) - sum(terisi)) as kosong
  from
  (
  
  select
      (select count(*) from v_kamar_rs_jk_5 b where b.ref_kls_inap_id = a.ref_kls_inap_id and b.ref_ruang_id = a.ref_ruang_id and ( stat_tmpt_tdr_id_status = 4 or stat_tmpt_tdr_id_status = 3) and b.ref_tmpt_tdr_kamar = a.ref_tmpt_tdr_kamar ) as terisi
      ,jml as kapasitas
      ,ref_ruang_nama as ruang
      ,ref_kls_inap_nama as kelas
      ,ref_tmpt_tdr_kamar
  from
      v_kamar_rs_kapasitas_non_covid a
  where
      ref_kls_inap_id > 0
      and (ref_ruang_nama not ilike '%durian%' or (ref_ruang_nama::text ~~* '%durian%' and ref_tmpt_tdr_kamar ilike '%4%'))
      
      and ref_tmpt_tdr_kamar not ilike '%x%'
  order by
  ref_ruang_nama asc
  ,ref_kls_inap_nama
  ) as data
  group by
  ruang
  ,kelas
  order by ruang asc, kelas asc
  `;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        ruang: req.query.ruang,
        kelas: req.query.kelas,
        kapasitas: req.query.kapasitas,
        terisi: req.query.terisi,
        kosong: req.query.kosong,
      },
    })
    .then((payload) => {
      return success(req, res, payload);
    });
};

exports.fullDataKamar = (req, res) => {
  const query = `
  select
	ref_tmpt_tdr_kamar as kamar
    ,ref_ruang_id as idruang
    ,ref_ruang_nama as nmruang
    ,ref_kls_inap_id as idkelas
    ,ref_kls_inap_nama as nmkelas
    ,count(ref_tmpt_tdr_kamar) as jml_bed
    ,array_to_string(array(
        select
            (select ps_jeniskelamin from asp_pasien where ps_id = stat_tmpt_tdr_id_pasien limit 1)
        from
            v_tempat_tidur_5 c
            , status_tempat_tidur d
        where
            c.ref_tmpt_tdr_id = d.stat_tmpt_tdr_id_tmpt_tdr
            and c.ref_kls_inap_id = a.ref_kls_inap_id
            and c.ref_ruang_id = a.ref_ruang_id
            and d.stat_tmpt_tdr_id_status in (3)
            and c.ref_tmpt_tdr_aktif is true
            and c.ref_ruang_nama not ilike '%vk%'
            and c.ref_ruang_nama not ilike '%ok%'
            and c.ref_ruang_nama not ilike '%batavia%'
            and c.ref_tmpt_tdr_kamar = a.ref_tmpt_tdr_kamar
            and c.ref_tmpt_tdr_id is not null
            and (c.ref_tmpt_tdr_bed::text !~ '%N%' OR c.ref_tmpt_tdr_bed::text ~ '%BN%'::text)
	),',') as jk
	,(select
		count(*) as infeksi
		from v_tempat_tidur_5 c, status_tempat_tidur d
		where
			c.ref_tmpt_tdr_id = d.stat_tmpt_tdr_id_tmpt_tdr
            and c.ref_kls_inap_id = a.ref_kls_inap_id
            and c.ref_ruang_id = a.ref_ruang_id
            and d.stat_tmpt_tdr_id_status in (3)
			and d.stat_tmpt_tdr_infeksi is true 
            and c.ref_tmpt_tdr_aktif is true
            and c.ref_ruang_nama not ilike '%vk%'
            and c.ref_ruang_nama not ilike '%ok%'
            and c.ref_ruang_nama not ilike '%batavia%'
            and c.ref_tmpt_tdr_kamar = a.ref_tmpt_tdr_kamar
            and c.ref_tmpt_tdr_id is not null
            and (c.ref_tmpt_tdr_bed::text !~ '%N%' OR c.ref_tmpt_tdr_bed::text ~ '%BN%'::text)
	)as infeksi
	,(select count(*)
		from v_tempat_tidur_5 c, status_tempat_tidur d
		where
			c.ref_tmpt_tdr_id = d.stat_tmpt_tdr_id_tmpt_tdr
            and c.ref_kls_inap_id = a.ref_kls_inap_id
            and c.ref_ruang_id = a.ref_ruang_id
            and d.stat_tmpt_tdr_id_status in (1)
            and c.ref_tmpt_tdr_aktif is true
            and c.ref_ruang_nama not ilike '%vk%'
            and c.ref_ruang_nama not ilike '%ok%'
            and c.ref_ruang_nama not ilike '%batavia%'
            and c.ref_tmpt_tdr_kamar = a.ref_tmpt_tdr_kamar
            and c.ref_tmpt_tdr_id is not null
            and (c.ref_tmpt_tdr_bed::text !~ '%N%' OR c.ref_tmpt_tdr_bed::text ~ '%BN%'::text)
	) as jml_kosong
from
	v_tempat_tidur_5 a
where ref_kls_inap_id > 0
	and ref_tmpt_tdr_aktif is true
	and ref_ruang_nama not ilike '%vk%'
	and ref_ruang_nama not ilike '%ok%'
	and ref_ruang_nama not ilike '%batavia%' 
    and ref_tmpt_tdr_id is not null
    and (ref_tmpt_tdr_bed::text !~ '%N%' OR ref_tmpt_tdr_bed::text ~ '%BN%'::text)
group by
	ref_tmpt_tdr_kamar 
    ,ref_ruang_id 
    ,ref_kls_inap_id
    ,ref_kls_inap_nama
    ,ref_ruang_nama
order by
	idruang,
	idkelas
  `;
  return models2.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
    })
    .then((payload) => {
      return success(req, res, payload);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
