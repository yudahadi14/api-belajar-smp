const models = require("../../models");
const { success, error } = require("../../helpers/utility/response");
const axios = require("axios");
const moment = require("moment");
const ExcelJS = require("exceljs");
const { QueryTypes, Op } = require("sequelize");

exports.getUbeRule = (req, res) => {
  const { penanggung_id } = req.query;
  return models.trx_si_ube_rule
    .findAll({
      where: {
        penanggung_id: penanggung_id,
      },
      order: [["order", "ASC"]],
      include: [
        {
          model: models.asp_penanggung,
          required: true,
          as: "penanggung",
        },
        {
          model: models.mst_tipe_berkas,
          required: true,
          as: "tipe_berkas",
        },
      ],
    })
    .then((payload) => {
      return success(req, res, payload, "Rule termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.createUbeRule = (req, res) => {
  const body = req.body;
  let { peg_id } = req.user;
  let arr = [];
  body.map((item) => {
    let found = arr.find((el) => el.tipe_berkas_id == item.tipe_berkas_id);
    if (!found) {
      return arr.push({
        penanggung_id: item.penanggung_id,
        tipe_berkas_id: item.tipe_berkas_id,
        created_by: peg_id,
      });
    }
    return;
  });
  // let promiseArr = [];

  // body.map(item=>{
  //   promiseArr.push(
  //     models.trx_si_ube.findOne({
  //       where: {
  //         penanggung_id: item.penanggung_id,
  //       },
  //     }).then(found=>{})
  //   );
  // })
  return models.trx_si_ube_rule
    .bulkCreate(arr)
    .then((payload) => {
      if (payload) {
        return success(req, res, payload, "Rule berhasil ditambahkan.");
      }
      throw new Error("Gagal Insert Rule");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.editUbeRuleNew = (req, res) => {
  const { ube_rule_id, order } = req.body;

  if (!ube_rule_id || !order) {
    return error(req, res, {}, "check parameter", 400, null);
  }

  return models.trx_si_ube_rule
    .update(
      {
        order,
      },
      {
        where: {
          ube_rule_id,
        },
      }
    )
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.editUbeRule = (req, res) => {
  const body = req.body;
  let user = req.user;
  let promiseArr = [];
  let arr = [];
  body.map((item) => {
    let found = arr.find((el) => el.tipe_berkas_id == item.tipe_berkas_id);
    if (!found) {
      return arr.push({
        penanggung_id: item.penanggung_id,
        tipe_berkas_id: item.tipe_berkas_id,
        updated_by: user.peg_id,
      });
    }
    return;
  });
  arr.map((item) => {
    if (item.ube_rule_id) {
      return promiseArr.push(
        models.trx_si_ube_rule.update(
          {
            penanggung_id: item.penanggung_id,
            tipe_berkas_id: item.tipe_berkas_id,
            updated_by: user.peg_id,
          },
          {
            where: {
              ube_rule_id: item.ube_rule_id,
            },
          }
        )
      );
    }
    return promiseArr.push(
      models.trx_si_ube_rule
        .findOne({
          where: {
            penanggung_id: item.penanggung_id,
            tipe_berkas_id: item.tipe_berkas_id,
          },
        })
        .then((found) => {
          if (!found) {
            return models.trx_si_ube_rule.create({
              penanggung_id: item.penanggung_id,
              tipe_berkas_id: item.tipe_berkas_id,
              created_by: user.peg_id,
            });
          }
        })
    );
  });
  return Promise.all(promiseArr)
    .then((payload) => {
      if (payload) {
        return success(req, res, payload, "Rule berhasil ditambahkan.");
      }
      throw new Error("Gagal Insert Rule");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getUbe = (req, res) => {
  const { kunId, penanggungId, tipe_berkas_id } = req.query;
  if (!kunId || !penanggungId) {
    return res.status(400).json({
      status: 400,
      message: "Isi Kun ID dan PenanggungID",
      data: {},
    });
  }
  return models.trx_si_ube
    .findAll({
      where: {
        kun_id: kunId,
      },
      include: [
        {
          model: models.pegawai,
          required: false,
          as: "pegawai",
        },
      ],
    })
    .then((payload) => {
      return models.trx_si_ube_rule
        .findAll({
          where: {
            penanggung_id: penanggungId,
            is_active: true,
          },
          order: [["order", "ASC"]],
          include: [
            {
              model: models.mst_tipe_berkas,
              where: {
                tipe_berkas_id: tipe_berkas_id
                  ? tipe_berkas_id
                  : {
                      [Op.not]: null,
                    },
              },
              required: true,
              as: "tipe_berkas",
            },
            {
              model: models.pegawai,
              required: false,
              as: "pegawai",
            },
          ],
        })
        .then((rules) => {
          let arr = [];
          if (rules.length === 0) {
            return models.mst_tipe_berkas
              .findAll({
                where: {
                  is_others: true,
                },
                where: {
                  tipe_berkas_id: tipe_berkas_id
                    ? tipe_berkas_id
                    : {
                        [Op.not]: null,
                      },
                },
              })
              .then((berkas) => {
                berkas.map((item) => {
                  let found = payload.find(
                    (find) => find.tipe_berkas_id === item.tipe_berkas_id
                  );
                  if (found) {
                    return arr.push({
                      penanggung_id: penanggungId,
                      input_type: item.input_type,
                      placeholder: item.placeholder,
                      kun_id: found.kun_id,
                      si_ube_id: found.si_ube_id,
                      filename: found.si_ube_filename,
                      rules_berkas_created_at: "",
                      rules_berkas_created_by: "",
                      tipe_berkas_id: item.tipe_berkas_id,
                      nama_berkas: item.nama_berkas,
                      is_locked: found.is_locked,
                      file_updated_at: found.updated_at,
                      file_updated_by: found.pegawai
                        ? found.pegawai.peg_nama
                        : "",
                      file_created_at: found.created_at,
                      file_created_by: found.pegawai
                        ? found.pegawai.peg_nama
                        : "",
                    });
                  }
                  return arr.push({
                    penanggung_id: penanggungId,
                    input_type: item.input_type,
                    placeholder: item.placeholder,
                    kun_id: "",
                    si_ube_id: "",
                    filename: "",
                    tipe_berkas_id: item.tipe_berkas_id,
                    rules_berkas_created_at: "",
                    rules_berkas_created_by: "",
                    nama_berkas: item.nama_berkas,
                    is_locked: false,
                    file_updated_at: "",
                    file_updated_by: "",
                    file_created_at: "",
                    file_created_by: "",
                  });
                });
                return arr;
              });
          }
          rules.map((item) => {
            let found = payload.find(
              (find) => find.tipe_berkas_id === item.tipe_berkas_id
            );
            if (found) {
              return arr.push({
                penanggung_id: item.penanggung_id,
                input_type: item.tipe_berkas.input_type,
                placeholder: item.tipe_berkas.placeholder,
                kun_id: found.kun_id,
                si_ube_id: found.si_ube_id,
                filename: found.si_ube_filename,
                rules_berkas_created_at: item.created_at,
                rules_berkas_created_by: item.pegawai
                  ? item.pegawai.peg_nama
                  : "",
                tipe_berkas_id: item.tipe_berkas.tipe_berkas_id,
                nama_berkas: item.tipe_berkas.nama_berkas,
                is_locked: found.is_locked,
                file_updated_at: found.updated_at,
                file_updated_by: found.pegawai ? found.pegawai.peg_nama : "",
                file_created_at: found.created_at,
                file_created_by: found.pegawai ? found.pegawai.peg_nama : "",
              });
            }
            return arr.push({
              penanggung_id: item.penanggung_id,
              input_type: item.tipe_berkas.input_type,
              placeholder: item.tipe_berkas.placeholder,
              kun_id: "",
              si_ube_id: "",
              filename: "",
              rules_berkas_created_at: item.created_at,
              rules_berkas_created_by: item.pegawai
                ? item.pegawai.peg_nama
                : "",
              tipe_berkas_id: item.tipe_berkas.tipe_berkas_id,
              nama_berkas: item.tipe_berkas.nama_berkas,
              is_locked: false,
              file_updated_at: "",
              file_updated_by: "",
              file_created_at: "",
              file_created_by: "",
            });
          });
          return arr;
        });
    })
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.addUbe = (req, res) => {
  let body = req.body;
  let user = req.user;
  // let arrBody = [];
  // body.map(item=>{
  //     arrBody.push({
  //       kun_id: item.kunId,
  //       tipe_berkas_id: item.tipeBerkasId,
  //       tipeBerkas: item.tipeBerkas,
  //       filePhoto: item.value,
  //     });
  // })
  let promiseArr = [];
  body.map((item) => {
    return promiseArr.push(
      models.trx_si_ube
        .findOne({
          where: {
            kun_id: item.kun_id,
            tipe_berkas_id: item.tipe_berkas_id,
          },
        })
        .then((exist) => {
          if (exist) {
            return models.trx_si_ube.update(
              {
                si_ube_filename: item.si_ube_filename,
                updated_by: user.peg_id,
                updated_at: models.sequelize.fn("NOW"),
              },
              {
                where: {
                  kun_id: item.kun_id,
                  tipe_berkas_id: item.tipe_berkas_id,
                },
              }
            );
          } else {
            return models.trx_si_ube.create({
              ...item,
              created_by: user.peg_id,
              created_at: models.sequelize.fn("NOW"),
            });
          }
        })
    );
  });

  return Promise.all(promiseArr)
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getUbeRuleGroup = (req, res) => {
  return models.trx_si_ube_rule
    .findAll({
      group: [
        "trx_si_ube_rule.penanggung_id",
        "penanggung.png_nama",
        "penanggung.png_id",
      ],
      order: [["penanggung", "png_nama", "ASC"]],
      attributes: ["penanggung_id"],
      include: [
        {
          attributes: ["png_nama", "png_id"],
          model: models.asp_penanggung,
          as: "penanggung",
          required: true,
        },
      ],
    })
    .then((payload) => {
      let arr = [];
      if (payload) {
        payload.map((item) => {
          arr.push({
            penanggung_id: item.penanggung_id,
            penanggung_nama: item.penanggung.png_nama,
          });
        });
      }
      return success(req, res, arr, "Rule termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.findUbeUser = (req, res) => {
  const { peg_id } = req.user;
  return models.mst_ube_role
    .findOne({
      where: {
        peg_id: peg_id,
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
exports.exportUbe = (req, res) => {
  const { start_date, end_date, png_id, with_rule, no_mr } = req.query;

  const query = `
  select 
  rkun_id,
  tgl,
  rkun_png_noncash,
  ap.png_nama,
    b.inap_id, 
    c.ref_ruang_nama,
    c.ref_kls_inap_nama,
    b.inap_waktu,
    b.inap_waktu_keluar,
    mtb.nama_berkas,
    mtb.input_type,
    tsu.si_ube_filename, 
      tsu.created_at,
      tsu.is_locked,
          tsu.created_by,
          vp.ps_mrn,
          vp.ps_namalengkap,
           pgc.peg_nama as creator, 
    pgu.peg_nama as updator,
    (select peg_nama from pegawai where peg_id = b.inap_tutup_tindakan_staff) as peg_tutup
  from 
    (
      select 
        distinct (
          select 
            inap_id 
          from 
            inap a 
          where 
            a.inap_id_kunjungan = b.inap_id_kunjungan 
          order by 
            inap_id desc 
          limit 
            1
        ) as inap_id_akhir, 
        tgl, 
        rkun_png_noncash,
        rkun_id,
        rkun_id_pasien
      from 
        rencana_kunjungan, 
        kunjungan, 
        inap b, 
        pembayaran_kasir 
      where 
        rkun_id = kun_id_rencana_kunjungan 
        and kun_id = inap_id_kunjungan 
        and rkun_id = id_rkun 
        and jenis_pembayaran in (1, 4)
        and kun_inap is true 
        and (no_kwitansi ilike '%KWI-PAY%' 
        or no_kwitansi ilike '%KWI-RTR%')
        and rkun_inap = 't' 
    AND id_parent IS NULL 
  ) as jjj 
  left join inap b on inap_id = inap_id_akhir 
  left join v_pasien vp on vp.ps_id = rkun_id_pasien
  left join asp_penanggung ap on ap.png_id = rkun_png_noncash  
  left join v_tempat_tidur_5 c on c.ref_tmpt_tdr_id = inap_tempat_tidur 
  ${
    with_rule === "true"
      ? "left join trx_si_ube_rule tsur on tsur.penanggung_id = rkun_png_noncash"
      : ""
  }
  left join trx_si_ube tsu on tsu.kun_id = rkun_id 
  ${with_rule === "true" ? "and tsu.tipe_berkas_id = tsur.tipe_berkas_id" : ""}
  ${
    with_rule === "true"
      ? "left join mst_tipe_berkas mtb on tsur.tipe_berkas_id = mtb.tipe_berkas_id "
      : "left join mst_tipe_berkas mtb on tsu.tipe_berkas_id = mtb.tipe_berkas_id "
  }
  left join pegawai pgc on pgc.peg_id = tsu.created_by 
  left join pegawai pgu on pgu.peg_id = tsu.updated_by 
  where 
    tgl between :start_date :: date and :end_date :: date
    ${png_id ? "and png_id = :png_id" : "--"}
    ${no_mr ? "and ps_mrn = :no_mr" : "--"}
    order by tgl desc, rkun_id asc
    `;

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        start_date: start_date || moment().format("YYYY-MM-DD"),
        end_date: end_date || moment().format("YYYY-MM-DD"),
        png_id: png_id,
        no_mr: no_mr,
      },
    })
    .then((data) => {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("New Sheet");
      let arr = [];
      worksheet.columns = [
        { header: "Id", key: "rkun_id" },
        { header: "Nomer MR", key: "ps_mrn" },
        { header: "Nama Pasien", key: "ps_namalengkap" },
        { header: "ID Penanggung", key: "rkun_png_noncash" },
        { header: "Penanggung", key: "png_nama" },
        { header: "Waktu Masuk", key: "inap_waktu" },
        { header: "Waktu Keluar", key: "inap_waktu_keluar" },
        { header: "Waktu Lunas", key: "tgl" },
        { header: "Kelas", key: "ref_kls_inap_nama" },
        { header: "Ruang", key: "ref_ruang_nama" },
        { header: "Berkas", key: "nama_berkas" },
        { header: "Creator", key: "creator" },
        { header: "Updator", key: "updator" },
        { header: "Penutup", key: "peg_tutup" },
        { header: "Respon", key: "si_ube_filename" },
        { header: "Waktu Insert", key: "created_at" },
        { header: "Waktu Update", key: "updated_at" },
        { header: "Locked", key: "is_locked" },
      ];
      data.map((kun) => {
        // let found = arr.find((el) => el == kun.kun_id);
        // arr.push(kun.kun_id);
        // if (found) {
        //   return worksheet.addRow([
        //     kun.rkun_id,
        //     kun.ps_mrn,
        //     kun.ps_namalengkap,
        //     kun.rkun_png_noncash,
        //     kun.png_nama,
        //     kun.inap_waktu,
        //     kun.inap_waktu_keluar,
        //     kun.tgl,
        //     kun.ref_kls_inap_nama,
        //     kun.ref_ruang_nama,
        //     kun.nama_berkas,
        //     kun.creator,
        //     kun.updator,
        //     kun.si_ube_filename
        //       ? (kun.input_type === "image" ? process.env.SERVER_URL : "") +
        //         kun.si_ube_filename
        //       : null,
        //     kun.created_at,
        //     kun.updated_at,
        //     kun.is_locked,
        //   ]);
        // }
        return worksheet.addRow([
          kun.rkun_id,
          kun.ps_mrn,
          kun.ps_namalengkap,
          kun.rkun_png_noncash,
          kun.png_nama,
          kun.inap_waktu,
          kun.inap_waktu_keluar,
          kun.tgl,
          kun.ref_kls_inap_nama,
          kun.ref_ruang_nama,
          kun.nama_berkas,
          kun.creator,
          kun.updator,
          kun.peg_tutup,
          kun.si_ube_filename
            ? (kun.input_type === "image"
                ? `${process.env.SERVER_URL}/public`
                : "") + kun.si_ube_filename
            : null,
          kun.created_at,
          kun.updated_at,
          kun.is_locked,
        ]);

        // arr.push([kun.kun_id, kun.nama_berkas, kun.si_ube_filename]);
        // arr.push(kun.nama_berkas);
        // arr.push(kun.si_ube_filename);
      });
      res.status(200);
      res.setHeader("Content-Type", "text/xlsx");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=teststream.xlsx"
      );
      workbook.xlsx.write(res).then(() => {
        res.end();
      });
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal memuat", 500, err);
    });
  // worksheet.addRow([2, "Mary Sue", 22]);
  // res.status(200);
  // res.setHeader("Content-Type", "text/xlsx");
  // res.setHeader(
  //   "Content-Disposition",
  //   "attachment; filename=teststream.xlsx"
  // );
  // workbook.xlsx.write(res).then(()=>{
  //   res.end()
  // });
};

exports.lockUbe = (req, res) => {
  let { is_locked, si_ube_id } = req.body;
  if (typeof is_locked != "boolean" || !si_ube_id) {
    return res.status(400).json({
      status: 400,
      message: "Data Masih Kosong",
      data: {},
    });
  }
  return models.trx_si_ube
    .update(
      {
        is_locked: is_locked,
      },
      {
        where: {
          si_ube_id: si_ube_id,
        },
      }
    )
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      if (err.message == 400) {
        return error(req, res, {}, "Tidak Terauthentikasi", 400, err);
      }
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.removeUbe = (req, res) => {
  let { si_ube_id } = req.query;
  let { peg_id } = req.user;
  return models.trx_si_ube
    .update(
      {
        si_ube_filename: null,
        updated_by: peg_id,
      },
      {
        where: {
          si_ube_id: si_ube_id,
        },
      }
    )
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      if (err.message == 400) {
        return error(req, res, {}, "Tidak Terauthentikasi", 400, err);
      }
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
// select
// tgl,
// rkun_png_noncash,
// ap.png_nama,
//   b.inap_id,
//   c.ref_ruang_nama,
//   c.ref_kls_inap_nama
// from
//   (
//     select
//       distinct (
//         select
//           inap_id
//         from
//           inap a
//         where
//           a.inap_id_kunjungan = b.inap_id_kunjungan
//         order by
//           inap_id desc
//         limit
//           1
//       ) as inap_id_akhir,
//       tgl,
//       rkun_png_noncash
//     from
//       rencana_kunjungan,
//       kunjungan,
//       inap b,
//       pembayaran_kasir
//     where
//       rkun_id = kun_id_rencana_kunjungan
//       and kun_id = inap_id_kunjungan
//       and rkun_id = id_rkun
//       and kun_inap is true
//       and jenis_pembayaran in (1, 4)
//   ) as jjj
//   left join inap b on inap_id = inap_id_akhir
//   left join asp_penanggung ap on ap.png_id = rkun_png_noncash
//   left join v_tempat_tidur_5 c on c.ref_tmpt_tdr_id = inap_tempat_tidur
// where
//   tgl = now() :: date

exports.exportUbeData = (req, res) => {
  const { start_date, end_date, no_mr, ps_nama } = req.query;

  const query = `
select  
rkun_id,
tgl,
rkun_png_noncash,
ap.png_nama,
  b.inap_id, 
  c.ref_ruang_nama,
  c.ref_kls_inap_nama,
  b.inap_waktu,
  b.inap_waktu_keluar,
        vp.ps_mrn,
        vp.ps_namalengkap,
  vp.ps_no_jmn_non_cash,
  vp.ps_telpon  
from 
  (
    select 
      distinct (
        select 
          inap_id 
        from 
          inap a 
        where 
          a.inap_id_kunjungan = b.inap_id_kunjungan 
        order by 
          inap_id desc 
        limit 
          1
      ) as inap_id_akhir, 
      tgl, 
      rkun_png_noncash,
      rkun_id,
      rkun_id_pasien
    from 
      rencana_kunjungan, 
      kunjungan, 
      inap b, 
      pembayaran_kasir 
    where 
      rkun_id = kun_id_rencana_kunjungan 
      and kun_id = inap_id_kunjungan 
      and rkun_id = id_rkun 
      and jenis_pembayaran in (1, 4)
      and kun_inap is true 
      and (no_kwitansi ilike '%KWI-PAY%' 
      or no_kwitansi ilike '%KWI-RTR%')
      and rkun_inap = 't' 
  AND id_parent IS NULL 
) as jjj 
  left join inap b on inap_id = inap_id_akhir 
  left join v_pasien vp on vp.ps_id = rkun_id_pasien
  left join asp_penanggung ap on ap.png_id = rkun_png_noncash  
  left join v_tempat_tidur_5 c on c.ref_tmpt_tdr_id = inap_tempat_tidur 
where 
  tgl between :start_date :: date and :end_date :: date
  ${no_mr ? "and ps_mrn = :no_mr" : "--"}
  ${ps_nama ? "and ps_namalengkap ilike :ps_nama" : "--"}
  order by tgl
    `;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        start_date: start_date || moment().format("YYYY-MM-DD"),
        end_date: end_date || moment().format("YYYY-MM-DD"),
        no_mr: no_mr,
        ps_nama: ps_nama ? `%${ps_nama}%` : "",
      },
    })
    .then((data) => {
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet("New Sheet");
      let arr = [];
      worksheet.columns = [
        { header: "Id", key: "rkun_id" },
        { header: "Nomer MR", key: "ps_mrn" },
        { header: "Nama Pasien", key: "ps_namalengkap" },
        { header: "Penanggung", key: "png_nama" },
        { header: "ID Penanggung", key: "rkun_png_noncash" },
        { header: "Waktu Masuk", key: "inap_waktu" },
        { header: "Waktu Keluar", key: "inap_waktu_keluar" },
        { header: "Waktu Lunas", key: "tgl" },
        { header: "Kelas", key: "ref_kls_inap_nama" },
        { header: "Ruang", key: "ref_ruang_nama" },
      ];
      data.map((kun) => {
        return worksheet.addRow([
          kun.rkun_id,
          kun.ps_mrn,
          kun.ps_namalengkap,
          kun.png_nama,
          kun.rkun_png_noncash,
          kun.inap_waktu,
          kun.inap_waktu_keluar,
          kun.tgl,
          kun.ref_kls_inap_nama,
          kun.ref_ruang_nama,
        ]);
      });
      res.status(200);
      res.setHeader("Content-Type", "text/xlsx");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=teststream.xlsx"
      );
      workbook.xlsx.write(res).then(() => {
        res.end();
      });
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal memuat", 500, err);
    });
};

exports.addUbeRule = (req, res) => {
  const { penanggung_id, tipe_berkas_id, order } = req.body;

  if (!penanggung_id || !tipe_berkas_id) {
    return error(req, res, {}, "check parameter", 400, null);
  }

  return models.trx_si_ube_rule
    .findOne({
      where: {
        penanggung_id,
        tipe_berkas_id,
      },
    })
    .then((ada) => {
      console.log(ada);
      if (ada) {
        throw new Error("Rule sudah ada");
      }
      return models.trx_si_ube_rule.create({
        penanggung_id,
        tipe_berkas_id,
        order: order || null,
      });
    })
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.deleteUbeRule = (req, res) => {
  const { ube_rule_id } = req.query;

  if (!ube_rule_id) {
    return error(req, res, {}, "check parameter", 400, null);
  }
  return models.trx_si_ube_rule
    .destroy({
      where: {
        ube_rule_id,
      },
    })
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.listFiles = (req, res) => {
  return models.mst_tipe_berkas
    .findAll()
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.addFile = (req, res) => {
  const { nama_berkas, input_type, placeholder } = req.body;
  if (!nama_berkas || !input_type) {
    return error(req, res, {}, "Check Parameter", 400, null);
  }
  return models.mst_tipe_berkas
    .findOne({
      where: {
        nama_berkas,
      },
    })
    .then((berkas) => {
      if (berkas) {
        throw new Error("Berkas sudah ada!");
      }
      return models.mst_tipe_berkas.create({
        nama_berkas: nama_berkas,
        input_type: input_type,
        placeholder: placeholder,
      });
    })
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.putFile = (req, res) => {
  const { tipe_berkas_id, input_type, nama_berkas, placeholder } = req.body;
  if (!tipe_berkas_id) {
    return error(req, res, {}, "Check Parameter", 400, null);
  }
  return models.mst_tipe_berkas
    .update(
      {
        nama_berkas: nama_berkas,
        input_type: input_type,
        placeholder: placeholder,
      },
      {
        where: {
          tipe_berkas_id,
        },
      }
    )
    .then((payload) => {
      return success(req, res, payload, "Data termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
