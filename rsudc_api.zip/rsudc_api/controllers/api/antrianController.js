const models = require("../../models");
const { Op } = require("sequelize");
const { success, error } = require("../../helpers/utility/response");
const moment = require("moment");
const { sequelize } = require("../../models");
const axiosBPJS = require("./BPJS/Helpers/axios");
const { default: axios } = require("axios");

exports.batalAppointment = (req, res) => {
  const { mr } = req.user;
  const { alasan, rkun_id } = req.body;
  if (!alasan || !rkun_id) {
    return error(req, res, {}, "Isi alasan & kunjungan", 400, null);
  }
  return models.pasien
    .findOne({
      where: {
        ps_mrn: {
          [Op.eq]: sequelize.literal(`mrn_decoded('${mr}')`),
        },
      },
    })
    .then((kunjungan) => {
      if (!kunjungan) {
        throw new Error("Pasien tidak ditemukan.");
      }

      return models.rencana_kunjungan
        .findOne({
          where: {
            rkun_id_pasien: kunjungan.ps_id,
            rkun_id: rkun_id,
          },
        })
        .then((found) => {
          if (!found) {
            throw new Error("Kunjungan tidak ditemukan.");
          }
          // else if (moment().isSame(moment(found.tglkunjung, 'YYYY-MM-DD'), 'day')) {
          //   throw new Error("Pembatalan hanya bisa di H-1.")
          // }
          return models.jml_nelp
            .findOne({
              where: {
                rkunid: rkun_id,
              },
            })
            .then((nelp) => {
              if (nelp && nelp.no_surat_kontrol) {
                return axios
                  .get(
                    `http://192.168.200.8:8080/RsudcApi/hapusrencanakontrol?nosuratkontrol=${nelp.no_surat_kontrol}&user=rsudc_mobile`
                  )
                  .then((kontrol) => {
                    if (
                      kontrol.data.metaData &&
                      kontrol.data.metaData.code !== 200
                    ) {
                      throw new Error(kontrol.data.metaData.message);
                    }
                  });
              }
            })
            .then(() => {
              return models.rencana_kunjungan.update(
                {
                  rkun_batal_alasan: alasan,
                  rkun_batal: true,
                },
                {
                  where: {
                    rkun_id_pasien: kunjungan.ps_id,
                    rkun_id: rkun_id,
                  },
                }
              );
            });
        })
        .then(() => {
          return kunjungan;
        });
    })
    .then((kunjungan) => {
      return axiosBPJS
        .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/updatewaktu`, {
          kodebooking: `${rkun_id}`,
          taskid: 99,
          waktu: moment.utc().format("x"),
        })
        .then(() => {
          return models.jml_nelp
            .update(
              {
                task_id: 99,
                error_jkn: null,
              },
              {
                where: {
                  rkunid: rkun_id,
                },
              }
            )
            .then(() => {
              return kunjungan;
            });
        })
        .catch((err) => {
          return kunjungan;
        });
    })
    .then((kunjungan) => {
      return models.rencana_kunjungan.findOne({
        where: {
          rkun_id_pasien: kunjungan.ps_id,
          rkun_id: rkun_id,
        },
      });
    })
    .then((payload) => {
      return success(req, res, payload, "Berhasil batal.");
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal batal", 500, err);
    });
};

exports.historyAppointment = (req, res) => {
  const { mr } = req.user;
  const { tipe, id_poli, is_today } = req.query;
  let dateHistory = {
    [Op.gt]: moment().format("YYYY-MM-DD"),
  };
  if (tipe === "last_year") {
    dateHistory = {
      [Op.gte]: moment().subtract(1, "year").format("YYYY-MM-DD"),
    };
  } else if (tipe === "today") {
    dateHistory = {
      [Op.eq]: moment().format("YYYY-MM-DD"),
    };
  }
  return models.pasien
    .findOne({
      where: {
        ps_mrn: {
          [Op.eq]: sequelize.literal(`mrn_decoded('${mr}')`),
        },
      },
    })
    .then((kunjungan) => {
      if (!kunjungan) {
        throw new Error("Pasien tidak ditemukan.");
      }
      return models.rencana_kunjungan.findAll({
        attributes: [
          "rkun_id",
          "rkun_id_layanan",
          "rkun_nomor",
          "rkun_id_pasien",
          "rkun_tgl_visit",
          "rkun_id_dokter",
          "rkun_batal",
          "rkun_reservasi",
          "is_bpjs",
        ],
        where: {
          rkun_reservasi: true,
          rkun_id_layanan: id_poli
            ? id_poli
            : {
                [Op.not]: null,
              },
          rkun_tgl_visit: is_today
            ? moment().format("YYYY-MM-DD")
            : dateHistory,
          rkun_id_pasien: kunjungan.ps_id,
          rkun_batal: is_today
            ? {
                [Op.or]: [null, false],
              }
            : {
                [Op.or]: [null, false, true],
              },
        },
        include: [
          {
            model: models.ref_layanan,
            required: true,
            as: "layanan",
            attributes: ["ref_layanan_id", "ref_layanan_nama"],
          },
          {
            model: models.pegawai,
            required: true,
            as: "dokter",
            attributes: ["peg_id", "peg_nama"],
          },
          {
            model: models.trx_midtrans,
            as: "midtrans",
            order: [["trx_mt_id", "DESC"]],
            limit: 1,
            attributes: [
              "trx_mt_rkun_id",
              "trx_mt_gross_amount",
              "trx_mt_transaction_status",
              "trx_mt_token",
              "trx_mt_order_id",
            ],
          },
          {
            model: models.foto_dokter,
            as: "foto_dokter",
          },
          {
            model: models.billing,
            attributes: ["bill_id_rec", "bill_id_rkun"],
            as: "billing",
          },
        ],
        order: [["rkun_id", "DESC"]],
      });
    })
    .then((payload) => {
      return success(req, res, payload, "Berhasil Memuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal Memuat", 500, err);
    });
};

exports.historyAppDetail = (req, res) => {
  const { rkun_id } = req.query;
  if (!rkun_id) {
    return error(req, res, {}, "Isi ID Kunjungan", 400, null);
  }
  const { mr } = req.user;
  return models.jml_nelp
    .findOne({
      where: {
        rkunid: rkun_id,
        mrn: {
          [Op.eq]: sequelize.literal(`mrn_decoded('${mr}')`),
        },
      },
      include: {
        model: models.rencana_kunjungan,
        as: "rencana_kunjungan",
        required: true,
        attributes: ["rkun_id", "rkun_waktu"],
      },
    })
    .then((payload) => {
      if (!payload) {
        return error(req, res, {}, "Tidak ditemukan", 400, null);
      }
      return success(req, res, payload, "Berhasil Memuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal Memuat", 500, err);
    });
};
