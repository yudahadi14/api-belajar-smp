const { validationResult, body } = require("express-validator");
const { error } = require("../Helpers/responser");

exports.validDaftarBaruWSRS = [
  body("nomorkartu")
    .notEmpty()
    .withMessage("Mohon isi Nomor Kartu!.")
    .isString()
    .withMessage("Nomor Kartu String!."),
  body("nik")
    .notEmpty()
    .withMessage("Mohon isi NIK!.")
    .isString()
    .withMessage("NIK String!."),
  body("nohp")
    .notEmpty()
    .withMessage("Mohon isi No HP!.")
    .isString()
    .withMessage("No HP String!."),
  body("alamat")
    .notEmpty()
    .withMessage("Mohon isi No Alamat!.")
    .isString()
    .withMessage("Alamat String!."),
  body("kodeprop")
    .notEmpty()
    .withMessage("Mohon isi Kode Prop!.")
    .isString()
    .withMessage("Kode Prop String!."),
  body("namaprop")
    .notEmpty()
    .withMessage("Mohon isi Nama Prop!.")
    .isString()
    .withMessage("Nama Prop String!."),
  body("kodedati2")
    .notEmpty()
    .withMessage("Mohon isi kodedati2!.")
    .isString()
    .withMessage("kodedati2 String!."),
  body("kodedati2")
    .notEmpty()
    .withMessage("Mohon isi Nama kodedati2!.")
    .isString()
    .withMessage("Nama kodedati2 String!."),
  body("kodekec")
    .notEmpty()
    .withMessage("Mohon isi kodekec!.")
    .isString()
    .withMessage("kodekec String!."),
  body("namakec")
    .notEmpty()
    .withMessage("Mohon isi Nama namakec!.")
    .isString()
    .withMessage("Nama namakec String!."),
  body("kodekel")
    .notEmpty()
    .withMessage("Mohon isi kodekel!.")
    .isString()
    .withMessage("kodekel String!."),
  body("namakel")
    .notEmpty()
    .withMessage("Mohon isi Nama namakel!.")
    .isString()
    .withMessage("Nama namakel String!."),
  body("rt")
    .notEmpty()
    .withMessage("Mohon isi rt!.")
    .isString()
    .withMessage("rt String!."),
  body("rw")
    .notEmpty()
    .withMessage("Mohon isi Nama rw!.")
    .isString()
    .withMessage("Nama rw String!."),
  (req, res, next) => {
    const errors = validationResult(req);
    // console.log(errors);
    if (!errors.isEmpty()) {
      const firstError = errors.array().map((error) => error.msg)[0];
      return error(req, res, {}, firstError, 201, null);
    }
    next();
  },
];
