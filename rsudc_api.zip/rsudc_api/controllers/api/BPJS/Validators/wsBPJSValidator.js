const { validationResult, body } = require("express-validator");
const { error } = require("../Helpers/responser");

exports.validUpdateJadwal = [
  body("kodepoli").notEmpty().withMessage("Mohon isi Nomor kodepoli!."),
  body("kodesubspesialis")
    .notEmpty()
    .withMessage("Mohon isi kodesubspesialis!."),
  body("kodedokter").notEmpty().withMessage("Mohon isi kodedokter!."),
  body("jadwal.*.hari").notEmpty().withMessage("Mohon isi Jadwal Hari!."),
  body("jadwal.*.buka").notEmpty().withMessage("Mohon isi Jadwal Buku!."),
  body("jadwal.*.tutup").notEmpty().withMessage("Mohon isi Jadwal Tutup!."),
  (req, res, next) => {
    const errors = validationResult(req);
    // console.log(errors);
    if (!errors.isEmpty()) {
      const firstError = errors.array().map((error) => error.msg)[0];
      return error(req, res, {}, firstError, 201, null);
    }
    next();
  },
];
exports.validDaftarBaruWSBPJS = [
  body("kodebooking")
    .notEmpty()
    .withMessage("Mohon isi Kode Booking!.")
    .isString()
    .withMessage("Kode Booking String!."),
  body("jenispasien")
    .notEmpty()
    .withMessage("Mohon isi Jenis Pasien!.")
    .isString()
    .withMessage("Jenis Pasien Int!."),
  body("nomorkartu")
    .notEmpty()
    .withMessage("Mohon isi Nomor Kartu!.")
    .isString()
    .withMessage("Nomor Kartu String!."),
  body("nik")
    .notEmpty()
    .withMessage("Mohon isi NIK!.")
    .isString()
    .withMessage("NIK String!."),
  body("nohp")
    .notEmpty()
    .withMessage("Mohon isi No HP!.")
    .isString()
    .withMessage("No HP String!."),
  body("kodepoli")
    .notEmpty()
    .withMessage("Mohon isi Kode Poli!.")
    .isString()
    .withMessage("Kode Poli String!."),
  body("namapoli")
    .notEmpty()
    .withMessage("Mohon isi Nama Poli!.")
    .isString()
    .withMessage("Nama Poli String!."),
  body("pasienbaru")
    .notEmpty()
    .withMessage("Mohon isi Pasien Baru!.")
    .isInt()
    .withMessage("Pasien Baru Int!."),
  body("norm")
    .notEmpty()
    .withMessage("Mohon isi RM!.")
    .isString()
    .withMessage("RM String!."),
  body("tanggalperiksa")
    .notEmpty()
    .withMessage("Mohon isi Tanggal Periksa!.")
    .isString()
    .withMessage("tanggalperiksa String!."),
  body("kodedokter")
    .notEmpty()
    .withMessage("Mohon isi Kode Dokter!.")
    .isInt()
    .withMessage("kodedokter Int!."),
  body("namadokter")
    .notEmpty()
    .withMessage("Mohon isi Nama Dokter!.")
    .isString()
    .withMessage("Nama Dokter String!."),
  body("jampraktek")
    .notEmpty()
    .withMessage("Mohon isi Jam Praktek!.")
    .isString()
    .withMessage("tanggalperiksa String!."),
  body("jeniskunjungan")
    .notEmpty()
    .withMessage("Mohon isi Jenis Kunjungan!.")
    .isInt()
    .withMessage("Jenis Kunjungan String!."),
  body("nomorreferensi")
    .notEmpty()
    .withMessage("Mohon isi Nomor Referensi!.")
    .isString()
    .withMessage("nomorreferensi String!."),
  body("nomorantrean")
    .notEmpty()
    .withMessage("Mohon isi Nomor Antrean!.")
    .isString()
    .withMessage("nomorantrean String!."),
  body("angkaantrean")
    .notEmpty()
    .withMessage("Mohon isi Angka Antrean!.")
    .isInt()
    .withMessage(" Angka Antrea Int!."),

  (req, res, next) => {
    const errors = validationResult(req);
    // console.log(errors);
    if (!errors.isEmpty()) {
      const firstError = errors.array().map((error) => error.msg)[0];
      return error(req, res, {}, firstError, 201, null);
    }
    next();
  },
];
