const axios = require("axios");
const moment = require("moment");
const decrypt = require("./decrypt");
const signatureBPJS = require("./signature");
const axiosBPJS = axios.create({
  baseURL:
    process.env.NODE_ENV === "production"
      ? process.env.BPJS_URL
      : process.env.BPJS_URL_DEV,
  timeout: 1000 * 30,
});

axiosBPJS.interceptors.request.use(
  async (config) => {
    console.log(config);
    let utcTime = moment.utc().format("X");
    const { signature, timestamp, cons_id, user_key, key } =
      signatureBPJS(utcTime);
    config.headers = {
      ...config.headers,
      "X-cons-id": cons_id,
      "X-timestamp": timestamp,
      "X-signature": signature,
      user_key: user_key,
      internal_key: key
    };
    return config;
  },
  (error) => {
    Promise.reject(error);
  }
);
axiosBPJS.interceptors.response.use(
  function (response) {
    if (response.data) {
      let key = response.config.headers.internal_key;
      return {
        response: response.data.response
          ? decrypt(response.data.response, key)
          : null,
        metadata: response.data.metadata,
        metaData: response.data.metaData,
      };
      // return axios
      //   .post("http://192.168.200.7:8000/decrypt", {
      //     key: key,
      //     data: response.data.response,
      //   })
      //   .then((payload) => {
      //     if (payload.data && payload.data.data) {
      //       return {
      //         response: payload.data.data,
      //       };
      //     }

      //     return null;
      //   });
    }
    return {
      response: null,
      metadata: {
        message: "Ada Kesalahan",
        code: 400,
      },
    };
  },
  function (error) {

    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    return Promise.reject(error);
  }
);
module.exports = axiosBPJS;
