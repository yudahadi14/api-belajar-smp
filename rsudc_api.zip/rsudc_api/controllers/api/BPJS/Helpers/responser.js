const log4js = require("log4js");
const moment = require("moment");

log4js.configure({
  appenders: {
    app: {
      type: "file",
      filename: `log/bpjs/${moment().format("YYYY_MM_DD")}.log`,
    },
    log: {
      type: "console",
    },
  },
  categories: {
    default: { appenders: ["app", "log"], level: "error" },
    log: {
      appenders: ["log"],
      level: "all",
    },
  },
});

let logger = log4js.getLogger("app");
let loggerConsole = log4js.getLogger("log");

exports.success = (
  req,
  res,
  data = null,
  message = "Berhasil",
  status = 200,
  tipe
) => {
  loggerConsole.info(message);
  if (tipe === "v-claim") {
    return res.json({
      metaData: {
        code: status,
        message: message,
      },
      metadata: {
        code: status,
        message: message,
      },
      response: data,
    });
  }
  return res.json({
    metaData: {
      code: status,
      message: message,
    },
    metadata: {
      code: status,
      message: message,
    },
    response: data,
  });
};

exports.error = (
  req,
  res,
  data = null,
  message = "Ada Kesalahan",
  status = 500,
  err,
  tipe
) => {
  const sequelizePattern = /SequelizeDatabaseError/gi;
  const seqErr = (val) => {
    return sequelizePattern.test(val);
  };
  if (err && err.response) {
    logger.fatal(err.response);
    message = err.response.message;
    status = status ? status : 201;
  } else if (err) {
    console.warn(err);
    logger.fatal(err.toString());
    if (err.message) {
      message = err.message;
      status = 201;
    }
  } else {
    console.warn(err);
  }
  if (tipe === "v-claim") {
    return res.json({
      metadata: {
        code: status,
        message: err
          ? seqErr(err.stack)
            ? "Ada Kesalahan"
            : message
          : message,
      },
      metaData: {
        code: status,
        message: err ? (seqErr(err.stack) ? "Ada Kesalahan" : message) : message,
      },  
      response: data,
    });
  }
  return res.status(status).json({
    metadata: {
      code: status,
      message: err ? (seqErr(err.stack) ? "Ada Kesalahan" : message) : message,
    },
    metaData: {
      code: status,
      message: err ? (seqErr(err.stack) ? "Ada Kesalahan" : message) : message,
    },
    response: data,
  });
};
