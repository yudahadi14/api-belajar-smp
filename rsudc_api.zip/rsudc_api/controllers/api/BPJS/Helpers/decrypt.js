const CryptoJS = require("crypto-js");
const LzString = require("lz-string");
let _try = 0;
const decrypt = (encrypted, key) => {
  let hasil = null;
  try {
    _try += 1;
    console.log(_try);
    let secretKeyHash = CryptoJS.SHA256(key).toString(CryptoJS.enc.Hex);
    let iv = secretKeyHash.slice(0, 32);
    iv = CryptoJS.enc.Hex.parse(iv);
    secretKeyHash = CryptoJS.enc.Hex.parse(secretKeyHash);
    let ct = CryptoJS.enc.Base64.parse(encrypted);
    let decrypted = CryptoJS.AES.decrypt({ ciphertext: ct }, secretKeyHash, {
      mode: CryptoJS.mode.CBC,
      // padding: CryptoJS.pad.Pkcs7,
      iv: iv,
    });
    hasil = decrypted.toString(CryptoJS.enc.Utf8);
    hasil = LzString.decompressFromEncodedURIComponent(hasil);
  } catch (error) {
    if (_try < 4) {
      decrypt(encrypted, key);
    }
    throw new Error(error);
  }
  _try = 0;
  return hasil ? JSON.parse(hasil) : null;
};

module.exports = decrypt;
