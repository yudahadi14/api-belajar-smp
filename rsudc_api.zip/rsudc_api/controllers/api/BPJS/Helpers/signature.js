const crypto = require("crypto");
const moment = require("moment");

const signatureBPJS = (utcTime) => {
  let time = parseInt((new Date().getTime() / 1000).toFixed(0));
  // let utcTimeOld = moment("1970-01-01 00:00:00").utc().format("X");
  // let timestamp = utcTime - utcTimeOld;
  let secretKey =
    process.env.NODE_ENV === "production"
      ? process.env.BPJS_SEC_KEY
      : process.env.BPJS_SEC_KEY_DEV;
  let consID =
    process.env.NODE_ENV === "production"
      ? process.env.BPJS_CONS_ID
      : process.env.BPJS_CONS_ID_DEV;
  let uKey =
    process.env.NODE_ENV === "production"
      ? process.env.BPJS_USER_KEY
      : process.env.BPJS_USER_KEY_DEV;
  let signature = crypto
    .createHmac("sha256", `${secretKey}`)
    .update(`${consID}&${utcTime}`)
    .digest("base64");
  return {
    key: `${consID}${secretKey}${utcTime}`,
    signature: signature,
    timestamp: utcTime,
    cons_id: `${consID}`,
    user_key: `${uKey}`,
  };
};
module.exports = signatureBPJS;
