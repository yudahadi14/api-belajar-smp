const jwt = require("jsonwebtoken");
const { Op } = require("sequelize");
const { error } = require("../Helpers/responser");

const verifyAuth = (token) => {
  return jwt.verify(token, "RSUDCKBR!DG!NG", function (err, decoded) {
    if (err) {
      return {
        error: err,
      };
    }
    return decoded;
  });
};

const authMid = (req, res, next) => {
  const token = req.header("x-token");
  const username = req.header("x-username");
  if (!token || !username) {
    return error(req, res, {}, "Not Authenticated", 201, {});
  }
  const verify = verifyAuth(token);

  if (verify.error) {
    if (verify.error.name === "JsonWebTokenError") {
      return error(req, res, {}, "Not Authenticated", 201, {});
    } else if (verify.error.name == "TokenExpiredError") {
      return error(req, res, {}, "Token Expired!.", 201, {});
    } else {
      return error(req, res, {}, "Not Authenticated", 201, {});
    }
  }
  req.user = verify;
  return next();
};
module.exports = authMid;
