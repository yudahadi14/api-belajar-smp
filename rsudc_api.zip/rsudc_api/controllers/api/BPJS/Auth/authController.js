const moment = require("moment");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { Op } = require("sequelize");
const models = require("../../../../models");
const { error, success } = require("../Helpers/responser");


const signAuthJwt = (data) => {
  return jwt.sign(data, "RSUDCKBR!DG!NG", {
    expiresIn: "30m",
  });
};

exports.getToken = (req, res) => {
  //   const { username, password } = req.body;
  const username = req.headers["x-username"];
  const password = req.headers["x-password"];

  if (!username || !password) {
    return error(req, res, {}, "Not Authenticated", 201, null);
  }

  return models.mst_auth_bridging
    .findOne({
      where: {
        auth_bridging_username: username,
      },
    })
    .then((payload) => {
      if(!payload){
        throw new Error("Username / password tidak sesuai");
      }
      let authenticated = bcrypt.compareSync(
        password,
        payload.auth_bridging_password
      );
      if (!authenticated) {
        throw new Error("Username / password tidak sesuai");
      }
      const authToken = signAuthJwt({
        auth_bridging_name: payload.auth_bridging_name,
      });
      return success(req, res, { token: authToken }, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
