const axios = require("axios");
const moment = require("moment");
const { Op, QueryTypes } = require("sequelize");
const {
  getDiffDate,
  getHari,
  getPeriodeTanggal,
  sisaKuota,
  getDOW,
} = require("../../../../helpers/utility/common");
const { waktuTungguDefault } = require("../../../../helpers/utility/variables");
const { sequelize } = require("../../../../models");
const models = require("../../../../models");
const { error, success } = require("../Helpers/responser");
// exports.authMid = (r)
//   .then((payload) => {
//       return success(req, res, { list: payload }, "OK", 1);
//     })
//     .catch((err) => {
//       return error(req, res, {}, "Ada Kesalahan", 500, err);
//     });

exports.statusAntrian = async (req, res) => {
  const { kodepoli, kodedokter, tanggalperiksa, jampraktek } = req.body;

  if (!kodepoli || !kodedokter || !tanggalperiksa || !jampraktek) {
    return error(req, res, {}, "Invalid Parameters", 201, null);
  }
  const isDateValid = moment(tanggalperiksa, "YYYY-MM-DD", true).isValid();
  if (!isDateValid) {
    return error(
      req,
      res,
      {},
      "Format Tanggal Tidak Sesuai, Format : YYYY-MM-DD",
      201,
      null
    );
  }
  if (getDiffDate(tanggalperiksa) > 0) {
    return error(req, res, {}, "Hanya Untuk Hari ini dan Mendatang", 201, null);
  }
  const query = `
  select 
  rkun_tgl_visit, 
  a.nmpoli,
  a.dr_bpjs_nama,
  kd_layananpoli_rsc,
  sum(terlayani) as terlayani, 
  sum(takterlayani) as takterlayani, 
  sum(tot) as total 
from 
  (
    SELECT 
      count(*) as tot, 
      rkun_nomor, 
      nmpoli, 
      rkun_waktu,
      vd.dr_bpjs_nama, 
      vd.dr_bpjs_kode,
      rkun_tgl_visit, 
      kd_layananpoli_rsc,
      case when rkun_waktu = 1 then 'Pagi' else 'Sore' End as waktu, 
      count(
        case when png_nama is not null then 'Datang' end
      ) as terlayani, 
      count(
        case when png_nama is null then 'Tidak Datang' end
      ) as takterlayani, 
      png_nama 
    FROM 
      rencana_kunjungan 
      join refpoli_bpjs on kd_layananpoli_rsc = rkun_id_layanan 
      join dokter_bpjs vd on vd.dr_bpjs_id_layanan = rkun_id_layanan
      left join asp_penanggung on png_id = rkun_png_noncash 
    WHERE 
      kdpoli = :kodepoli
      and rkun_inap is false 
      and vd.dr_bpjs_kode = ':kodedokter'
      and rkun_id_layanan not in(23, 24, 39, 121, 25, 52) 
      and rkun_tgl_visit = :tanggalperiksa
      and rkun_nomor != 0 
      and rkun_waktu = 1 
      and (
        rkun_batal is null 
        or rkun_batal is false
      ) 
    group by 
      rkun_tgl_visit, 
      kd_layananpoli_rsc,
      nmpoli, 
      rkun_waktu, 
      png_nama, 
      rkun_nomor,
      vd.dr_bpjs_nama,
      vd.dr_bpjs_kode
    order by 
      rkun_nomor asc
  ) a 
group by 
  rkun_tgl_visit, 
  nmpoli,
  kd_layananpoli_rsc,
  dr_bpjs_nama
  `;

  // let hariPeriksa = getHari(
  //   moment(tanggalperiksa, "YYYY-MM-DD").format("dddd")
  // );
  let poliBPJS = null;
  let dataDokter = null;
  let qDokter = 0;
  let qBerjalanDokter = 0;
  let qBerjalanDokterBPJS = 0;
  let currAntri = 0;
  let quota = null;
  return Promise.all([
    getPoliBPJS(kodepoli).then((poli) => {
      poliBPJS = poli;
    }),
    getDokter(kodedokter).then((dokter) => {
      dataDokter = dokter;
    }),
  ])
    .then(() => {
      return Promise.all([
        this.quotaDokterHFIS(
          kodepoli,
          tanggalperiksa,
          kodedokter,
          jampraktek,
          dataDokter.dr_bpjs_id_peg,
          poliBPJS.kd_layananpoli_rsc
        ).then((dokter) => {
          quota = dokter;
        }),
        getCurrentAntri(tanggalperiksa, poliBPJS.kd_layananpoli_rsc).then(
          (antri) => {
            currAntri = antri;
          }
        ),
      ]);
    })
    .then(() => {
      return models.sequelize
        .query(query, {
          type: QueryTypes.SELECT,
          replacements: {
            kodepoli: kodepoli,
            tanggalperiksa: tanggalperiksa,
            kodedokter: kodedokter,
          },
        })
        .then((payload) => {
          if (!payload || payload.length === 0) {
            throw new Error("Antrian tidak ditemukan");
          }
          return {
            namapoli: payload[0].nmpoli,
            namadokter: payload[0].dr_bpjs_nama,
            totalantrean: Number(payload[0].total),
            sisaantrean:
              Number(payload[0].total) - Number(payload[0].terlayani),
            antreanpanggil: currAntri,
            sisakuotajkn: quota.sisa_bpjs,
            kuotajkn: quota.quota_bpjs,
            sisakuotanonjkn: quota.sisa_umum,
            kuotanonjkn: quota.quota_umum,
            keterangan: "",
          };
        });
    })
    .then((body) => {
      return success(req, res, body, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

const getPoliBPJS = async (poli_id) => {
  return models.refpoli_bpjs
    .findOne({
      where: {
        kdpoli: poli_id,
      },
    })
    .then((data) => {
      if (!data) {
        throw new Error("Poli Tidak Ditemukan");
      }
      return data;
    });
};

const getKalenderLibur = async (date) => {
  return models.kalender_libur
    .findOne({
      where: {
        kal_libur_tgl: date,
      },
    })
    .then((data) => {
      if (!data) {
        return false;
      }
      return data;
    });
};

const getJadwalBukaPoli = async (tanggal, id_poli, jam) => {
  let { periode1, periode2, tahun } = getPeriodeTanggal(tanggal);
  let hari = getHari(moment(tanggal, "YYYY-MM-DD").format("dddd"));

  return models.jadwal_buka_poli
    .findOne({
      where: {
        id_poli: id_poli,
        jam_tutup: {
          [Op.lte]: jam,
        },
        hari: hari,
        blnint1: periode1,
        blnint2: periode2,
        thn: tahun,
        active: true,
      },
    })
    .then((data) => {
      if (data) {
        throw new Error("Poli Tutup");
      }
      return data;
    });
};
const getPatientBlackList = async (ps_id) => {
  return models.pasienblacklist.findOne({
    where: {
      id_ps: ps_id,
    },
  });
};

const getDataPasien = async ({ noMr, noka, nik, nohp }) => {
  let query = `select 
  a.ps_id, 
  ps_mrn, 
  ps_namalengkap, 
  umurws(ps_tgllahir) as umur, 
  umur(ps_tgllahir) as umur2, 
  is_lansia(ps_tgllahir), 
  ps_no_jmn_non_cash 
from 
  pasien a 
  join asp_pasien b on a.ps_id = b.ps_id 
where 
  a.ps_id != '-1' 
  ${noka ? "and ps_no_jmn_non_cash = :noka" : "--"}
  ${noMr ? "and a.ps_mrn = mrn_decoded(:mrn)" : "--"}
  ${nik ? "and ps_nomor_identitas = :nik" : "--"}
  ${nohp ? "and ps_telpon = :nohp" : "--"}
  
limit 1;
`;

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        mrn: noMr,
        noka: noka,
        nik: nik,
        nohp: nohp,
      },
    })
    .then((payload) => {
      if (!payload[0]) {
        throw new Error("Pasien tidak ditemukan");
      }
      return payload[0];
    });
};

const getDokter = async (code) => {
  return models.dokter_bpjs
    .findOne({
      where: {
        dr_bpjs_kode: `${code}`,
      },
    })
    .then((data) => {
      if (!data) {
        throw new Error("Dokter Tidak Ditemukan");
      }
      return data;
    });
};

const getOffDokter = async (layananId, day) => {
  const query = `
  select 
  quota_id_layanan,
  hari,
  ref_layanan_nama
from
  quota_pasien_poli
  left join ref_layanan on ref_layanan_id = quota_id_layanan
where
  hari = :day
  and active = false
  and ref_layanan_id = :idLayanan
  and quota_id_layanan =(
    select
      id_layanan
    from
      sms_id_layanan
    where
      active is true
      and id_layanan = :idLayanan);
`;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        idLayanan: layananId,
        day: day,
      },
    })
    .then((payload) => {
      return payload[0];
    });
};

const sumTime = (props) => {
  // let args = Array.prototype.slice.call(arguments);
  let i = 0;
  let hour = 0;

  props.forEach((time) => {
    let arr = time ? time.split(":") : "07";
    hour = parseInt(arr[0]);
    i += parseInt(arr[0]) * 60 + parseInt(arr[1]);
  });
  hour = Math.floor(i / 60);
  i = i % 60;
  console.log(`${hour < 10 ? "0" + hour : hour}:${i < 10 ? "0" + i : i}`);
  return `${hour < 10 ? "0" + hour : hour}:${i < 10 ? "0" + i : i}`;
};

const noAntri5 = async (idLayanan, date, psID, doctorId) => {
  const query = "select fnoantri(:idLayanan,:date,1,:psID, :doctorId) as data";
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        idLayanan: idLayanan,
        date: date,
        psID: psID,
        doctorId: doctorId,
      },
    })
    .then((payload) => {
      return payload[0];
    });
};
exports.quotaDokterHFIS = async (
  kd_poli,
  tanggal,
  kode_dokter,
  waktu,
  doctor_id,
  id_layanan
) => {
  let url = "http://192.168.200.8:8080/RsudcApi/datadokter";
  let var_kd_poli = (key) => {
    let kd = key;
    switch (key) {
      case "HIV":
        kd = "INT";
        break;
      default:
        kd = kd_poli;
        break;
    }
    return kd;
  };
  return axios
    .get(url, {
      params: {
        jnskontrol: 2,
        kdpoli: var_kd_poli(kd_poli),
        tglrencanakontrol: tanggal,
      },
    })
    .then((payload) => {
      let data = payload.data;
      let hari = getDOW(tanggal);
      if (!data.metaData) {
        throw new Error("Gagal Memuat Dokter");
      } else if (kd_poli == "GND" && hari < 7) {
        if (!data.response.list) {
          data.response = {
            list: [],
          };
        }
        data.response.list.push({
          kodeDokter: "267752",
          namaDokter: "Dwi Suprihartono, dr. Sp.Ort",
          jadwalPraktek: "08:00 - 12:00",
          kapasitas: "25",
        });
      } else if (data.metaData.code !== 200) {
        if (data.metaData.code >= 404) {
          throw new Error("BPJS Offline, coba beberapa saat lagi.");
        }
        throw new Error(data.metaData.message);
      } else if (
        !data.response ||
        !data.response.list ||
        data.response.list.length === 0
      ) {
        throw new Error("Jadwal Kosong BPJS");
      }
      let list = data.response.list.filter((item) => item.kapasitas > 0);
      return list;
    })
    .then((dokter_bpjs) => {
      let split_ = waktu.split("-");
      if (!split_[0] || !split_[1]) {
        throw new Error("Mohon coba kembali.");
      }
      let start_ = split_ ? split_[0].substring(0, 5) : "00:00";
      let end_ = split_ ? split_[1].substring(0, 5) : "00:00";
      let wak = `${start_}-${end_}`;
      wak = String(wak.replace(/\s/g, ""));
      let found = dokter_bpjs.find(
        (el) =>
          el.kodeDokter === String(kode_dokter) &&
          String(el.jadwalPraktek.replace(/\s/g, "")) === wak
      );
      if (!found) {
        throw new Error("Jadwal Kosong");
      }
      return found.kapasitas;
    })
    .then((kapasitas) => {
      let qBerjalanDokter = 0;
      let qBerjalanDokterBPJS = 0;
      return Promise.all([
        this.kuotaBerjalanDokter(tanggal, doctor_id, id_layanan).then(
          (quota) => {
            qBerjalanDokter = quota;
          }
        ),
        this.kuotaBerjalanDokter(tanggal, doctor_id, id_layanan, true).then(
          (quota) => {
            qBerjalanDokterBPJS = quota;
          }
        ),
      ]).then(() => {
        // if (id_layanan == 87) {
        //   return {
        //     quota_bpjs: sisaKuota(20).bpjs,
        //     quota_umum: sisaKuota(20).umum,
        //     sisa_bpjs: sisaKuota(20).bpjs - qBerjalanDokterBPJS,
        //     sisa_umum: sisaKuota(20).umum - qBerjalanDokter,
        //   };
        // } else
        if (id_layanan == 51) {
          return {
            quota_bpjs: sisaKuota(kapasitas > 60 ? kapasitas : 60).bpjs,
            quota_umum: sisaKuota(kapasitas > 60 ? kapasitas : 60).umum,
            sisa_bpjs:
              sisaKuota(kapasitas > 60 ? kapasitas : 60).bpjs -
              qBerjalanDokterBPJS,
            sisa_umum:
              sisaKuota(kapasitas > 60 ? kapasitas : 60).umum - qBerjalanDokter,
          };
        } else {
          if (kd_poli == "GND" && doctor_id == 267752) {
            return {
              quota_bpjs: 0,
              quota_umum: sisaKuota(kapasitas).umum + 7,
              sisa_bpjs: 0,
              sisa_umum: sisaKuota(kapasitas).umum + 7 - qBerjalanDokter,
            };
          }
          return {
            quota_bpjs: sisaKuota(kapasitas).bpjs,
            quota_umum: sisaKuota(kapasitas).umum,
            sisa_bpjs: sisaKuota(kapasitas).bpjs - qBerjalanDokterBPJS,
            sisa_umum: sisaKuota(kapasitas).umum - qBerjalanDokter,
          };
        }
      });
    });
};

exports.quotaDokter = async (id_poli, day, tgl, id_dokter) => {
  let bulan = moment(tgl, "YYYY-MM-DD").format("M");
  let tahun = moment(tgl, "YYYY-MM-DD").format("YYYY");
  periode = 1;
  if (bulan >= 1 && bulan <= 3) {
    periode = 1;
  } else if (bulan >= 4 && bulan <= 6) {
    periode = 4;
  } else if (bulan >= 7 && bulan <= 9) {
    periode = 7;
  } else if (bulan >= 10 && bulan <= 12) {
    periode = 10;
  }
  const query =
    "select sum(quota_dr) as jumlah from jadwal_praktek_dokter where id_poli= :id_poli and hari_praktek=:day and periodeawal=:periode and thn=:tahun and id_dokter = :id_dokter";
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        day: day,
        periode: periode.toString(),
        tahun: tahun,
        id_dokter: id_dokter,
        id_poli: id_poli,
      },
    })
    .then((payload) => {
      if (payload[0] && payload[0].jumlah) {
        return Number(payload[0].jumlah);
      }
      return 0;
    });
  // echo $sql;
};

exports.kuotaBerjalanDokter = async (tgl, id_dokter, id_poli, bpjs) => {
  let query = `SELECT 
  COUNT(*) as jumlah 
FROM 
  rencana_kunjungan 
where 
  rkun_reservasi is true 
  and rkun_tgl_visit = :tgl 
  and rkun_id_layanan = :id_poli 
  and rkun_id_dokter = :id_dokter
  and rkun_batal is not true
  ${bpjs ? "and is_bpjs is true" : "and is_bpjs is not true"}
`;
  if (id_poli == 87) {
    query = `SELECT 
    COUNT(*) as jumlah 
  FROM 
    rencana_kunjungan 
  where 
    rkun_reservasi is true 
    and rkun_tgl_visit = :tgl 
    and rkun_id_layanan = :id_poli 
    and rkun_batal is not true
    ${bpjs ? "and is_bpjs is true" : "and is_bpjs is not true"}
  `;
  }
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        tgl: tgl,
        id_dokter: id_dokter,
        id_poli: id_poli,
      },
    })
    .then((payload) => {
      if (payload[0] && payload[0].jumlah) {
        return Number(payload[0].jumlah);
      }
      return 0;
    });
};

const getKunjungan = async (psId, tgl) => {
  return models.rencana_kunjungan.findOne({
    where: {
      rkun_reservasi: true,
      rkun_batal: {
        [Op.or]: [false, null],
      },
      rkun_id_pasien: psId,
      rkun_tgl_visit: tgl,
    },
    order: [["rkun_tgl_visit", "DESC"]],
  });
};

const getCurrentAntri = async (tgl, idLayanan) => {
  const query = `
  select 
  no_all as nomor
from
  NO_ANTRI
where
  id_layanan = :idLayanan
  and group_antri = 6
  and reset is false
  and no_all != 0
  and cast(tgl_no_antri as date) = :tgl
  and sudah_dipanggil is true
order by
  no_all asc
limit
  1
`;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        tgl: tgl,
        idLayanan: idLayanan,
      },
    })
    .then((payload) => {
      if (payload[0] && payload[0].nomor) {
        return payload[0].nomor;
      }
      return "0";
    });
};

const prosesAppointment = async ({
  layananId,
  day,
  psId,
  dateYMD,
  namaDokter,
  namaPoli,
  norm,
  idDokter,
  kdpoli,
  kodedokter,
  waktu,
  is_bpjs,
  norujukan,
  jeniskunjungan,
  nomorkartu,
}) => {
  // let quotaPoli = await countQuota(day, layananId);
  let qDokter = 0;
  let qBerjalanDokter = 0;
  let qBerjalanDokterBPJS = 0;
  let quota = null;
  return Promise.all([
    this.quotaDokterHFIS(
      kdpoli,
      dateYMD,
      kodedokter,
      waktu,
      idDokter,
      layananId
    ).then((data) => {
      quota = data;
    }),
    // this.kuotaBerjalanDokter(dateYMD, idDokter, layananId).then((quota) => {
    //   qBerjalanDokter = quota;
    // }),
    // this.kuotaBerjalanDokter(dateYMD, idDokter, layananId, true).then(
    //   (quota) => {
    //     qBerjalanDokterBPJS = quota;
    //   }
    // ),
    getKunjungan(psId, dateYMD).then((data) => {
      if (data) {
        throw new Error(
          "Nomor Antrean Hanya Dapat Diambil 1 Kali Pada Tanggal Yang Sama"
        );
      }
    }),
  ])
    .then(() => {
      if (is_bpjs) {
        if (quota.sisa_bpjs <= 0) {
          throw new Error("Quota Kosong");
        }
      } else if (quota.sisa_umum <= 0) {
        throw new Error("Quota Kosong");
      }
      return checkHourQuota(layananId, day).then((result) => {
        if (!result) {
          throw new Error("Quota Kosong!");
        }
        return noAntri5(layananId, dateYMD, psId, idDokter).then((antri) => {
          return antri;
        });
      });
    })
    .then((antri) => {
      let result = antri.data.split("_");
      return this.getVisitTime(result[2], layananId, day).then((waktu) => {
        return models.v_pasien
          .findOne({
            where: {
              ps_id: psId,
            },
            attributes: [
              [sequelize.literal("is_lansia(ps_tgllahir)"), "lansia"],
              "ps_mrn",
            ],
          })
          .then((payload) => {
            return models.jml_nelp
              .create({
                nmpasien: payload.nama_pasien,
                no_telp: "",
                mrn: payload.ps_mrn,
                proses: true,
                id_jns_app_layanan: 3,
                status_id: 1,
                rkunid: result[1],
                is_lansia: payload.lansia,
                poli: namaPoli,
                nm_dokter: namaDokter,
                is_bpjs: is_bpjs,
                pesanfoot1: `Pkl ${waktu.one} s/d ${waktu.two} WIB`,
                pesanfoot2: `Pkl ${waktu.one} s/d ${waktu.two} WIB`,
                tglkunjung: dateYMD,
                reg: "REG",
                noantri: result[2],
                no_rujukan: norujukan,
                jeniskunjungan: jeniskunjungan,
                kdpoli_bpjs: kdpoli || null,
                // no_surat_kontrol: no_kontrol || null,
                nobpjs: nomorkartu || null,
                jenis_reservasi: 3,
              })
              .then(() => {
                return {
                  nomorantrean: `${result[2]}`,
                  angkaantrean: Number(result[2]),
                  kodebooking: `${result[1]}`,
                  norm: `${payload.ps_mrn}`,
                  namapoli: `${namaPoli}`,
                  namadokter: `${namaDokter}`,
                  estimasidilayani: Number(
                    moment(
                      `${dateYMD + " " + waktu.two}`,
                      "YYYY-MM-DD hh:mm"
                    ).format("x")
                  ),
                  sisakuotajkn: is_bpjs ? quota.sisa_bpjs - 1 : quota.sisa_bpjs,
                  kuotajkn: quota.quota_bpjs,
                  sisakuotanonjkn: !is_bpjs
                    ? quota.sisa_umum - 1
                    : quota.sisa_umum,
                  kuotanonjkn: quota.quota_umum,
                  keterangan:
                    "Peserta harap 60 menit lebih awal guna pencatatan administrasi.",
                };
              });
          });
      });
    });
};

const countQuota = async (day, layanan_id) => {
  return models.quota_pasien_poli.findOne({
    attributes: ["quota_id_layanan", "jml_quota"],
    where: {
      hari: day,
      quota_id_layanan: layanan_id,
    },
  });
};

const countPatient = async (date) => {
  return models.rencana_kunjungan.count({
    where: {
      rkun_batal: {
        [Op.not]: true,
      },
      rkun_reservasi: true,
      rkun_tgl_visit: date,
    },
  });
};

const checkHourQuota = async (layananId, day) => {
  const query = `
  SELECT 
  id_quota, 
  jamke1, 
  jamke2, 
  jamke3, 
  jamke4, 
  jamke5, 
  jamke6, 
  quota_id_layanan, 
  hari, 
  jambuka, 
  jml_quota, 
  interv, 
  intervaljam, 
  intervaljam2 
from 
  quota_pasien_poli 
where 
  quota_id_layanan = :layananId 
  and hari = :day
`;

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        layananId: layananId,
        day: day,
      },
    })
    .then((payload) => {
      console.log(payload);
      return payload[0];
    });
};

exports.getVisitTime = async (noAntri, layananId, day) => {
  const result = await checkHourQuota(layananId, day);
  if (!result) {
    throw new Error("Quota Kosong!");
  }

  let intervalOne = result.intervaljam;
  let intervalTwo = result.intervaljam2;
  let q1 = result.jamke1;
  let q2 = result.jamke2;
  let q3 = result.jamke3;
  let q4 = result.jamke4;
  let q5 = result.jamke5;
  let q6 = result.jamke6;
  let timeStart = result.jambuka;
  let minute = "00:00";
  let openTime = sumTime([timeStart, minute]);
  let QueueNo = noAntri + 1;
  let message = "";
  let nextTime = "";
  let nextTimeLagi = "";
  if (QueueNo <= q1) {
    nextTime = sumTime([openTime, intervalOne]);
    // message = "PKL " + openTime + " s/d " + nextTime + " WIB";
    message = {
      one: openTime,
      two: nextTime,
    };
  }

  if (QueueNo > q1 && QueueNo <= q1 + q2) {
    nextTime = sumTime([openTime, intervalOne]);
    nextTimeLagi = sumTime([openTime, intervalOne, intervalTwo]);
    message = {
      one: nextTime,
      two: nextTimeLagi,
    };
  }

  if (QueueNo > q1 + q2 && QueueNo <= q1 + q2 + q3) {
    nextTime = sumTime([openTime, intervalOne, intervalTwo]);
    nextTimeLagi = sumTime([openTime, intervalOne, intervalTwo, intervalTwo]);
    // message = "PKL " + nextTime + " s/d " + nextTimeLagi + " WIB";
    message = {
      one: nextTime,
      two: nextTimeLagi,
    };
  }

  if (QueueNo > q1 + q2 + q3 && QueueNo <= q1 + q2 + q3 + q4) {
    nextTime = sumTime([openTime, intervalOne, intervalTwo, intervalTwo]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    // message = "PKL " + nextTime + " s/d " + nextTimeLagi + " WIB";
    message = {
      one: nextTime,
      two: nextTimeLagi,
    };
  }
  if (QueueNo > q1 + q2 + q3 + q4 && QueueNo <= q1 + q2 + q3 + q4 + q5) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    // message = "PKL " + nextTime + " s/d " + nextTimeLagi + " WIB";
    message = {
      one: nextTime,
      two: nextTimeLagi,
    };
  }
  if (
    QueueNo > q1 + q2 + q3 + q4 + q5 &&
    QueueNo <= q1 + q2 + q3 + q4 + q5 + q6
  ) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    // message = "PKL " + nextTime + " s/d " + nextTimeLagi + " WIB";
    message = {
      one: nextTime,
      two: nextTimeLagi,
    };
  }
  if (
    QueueNo > q1 + q2 + q3 + q4 + q5 + q6 &&
    QueueNo <= q1 + q2 + q3 + q4 + q5 + q6 + q6
  ) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    // message = "PKL " + nextTime + " s/d " + nextTimeLagi + " WIB";
    message = {
      one: nextTime,
      two: nextTimeLagi,
    };
  }
  if (
    QueueNo > q1 + q2 + q3 + q4 + q5 + q6 + q6 &&
    QueueNo <= q1 + q2 + q3 + q4 + q5 + q6 + q6 + q6
  ) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    // message = "PKL " + nextTime + " s/d " + nextTimeLagi + " WIB";
    message = {
      one: nextTime,
      two: nextTimeLagi,
    };
  }
  if (QueueNo > q1 + q2 + q3 + q4 + q5 + q6 + q6 + q6) {
    if (q1 > 0 && q2 == 0) {
      nextTime = sumTime([openTime, intervalOne]);
      nextTimeLagi = sumTime([openTime, intervalOne, intervalTwo]);
    } else {
      if (q1 > 0 && q2 > 0 && q3 == 0) {
        nextTime = sumTime([openTime, intervalOne, intervalTwo]);
        nextTimeLagi = sumTime([
          openTime,
          intervalOne,
          intervalTwo,
          intervalTwo,
        ]);
      }
      if (q1 > 0 && q2 > 0 && q3 > 0 && q4 == 0) {
        nextTime = sumTime([openTime, intervalOne, intervalTwo, intervalTwo]);
        nextTimeLagi = sumTime([
          openTime,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
      }
      if (q1 > 0 && q2 > 0 && q3 > 0 && q4 > 0 && q5 == 0) {
        nextTime = sumTime([
          openTime,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
        nextTimeLagi = sumTime([
          openTime,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
      }
      if (q1 > 0 && q2 > 0 && q3 > 0 && q4 > 0 && q5 > 0 && q6 == 0) {
        nextTime = sumTime([
          openTime,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
        nextTimeLagi = sumTime([
          openTime,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
      }
      // message = "PKL " + nextTime + " s/d " + nextTime + " WIB";
      message = {
        one: nextTime,
        two: nextTimeLagi,
      };
    }
  }
  return message;
};

exports.ambilAntrian = async (req, res) => {
  const {
    nomorkartu,
    nik,
    nohp,
    kodepoli,
    norm,
    tanggalperiksa,
    kodedokter,
    jampraktek,
    jeniskunjungan,
    nomorreferensi,
  } = req.body;
  if (
    // !nomorkartu ||
    // !nik ||
    // !nohp ||
    !kodepoli ||
    // !norm ||
    !tanggalperiksa ||
    !kodedokter
    // ||
    // !jampraktek
    // ||
    // !jeniskunjungan
    // ||
    // !nomorreferensi
  ) {
    return error(req, res, {}, "Invalid Parameters", 201, null);
  }
  const isDateValid = moment(tanggalperiksa, "YYYY-MM-DD", true).isValid();
  if (!isDateValid) {
    return error(req, res, {}, "Date Format : YYYY-MM-DD", 201, null);
  }
  // 1. Hanya untuk hari mendatang
  if (getDiffDate(tanggalperiksa) >= 0) {
    return error(req, res, {}, "Hanya Untuk Hari Mendatang", 201, null);
  }

  let tglLibur = null;
  let poliBPJS = null;
  let hariPeriksa = null;
  let dataPasien = null;
  let pasienBlacklist = null;
  let namaPoli = null;
  let isDokterOff = null;
  let dataDokter = null;
  hariPeriksa = getHari(moment(tanggalperiksa, "YYYY-MM-DD").format("dddd"));
  let isBPJS = false;

  // 2. Cek Hari Libur

  if (tglLibur === tanggalperiksa) {
    return error(req, res, {}, "Poli Tutup", 201);
  }

  if (hariPeriksa === "Minggu") {
    return error(req, res, {}, "Minggu Tutup", 201);
  }
  // 3. Cek BDM, BDA
  if (kodepoli.toUpperCase() === "BDM") {
    return error(
      req,
      res,
      {},
      "Poli Bedah Mulut Harap Datang Langsung",
      201,
      err
    );
  } else if (kodepoli.toUpperCase() === "BDA") {
    return error(
      req,
      res,
      {},
      "Poli Bedah Anak Harap Datang Langsung",
      201,
      err
    );
  }
  if (nomorkartu) {
    isBPJS = true;
  }

  return Promise.all([
    getKalenderLibur(tanggalperiksa).then((libur) => {
      if (libur) {
        throw new Error("Poli atau Dokter tidak tersedia");
      }
    }),
    getDataPasien({
      noMr: norm,
      noka: nomorkartu,
      nik: nik,
      nohp: nohp,
    }).then((pasien) => {
      dataPasien = pasien;
    }),
    getPoliBPJS(kodepoli).then((poli) => {
      poliBPJS = poli;
    }),
    getDokter(kodedokter).then((dokter) => {
      dataDokter = dokter;
    }),
  ])
    .then(() => {
      return getPatientBlackList(dataPasien.ps_id).then((patient) => {
        if (patient) {
          throw new Error("Pasien masuk dalam daftar blacklist");
        }
      });
    })
    .then(() => {
      let jambooking = jampraktek.split("-");

      if (poliBPJS.kd_layananpoli_rsc == 1148) {
        namaPoli = "Bed.Thor.Kardiovask";
      } else if (poliBPJS.kd_layananpoli_rsc == 51) {
        namaPoli = "Fisiotherapy";
      } else if (poliBPJS.kd_layananpoli_rsc == 10) {
        namaPoli = "Rehab.Med.Spesialis";
      } else if (poliBPJS.kd_layananpoli_rsc == 60) {
        namaPoli = "Tumbuh Kembang";
      } else {
        namaPoli = poliBPJS.nmpoli;
      }
      return getJadwalBukaPoli(
        tanggalperiksa,
        poliBPJS.kd_layananpoli_rsc,
        `${jambooking[1]}:00`
      );
    })
    .then(() => {
      return getOffDokter(poliBPJS.kd_layananpoli_rsc, hariPeriksa).then(
        (off) => {
          if (off) {
            throw new Error(`Dokter ${off.dr_bpjs_nama} tidak tersedia`);
          }
        }
      );
    })
    .then(() => {
      return prosesAppointment({
        layananId: poliBPJS.kd_layananpoli_rsc,
        day: hariPeriksa,
        psId: dataPasien.ps_id,
        dateYMD: tanggalperiksa,
        namaDokter: dataDokter.dr_bpjs_nama,
        namaPoli: namaPoli,
        norm: norm,
        idDokter: dataDokter.dr_bpjs_id_peg,
        kdpoli: kodepoli,
        kodedokter,
        waktu: jampraktek,
        is_bpjs: isBPJS,
        norujukan: nomorreferensi,
        jeniskunjungan: jeniskunjungan,
        nomorkartu: nomorkartu,
      });
    })
    .then((payload) => {
      return success(req, res, payload, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.sisaAntrian = async (req, res) => {
  const { kodebooking } = req.body;

  let tgl = "";
  let hari = "";
  let hariPeriksa = "";
  let idLayanan = null;
  let idDokter = null;

  return models.rencana_kunjungan
    .findOne({
      where: {
        rkun_id: kodebooking,
      },
      include: [
        {
          model: models.refpoli_bpjs,
          required: true,
          as: "poli_bpjs",
        },
        {
          model: models.dokter_bpjs,
          required: false,
          as: "dokter_bpjs",
        },
      ],
    })
    .then((kun) => {
      if (!kun) {
        throw new Error("Kode Booking Tidak Ditemukan");
      }
      tgl = kun.rkun_tgl_visit;
      hari = moment(kun.rkun_tgl_visit, "YYYY-MM-DD").format("dddd");
      hariPeriksa = getHari(hari);
      idLayanan = kun.rkun_id_layanan;
      idDokter = kun.rkun_id_dokter;
      return kun;
    })
    .then((kun) => {
      return Promise.all([
        this.kuotaBerjalanDokter(tgl, idDokter, idLayanan).then((quo) => {
          qDokter = quo;
        }),
        getCurrentAntri(tgl, idLayanan).then((quo) => {
          currAntri = quo;
        }),
      ]).then(() => {
        return kun;
      });
    })
    .then((kunjungan) => {
      let sisaAntri =
        kunjungan.rkun_nomor > currAntri ? kunjungan.rkun_nomor - currAntri : 0;
      let body = {
        nomorantrean: kunjungan.rkun_nomor.toString(),
        namapoli: kunjungan.poli_bpjs.nmpoli,
        namadokter: kunjungan.dokter_bpjs
          ? kunjungan.dokter_bpjs.dr_bpjs_nama
          : "DOKTER RSUD",
        sisaantrean: sisaAntri,
        antreanpanggil: currAntri,
        waktutunggu: Number(sisaAntri) * waktuTungguDefault,
        keterangan: "",
      };
      return success(req, res, body, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.batalAntrian = (req, res) => {
  const { kodebooking, keterangan } = req.body;
  if (!kodebooking || !keterangan) {
    return error(req, res, {}, "Isi Parameter Kode dan Keterangan", 201, null);
  }
  return models.rencana_kunjungan
    .findOne({
      where: {
        rkun_id: kodebooking,
        rkun_batal: false,
      },
    })
    .then((exist) => {
      if (!exist) {
        throw new Error("Antrean Tidak Ditemukan atau Sudah Dibatalkan");
      }
    })
    .then(() => {
      return models.billing
        .findOne({
          where: {
            bill_id_rkun: kodebooking,
          },
        })
        .then((bill) => {
          if (bill) {
            throw new Error(
              "Pasien Sudah Dilayani, Antrean Tidak Dapat Dibatalkan"
            );
          }
        });
    })
    .then(() => {
      return models.rencana_kunjungan.update(
        {
          rkun_batal: true,
          rkun_batal_alasan: keterangan ? keterangan.substring(0, 255) : "",
        },
        {
          where: {
            rkun_id: kodebooking,
          },
        }
      );
    })
    .then((payload) => {
      return res.json({
        metadata: {
          message: "Ok",
          code: 200,
        },
      });
      // return success(req, res, null, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.checkIn = (req, res) => {
  const { kodebooking, waktu } = req.body;
  return models.rencana_kunjungan
    .findOne({
      where: {
        rkun_id: kodebooking,
      },
    })
    .then((exist) => {
      if (!exist) {
        throw new Error("Antrian tidak ditemukan");
      }
    })
    .then(() => {
      return models.rencana_kunjungan.update(
        {
          rkun_waktu_daftarulang: moment().format("YYYY-MM-DD"),
        },
        {
          where: {
            rkun_id: kodebooking,
          },
        }
      );
    })
    .then((payload) => {
      return res.json({
        metadata: {
          message: "Ok",
          code: 200,
        },
      });
      // return success(req, res, null, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.jadwalOperasi = (req, res) => {
  const { tanggalawal, tanggalakhir } = req.body;
  const isDateValidStart = moment(tanggalawal, "YYYY-MM-DD", true).isValid();
  if (!isDateValidStart) {
    return error(
      req,
      res,
      {},
      "Format Tanggal Tidak Sesuai, Format : YYYY-MM-DD",
      201,
      null
    );
  }
  const isDateValidEnd = moment(tanggalakhir, "YYYY-MM-DD", true).isValid();
  if (!isDateValidEnd) {
    return error(
      req,
      res,
      {},
      "Format Tanggal Tidak Sesuai, Format : YYYY-MM-DD",
      201,
      null
    );
  }
  let diff = moment(tanggalawal).diff(moment(tanggalakhir), "days");

  if (diff > 0) {
    return error(
      req,
      res,
      {},
      "Tanggal awal tidak boleh lebih dari tanggal akhir",
      201,
      null
    );
  }
  if (!tanggalawal || !tanggalakhir) {
    return error(
      req,
      res,
      {},
      "Isi Parameter Tanggal Awal dan Tanggal Akhir",
      201,
      null
    );
  }
  return models.antrian_operasi
    .findAll({
      attributes: [
        "opr_antri_id",
        "opr_antri_validasi_awal_waktu",
        "opr_antri_tgl",
        "opr_antri_tindakan",
      ],
      where: {
        opr_antri_tgl: {
          [Op.between]: [tanggalawal, tanggalakhir],
        },
      },
      include: [
        {
          attributes: ["ps_no_jmn_non_cash", "ps_id"],
          model: models.asp_pasien,
          as: "pasien",
          required: true,
        },
        {
          attributes: ["id_refpoli", "kd_layananpoli_rsc", "nmpoli", "kdpoli"],
          model: models.refpoli_bpjs,
          as: "poli_bpjs",
          required: true,
          limit: 1,
        },
        {
          attributes: ["inap_id", "inap_id_kunjungan"],
          model: models.inap,
          as: "inap",
          required: true,
          include: {
            attributes: ["kun_id", "kun_id_rencana_kunjungan"],
            model: models.kunjungan,
            required: true,
            as: "kunjungan",
          },
        },
      ],
    })
    .then((payload) => {
      const arr = [];
      payload.map((item) => {
        return arr.push({
          kodebooking: item.inap.kunjungan.kun_id_rencana_kunjungan,
          tanggaloperasi: item.opr_antri_validasi_awal_waktu
            ? item.opr_antri_validasi_awal_waktu
            : item.opr_antri_tgl,
          jenistindakan: item.opr_antri_tindakan,
          kodepoli: item.poli_bpjs[0] ? item.poli_bpjs[0].kdpoli : "POLI RS",
          namapoli: item.poli_bpjs[0] ? item.poli_bpjs[0].nmpoli : "POLI RS",
          terlaksana: item.opr_antri_validasi_akhir_waktu ? 1 : 0,
          nopeserta: item.pasien.ps_no_jmn_non_cash,
          lastupdate: item.opr_antri_mode_revisi_waktu
            ? Number(
                moment(item.opr_antri_mode_revisi_waktu, "YYYY-MM-DD").format(
                  "x"
                )
              )
            : Number(moment(item.opr_antri_tgl, "YYYY-MM-DD").format("x")),
        });
      });
      return success(req, res, { list: arr }, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.jadwalOperasiPasien = (req, res) => {
  const { nopeserta } = req.body;
  let tanggalawal = moment().format("YYYY-MM-DD");
  if (!nopeserta) {
    return error(req, res, {}, "Isi nopeserta", 201, null);
  }
  if (nopeserta.length !== 13) {
    return error(req, res, {}, "Nomer Kartu Tidak Valid", 400, null);
  }
  return models.antrian_operasi
    .findAll({
      attributes: [
        "opr_antri_id",
        "opr_antri_validasi_awal_waktu",
        "opr_antri_tgl",
        "opr_antri_tindakan",
        "opr_antri_id_rkun_id",
        "opr_antri_noantri_bpjs",
      ],
      // where: {
      //   opr_antri_tgl: {
      //     [Op.gte]: tanggalawal,
      //   },
      // },
      include: [
        {
          model: models.asp_pasien,
          attributes: ["ps_no_jmn_non_cash", "ps_id"],
          as: "pasien",
          required: true,
          where: {
            ps_no_jmn_non_cash: nopeserta,
          },
        },
        {
          model: models.refpoli_bpjs,
          attributes: ["id_refpoli", "kd_layananpoli_rsc", "nmpoli", "kdpoli"],
          as: "poli_bpjs",
          required: true,
          limit: 1,
        },
        // {
        //   attributes: ["rkun_id"],
        //   model: models.rencana_kunjungan,
        //   required: true,
        //   as: "rencana_kunjungan",
        // },
        // {
        //   model: models.inap,
        //   attributes: ["inap_id", "inap_id_kunjungan"],
        //   as: "inap",
        //   required: true,
        //   include: {
        //     attributes: ["kun_id", "kun_id_rencana_kunjungan"],
        //     model: models.kunjungan,
        //     required: true,
        //     as: "kunjungan",
        //   },
        // },
      ],
    })
    .then((payload) => {
      const arr = [];
      payload.map((item) => {
        return arr.push({
          kodebooking: `${item.opr_antri_id_rkun_id}`,
          tanggaloperasi: item.opr_antri_validasi_awal_waktu
            ? item.opr_antri_validasi_awal_waktu
            : item.opr_antri_tgl,
          jenistindakan: item.opr_antri_tindakan,
          kodepoli: item.poli_bpjs[0].kdpoli,
          namapoli: item.poli_bpjs[0].nmpoli,
          terlaksana: item.opr_antri_validasi_akhir_waktu ? 1 : 0,
        });
      });
      return success(
        req,
        res,
        {
          list: arr,
        },
        "OK",
        200
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.daftarBaru = (req, res) => {
  let {
    nomorkartu,
    nik,
    nomorkk,
    nama,
    jeniskelamin,
    tanggallahir,
    nohp,
    alamat,
    kodeprop,
    namaprop,
    kodedati2,
    namadati2,
    kodekec,
    namakec,
    kodekel,
    namakel,
    rw,
    rt,
  } = req.body;
  let pattern = /\D/;
  if (nomorkartu.length !== 13 || pattern.test(nomorkartu)) {
    return error(req, res, {}, "Format Nomor Kartu Tidak Sesuai", 201, null);
  }
  if (nik.length !== 16 || pattern.test(nik)) {
    return error(req, res, {}, "Format NIK Tidak Sesuai", 201, null);
  }
  if (getDiffDate(tanggallahir) <= 0) {
    return error(req, res, {}, "Format Tanggal Lahir Tidak Sesuai ", 201, null);
  }

  return models.pasienonline
    .findOne({
      where: {
        [Op.or]: [
          {
            regpsonline_id_jns_id_nomor: nik,
          },
          {
            regpsonline_nopenjamin: nomorkartu,
          },
        ],
      },
    })
    .then((pasien) => {
      if (pasien) {
        throw new Error("Data Peserta Sudah Pernah Dientrikan");
      }
    })
    .then(() => {
      alamat = alamat ? alamat.toUpperCase() : "";
      rt = rt ? rt.toUpperCase() : "";
      rw = rw ? rw.toUpperCase() : "";
      namakel = namakel ? namakel.toUpperCase() : "";
      namakec = namakec ? namakec.toUpperCase() : "";
      namadati2 = namadati2 ? namadati2.toUpperCase() : "";
      namaprop = namaprop ? namaprop.toUpperCase() : "";

      nama = nama ? nama.toUpperCase() : "";

      return models.pasienonline.create({
        regpsonline_id_jns_id: 1,
        regpsonline_id_jns_id_nomor: nik,
        regpsonline_namalengkap: nama,
        regpsonline_namapanggilan: "",
        regpsonline_tmptlahir: "",
        regpsonline_tgllahir: tanggallahir,
        regpsonline_jnskelamin: jeniskelamin === "L" ? 1 : 2,
        regpsonline_alamat: `${alamat} ${rt}/${rw} ${namakel} ${namakec} ${namadati2} ${namaprop}`,
        regpsonline_rtrw: rt + "/" + rw,
        regpsonline_kelurahan: namakel || null,
        regpsonline_kecamatan: namakec || null,
        regpsonline_kotadati: namadati2,
        regpsonline_kdpos: "",
        regpsonline_propinsi: namaprop || null,
        regpsonline_notelpon: nohp || null,
        regpsonline_agama: 0,
        regpsonline_nilaiyakin: null,
        regpsonline_textnilaiyakin: null,
        regpsonline_stsnikah: 0,
        regpsonline_stswarganegara: null,
        regpsonline_infoibu: "-",
        regpsonline_infoayah: "-",
        regpsonline_infoistrisuami: "-",
        regpsonline_nopenjamin: nomorkartu,
        regpsonline_nmwalidarurat: "-",
        regpsonline_telponwalidarurat: "-",
        regpsonline_fileupload: "-",
        regpsonline_filephoto: "-",
        regpsonline_flig_flag: false,
        regpasienonline_notelpon2: null,
        regpsonline_alamat_domisili: null,
        regpsonline_stspendidikan: null,
        regpsonline_penjamin: nomorkartu ? 2 : 1,
        regpsonline_bahasa: null,
        regpsonline_infokerja: null,
        regpsonline_produk_id: null,
        regpsonline_tgl_berkunjung: null,
      });
    })
    .then((pasien) => {
      if (pasien) {
        return success(
          req,
          res,
          {
            norm: "999999",
          },
          "Harap datang ke admisi untuk melengkapi data rekam medis."
        );
      }
      return error(req, res, {}, "Gagal mendaftar", 201);
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal mendaftar", 500, err);
    });
};
