const axiosBPJS = require("../Helpers/axios");
const { error, success } = require("../Helpers/responser");

exports.rujukanbynoka = (req, res) => {
  let { noka } = req.query;
  if (!noka) {
    return error(req, res, {}, "Isi Parameter", 201, null);
  }

  let arr = [];

  return axiosBPJS
    .get(`/${process.env.BPJS_VCLAIM_URL}/Rujukan/List/Peserta/${noka}`)
    .then((payload) => {
      console.log(payload);
      if (payload.response) {
        arr = [...arr, ...payload.response.rujukan];
      }
    })
    .then(() => {
      return axiosBPJS
        .get(`/${process.env.BPJS_VCLAIM_URL}/Rujukan/RS/List/Peserta/${noka}`)
        .then((payload) => {
          if (payload.response) {
            arr = [...arr, ...payload.response.rujukan];
          }
        });
    })
    .then(() => {
      return success(req, res, arr, "OK", 200, "v-claim");
    })
    .catch((err) => {
      console.log(err);
      return error(req, res, {}, "Ada Kesalahan", 500, err, "v-claim");
    });
};
