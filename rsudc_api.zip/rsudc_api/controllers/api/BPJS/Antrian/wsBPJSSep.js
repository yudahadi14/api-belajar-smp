const axiosBPJS = require("../Helpers/axios");
const { error, success } = require("../Helpers/responser");
//var app = express()

//app.use(express.json()) // for parsing application/json
//app.use(express.urlencoded({ extended: true }))

exports.createSep = (req, res) => {
  const {
    noka,
    tglsep,
    ppkpelayanan,
    jnspelayanan,
    klsrawathak,
    klsrawatnaik,
    penanggungjawab,
    nomr,
    asalrujukan,
    tglrujukan,
    norujukan,
    ppkrujukan,
    catatan,
    diag,
    politujuan,
    executif,
    cob,
    katarak,
    laka,
    tglkejadian,
    ket,
    suplesi,
    nosepsuplesi,
    kdpropinsi,
    kdkabupaten,
    kdkecamatan,
    tujuankunj,
    flagprocedure,
    kdpenunjang,
    assesmentpel,
    nosurat,
    kddpjp,
    dpjplayan,
    notelp,
    user,
  } = req.query;
  // if (!noKartu || !tglSep || !jnsPelayanan|| !ppkPelayanan) {
  //   return error(req, res, {}, "Isi Parameter", 201, null);
  // }

  //return res.json(noka);

  var postdata = {
    request: {
      t_sep: {
        noKartu: noka,
        tglSep: tglsep,
        ppkPelayanan: ppkpelayanan,
        jnsPelayanan: jnspelayanan,
        klsRawat: {
          klsRawatHak: klsrawathak,
          klsRawatNaik: klsrawatnaik,
          pembiayaan: "",
          penanggungJawab: penanggungjawab,
        },
        noMR: nomr,
        rujukan: {
          asalRujukan: asalrujukan,
          tglRujukan: tglrujukan,
          noRujukan: norujukan,
          ppkRujukan: ppkrujukan,
        },
        catatan: catatan,
        diagAwal: diag,
        poli: {
          tujuan: politujuan,
          eksekutif: executif,
        },
        cob: {
          cob: cob,
        },
        katarak: {
          katarak: katarak,
        },
        jaminan: {
          lakaLantas: laka,
          penjamin: {
            tglKejadian: tglkejadian,
            keterangan: ket,
            suplesi: {
              suplesi: suplesi,
              noSepSuplesi: nosepsuplesi,
              lokasiLaka: {
                kdPropinsi: kdpropinsi,
                kdKabupaten: kdkabupaten,
                kdKecamatan: kdkecamatan,
              },
            },
          },
        },
        tujuanKunj: tujuankunj,
        flagProcedure: flagprocedure,
        kdPenunjang: kdpenunjang,
        assesmentPel: assesmentpel,
        skdp: {
          noSurat: nosurat,
          kodeDPJP: kddpjp,
        },
        dpjpLayan: dpjplayan,
        noTelp: notelp,
        user: user,
      },
    },
  };
  return axiosBPJS
    .post(`/${process.env.BPJS_VCLAIM_URL}/SEP/2.0/insert`, postdata, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metaData.message,
        Number(payload.metaData.code),
        "v-claim"
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err, "v-claim");
    });
};
