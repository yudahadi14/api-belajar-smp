const moment = require("moment");
const axiosBPJS = require("../Helpers/axios");
const { error, success } = require("../Helpers/responser");
const {
  quotaDokter,
  kuotaBerjalanDokter,
  getVisitTime,
  quotaDokterHFIS,
} = require("./wsrsController");
const {
  getHari,
  sisaKuota,
  phoneParser,
  getDiffDate,
  sequencePromise,
} = require("../../../../helpers/utility/common");
const models = require("../../../../models");
const { Op } = require("sequelize");
const axios = require("axios");
const { funcPutEncounter } = require("../../IHS/encounterController");

console.log(moment("2023-10-11 16:00", "YYYY-MM-DD hh:mm").format("x"));

exports.batalJKN = async ({ kodebooking }) => {
  return axiosBPJS
    .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/updatewaktu`, {
      kodebooking: `${kodebooking}`,
      taskid: 99,
      waktu: moment.utc().format("x"),
    })
    .then((aw) => {
      console.log(aw);
      return models.jml_nelp
        .findOne({
          where: {
            rkunid: kodebooking,
          },
        })
        .then((nelp) => {
          if (nelp && nelp.no_surat_kontrol) {
            return axios
              .get(
                `http://192.168.200.8:8080/RsudcApi/hapusrencanakontrol?nosuratkontrol=${nelp.no_surat_kontrol}&user=rsudc_mobile`
              )
              .then((kontrol) => {
                if (
                  kontrol.data.metaData &&
                  kontrol.data.metaData.code !== 200
                ) {
                  throw new Error(kontrol.data.metaData.message);
                }
              });
          }
        });
    })
    .then(() => {
      return models.jml_nelp.update(
        {
          task_id: 99,
          error_jkn: null,
        },
        {
          where: {
            rkunid: kodebooking,
          },
        }
      );
    });
};

exports.mulaiAntriJKN = async ({
  rkun_id,
  no_kartu,
  nik,
  no_hp,
  kdpoli,
  nama_layanan,
  no_mr,
  kd_dokter,
  nama_dokter,
  no_rujukan,
  no_antri,
  tanggal,
  waktu,
  doctor_id,
  id_layanan,
  is_bpjs,
  jeniskunjungan,
}) => {
  const payload = {
    rkun_id,
    no_kartu,
    nik,
    no_hp,
    kdpoli,
    nama_layanan,
    no_mr,
    kd_dokter,
    nama_dokter,
    no_rujukan,
    no_antri,
    tanggal,
    waktu,
    doctor_id,
    id_layanan,
    is_bpjs,
    jeniskunjungan,
  };
  let quota = null;
  return Promise.all([
    quotaDokterHFIS(
      kdpoli,
      tanggal,
      kd_dokter,
      waktu,
      doctor_id,
      id_layanan
    ).then((c) => {
      quota = c;
    }),
    // kuotaBerjalanDokter(tanggal, doctor_id, id_layanan).then((c) => {
    //   quota_berjalan_dokter = c;
    // }),
    // kuotaBerjalanDokter(tanggal, doctor_id, id_layanan, true).then((c) => {
    //   quota_berjalan_dokter_bpjs = c;
    // }),
  ]).then(() => {
    let split_ = waktu.split("-");
    let start_ = split_ ? split_[0].substring(0, 5) : "00:00";
    let end_ = split_ ? split_[1].substring(0, 5) : "00:00";

    let localWaktu = `${start_}-${end_}`;
    // let parseWaktu = localWaktu.split("-")[0];

    return axiosBPJS
      .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/add`, {
        kodebooking: `${rkun_id}`,
        jenispasien: is_bpjs ? "JKN" : "NON JKN",
        nomorkartu: no_kartu,
        nik: nik,
        nohp: phoneParser(no_hp),
        kodepoli: kdpoli,
        namapoli: nama_layanan,
        pasienbaru: 0,
        norm: no_mr,
        tanggalperiksa: tanggal,
        kodedokter: `${kd_dokter}`,
        namadokter: `${nama_dokter}`,
        jampraktek: localWaktu.replace(/\s/g, ""),
        jeniskunjungan: jeniskunjungan || 1,
        nomorreferensi: `${no_rujukan}`,
        nomorantrean: `${no_antri}`,
        angkaantrean: no_antri,
        estimasidilayani: Number(
          moment(`${tanggal} ${start_}`, "YYYY-MM-DD hh:mm")
            .add(no_antri * 6, "minutes")
            .format("x")
        ),
        sisakuotajkn: is_bpjs ? quota.sisa_bpjs - 1 : quota.sisa_bpjs,
        kuotajkn: quota.quota_bpjs,
        sisakuotanonjkn: !is_bpjs ? quota.sisa_umum - 1 : quota.sisa_umum,
        kuotanonjkn: quota.quota_umum,
        keterangan:
          "Peserta harap 30 menit lebih awal guna pencatatan administrasi.",
      })
      .then((bpjs) => {
        if (!bpjs.metadata || bpjs.metadata.code !== 200) {
          return models.jml_nelp.update(
            {
              task_id: 0,
              error_jkn: bpjs.metadata
                ? bpjs.metadata.message
                : "Gagal Insert JKN",
            },
            {
              where: {
                rkunid: rkun_id,
              },
            }
          );
        } else {
          if (getDiffDate(tanggal) === 0) {
            return axiosBPJS
              .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/updatewaktu`, {
                kodebooking: `${rkun_id}`,
                taskid: 3,
                waktu: moment.utc().format("x"),
              })
              .then(() => {
                return models.jml_nelp
                  .update(
                    {
                      task_id: 3,
                      error_jkn: null,
                    },
                    {
                      where: {
                        rkunid: rkun_id,
                      },
                    }
                  )
                  .then(() => {
                    return payload;
                  });
              })
              .catch(() => {
                return models.jml_nelp
                  .update(
                    {
                      error_jkn: `Gagal Update Task ID : 3`,
                    },
                    {
                      where: {
                        rkunid: rkun_id,
                      },
                    }
                  )
                  .then(() => {
                    return payload;
                  });
              });
          } else {
            return payload;
          }
        }
      });
  });
};

exports.refPoli = (req, res) => {
  return axiosBPJS
    .get(`/${process.env.BPJS_ANTRIAN_URL}/ref/poli`)
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.refDokter = (req, res) => {
  return axiosBPJS
    .get(`/${process.env.BPJS_ANTRIAN_URL}/ref/dokter`)
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.refJadwalDokter = (req, res) => {
  const { kd_poli, tgl } = req.params;
  if (!kd_poli || !tgl) {
    return error(req, res, {}, "Isi Parameter", 201, null);
  }
  return axiosBPJS
    .get(
      `/${process.env.BPJS_ANTRIAN_URL}/jadwaldokter/kodepoli/${kd_poli}/tanggal/${tgl}`
    )
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.updateJadwalDokter = (req, res) => {
  return axiosBPJS
    .post(
      `/${process.env.BPJS_ANTRIAN_URL}/jadwaldokter/updatejadwaldokter`,
      req.body
    )
    .then((payload) => {
      return success(
        req,
        res,
        null,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.daftarBaruBPJS = (req, res) => {
  const { kodepoli, tanggalperiksa, kodedokter, angkaantrean } = req.body;
  let kuota = 0;
  let kuota_berjalan = 0;
  let kuota_berjalan_bpjs = 0;
  let id_layanan = 0;
  let estimasi = null;
  const isDateValid = moment(tanggalperiksa, "YYYY-MM-DD", true).isValid();
  if (!isDateValid) {
    return error(req, res, {}, "Date Format : YYYY-MM-DD", 201, null);
  }
  return models.refpoli_bpjs
    .findOne({
      where: {
        kdpoli: kodepoli,
      },
    })
    .then((poli) => {
      if (!poli) {
        throw new Error("Poli Tidak Ditemukan");
      }
      id_layanan = poli.kd_layananpoli_rsc;
      return poli;
    })
    .then((poli) => {
      return models.dokter_bpjs
        .findOne({
          where: {
            dr_bpjs_kode: `${kodedokter}`,
          },
        })
        .then((dokter) => {
          if (!dokter) {
            throw new Error("Dokter Tidak Ditemukan");
          }
          return Promise.all([
            kuotaBerjalanDokter(
              tanggalperiksa,
              dokter.dr_bpjs_id_peg,
              poli.kd_layananpoli_rsc
            ).then((berjalan) => {
              kuota_berjalan = berjalan;
            }),
            kuotaBerjalanDokter(
              tanggalperiksa,
              dokter.dr_bpjs_id_peg,
              poli.kd_layananpoli_rsc,
              true
            ).then((berjalan) => {
              kuota_berjalan_bpjs = berjalan;
            }),
            quotaDokter(
              poli.kd_layananpoli_rsc,
              getHari(moment(tanggalperiksa, "YYYY-MM-DD").format("dddd")),
              tanggalperiksa,
              dokter.dr_bpjs_id_peg
            ).then((quota) => {
              kuota = quota;
            }),
          ]);
        });
    })
    .then(() => {
      return getVisitTime(
        angkaantrean,
        id_layanan,
        getHari(moment(tanggalperiksa, "YYYY-MM-DD").format("dddd"))
      ).then((waktu) => {
        estimasi = waktu;
      });
    })
    .then(() => {
      let waktu = estimasi.two ? estimasi.two : "08:00";

      let body = req.body;
      body = {
        ...req.body,
        estimasidilayani: Number(
          moment(`${tanggalperiksa + " " + waktu}`, "YYYY-MM-DD hh:mm").format(
            "x"
          )
        ),
        sisakuotajkn: sisaKuota(kuota).bpjs - kuota_berjalan_bpjs,
        kuotajkn: sisaKuota(kuota).bpjs,
        sisakuotanonjkn: sisaKuota(kuota).umum - kuota_berjalan,
        kuotanonjkn: sisaKuota(kuota).umum,
        keterangan:
          "Peserta harap 30 menit lebih awal guna pencatatan administrasi.",
      };
      return axiosBPJS
        .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/add`, body)
        .then((payload) => {
          return success(
            req,
            res,
            null,
            payload.metadata.message,
            payload.metadata.code
          );
        });
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.updateWaktu = ({ tid, kdbook, waktu }) => {
  const parseTask = (val) => {
    let data = {
      rs: null,
    };
    switch (val) {
      case 1:
        // data = {
        //   ...data,
        //   rs: null
        // }
        break;
      case 2:
        // data = {
        //   ...data,
        //   rs: null,
        // };
        break;
      case 3:
        data = {
          ...data,
          rs: 2,
        };
        break;
      case 4:
        data = {
          ...data,
          rs: 4,
        };
        break;
      case 5:
        data = {
          ...data,
          rs: 5,
        };
        break;
      case 6:
        data = {
          ...data,
          rs: 5,
        };
        break;
      case 7:
        data = {
          ...data,
          rs: 7,
        };
        break;
      case 99:
        data = {
          ...data,
          rs: 8,
        };
        break;
      default:
        break;
    }

    return data;
  };
  return models.trx_history_rajal
    .findOne({
      where: {
        hist_rajal_type: parseTask(tid).rs,
        rkun_id: kdbook,
      },
    })
    .then((hist) => {
      if (hist) {
        hist.created_at = moment().format();
        return hist.save();
      }
      if (parseTask(tid).rs) {
        return models.trx_history_rajal.create({
          hist_rajal_type: parseTask(tid).rs,
          rkun_id: kdbook,
        });
      }
    })
    .then(() => {
      // if (taskid === 7) {
      //   return funcPutEncounter({
      //     rkun_id: kdbook,
      //   }).then((encounter) => {
      //     console.log(JSON.stringify(encounter));
      //   });
      // }
      // return;
    })
    .then(() => {
      return axiosBPJS
        .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/updatewaktu`, {
          taskid: tid,
          waktu: waktu ? waktu : moment.utc().format("x"),
          kodebooking: kdbook,
        })
        .then((payload) => {
          return models.jml_nelp
            .update(
              {
                task_id: tid,
                error_jkn: null,
              },
              {
                where: {
                  rkunid: kdbook,
                },
              }
            )
            .then(() => {
              console.log(`${kdbook} : ${tid}`);
              return payload;
            });
        });
    })
    .then((payload) => {
      console.log(payload);
      if (!payload.metadata || payload.metadata.code !== 200) {
        return models.jml_nelp
          .update(
            {
              error_jkn: `Gagal Update Task ID : ${tid}`,
            },
            {
              where: {
                rkunid: kdbook,
              },
            }
          )
          .then(() => {
            return payload;
          });
      }
      return payload;
    });
};

exports.updateWaktuAntri = (req, res) => {
  let { kodebooking, taskid, waktu, psid, mr } = req.body;
  // if (!waktu) {
  //   req.body.waktu = moment.utc().format("x");
  // }

  // 1 (mulai waktu tunggu admisi),
  //               2 (akhir waktu tunggu admisi/mulai waktu layan admisi),
  //               3 (akhir waktu layan admisi/mulai waktu tunggu poli),
  //               4 (akhir waktu tunggu poli/mulai waktu layan poli),
  //               5 (akhir waktu layan poli/mulai waktu tunggu farmasi),
  //               6 (akhir waktu tunggu farmasi/mulai waktu layan farmasi membuat obat),
  //               7 (akhir waktu obat selesai dibuat),
  //               99 (tidak hadir/batal)

  // 1. planned 2. arrived 3. triage 4. process 5. farmasi 6. kasir 7. done 8. cancel

  if (mr) {
    return models.jml_nelp
      .findOne({
        where: {
          tglkunjung: moment().format("YYYY-MM-DD"),
          mrn: mr,
        },
      })
      .then((nelp) => {
        if (!nelp) {
          throw new Error("Kunjungan tidak ditemukan");
        }
        let task = nelp.task_id;
        const promises = [];

        while (task < taskid) {
          task++;
          promises.push(task);
        }

        const upd = (val) => {
          return this.updateWaktu({
            tid: val,
            kdbook: nelp.rkunid,
            waktu,
          })
            .then((waktu) => {
              if (!waktu.metadata || waktu.metadata.code !== 200) {
                return false;
              }
              if (val < taskid) {
                return upd(val + 1);
              }
              return true;
            })
            .then((value) => {
              return new Promise((resolve) => {
                setTimeout(() => {
                  resolve(value);
                }, 500);
              });
            });
        };

        return sequencePromise(promises, (x) => upd(x)).then(() => {
          console.log("done");
        });
      })
      .then(() => {
        return success(req, res, "", "Berhasil Update", 200);
      })
      .catch((err) => {
        return error(req, res, {}, "Ada Kesalahan", 500, err);
      });
  }
  if (psid) {
    return models.rencana_kunjungan
      .findOne({
        where: {
          rkun_id_pasien: psid,
          rkun_tgl_visit: moment().format("YYYY-MM-DD"),
          rkun_batal: {
            [Op.not]: true,
          },
        },
      })
      .then((rkun) => {
        if (rkun) {
          return this.updateWaktu({
            tid: taskid,
            kdbook: rkun.rkun_id,
            waktu,
          });
        } else {
          throw new Error("Kode Booking Tidak Ditemukan");
          // return error(req, res, {}, "Kode Booking Tidak Ditemukan", 400, null);
        }
      })
      .then((payload) => {
        return success(
          req,
          res,
          null,
          payload.metadata.message,
          payload.metadata.code
        );
      })
      .catch((err) => {
        return error(req, res, {}, "Ada Kesalahan", 500, err);
      });
  }
  if (!kodebooking || !taskid) {
    return error(req, res, {}, "Isi parameter", 201, null);
  }
  return models.jml_nelp
    .findOne({
      where: {
        rkunid: kodebooking,
      },
    })
    .then((nelp) => {
      if (!nelp) {
        throw new Error("Kunjungan tidak ditemukan");
      }
      let task = nelp.task_id;
      const promises = [];

      while (task < taskid) {
        task++;
        promises.push(task);
      }
      const upd = (val) => {
        return this.updateWaktu({
          tid: val,
          kdbook: nelp.rkunid,
          waktu,
        })
          .then((waktu) => {
            if (!waktu.metadata || waktu.metadata.code !== 200) {
              return false;
            }
            if (val < taskid) {
              return upd(val + 1);
            }
            return true;
          })
          .then((value) => {
            return new Promise((resolve) => {
              setTimeout(() => {
                resolve(value);
              }, 500);
            });
          });
      };

      return sequencePromise(promises, (x) => upd(x)).then(() => {
        console.log("done");
      });
    })
    .then(() => {
      return success(req, res, "", "Berhasil Update", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });

  // return this.updateWaktu({
  //   tid: taskid,
  //   kdbook: kodebooking,
  //   waktu,
  // })
  //   .then((payload) => {
  //     return success(
  //       req,
  //       res,
  //       null,
  //       payload.metadata.message,
  //       payload.metadata.code
  //     );
  //   })
  //   .catch((err) => {
  //     console.log(err);
  //     return error(req, res, {}, "Ada Kesalahan", 500, err);
  //   });
};

exports.batalBPJS = (req, res) => {
  let { kodebooking, keterangan } = req.body;
  if (!kodebooking || !keterangan) {
    return error(req, res, {}, "Isi parameter", 201, null);
  }
  return axiosBPJS
    .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/batal`, req.body)
    .then((payload) => {
      return success(
        req,
        res,
        null,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.ambilListTask = (req, res) => {
  let { kodebooking } = req.body;
  if (!kodebooking) {
    return error(req, res, {}, "Isi Kodebooking", 201, null);
  }
  return axiosBPJS
    .post(`/${process.env.BPJS_ANTRIAN_URL}/antrean/getlisttask`, req.body)
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.dashboardTgl = (req, res) => {
  let { tanggal, waktu } = req.query;
  if (!tanggal || !waktu) {
    return error(req, res, {}, "Isi parameter", 201, null);
  }
  return axiosBPJS
    .get(
      `/${process.env.BPJS_ANTRIAN_URL}/dashboard/waktutunggu/tanggal/${tanggal}/waktu/${waktu}`
    )
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.dashboardBln = (req, res) => {
  let { bulan, tahun, waktu } = req.query;
  if (!bulan || !tahun || !waktu) {
    return error(req, res, {}, "Isi parameter", 201, null);
  }
  return axiosBPJS
    .get(
      `/${process.env.BPJS_ANTRIAN_URL}/dashboard/waktutunggu/bulan/${bulan}/tahun/${tahun}/waktu/${waktu}`
    )
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.antreanPerTgl = (req, res) => {
  let { tanggal } = req.query;
  if (!tanggal) {
    return error(req, res, {}, "Isi parameter", 201, null);
  }
  return axiosBPJS
    .get(
      `/${process.env.BPJS_ANTRIAN_URL}/antrean/pendaftaran/tanggal/${tanggal}`
    )
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metadata.message,
        payload.metadata.code
      );
    })
    .catch((err) => {
      return res.json(err);
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.bulkUpdateAntrian = (req, res) => {
  const { list, waktu, delay } = req.body;
  const taskid = 7;
  const all = [];
  let kdbook_failed = [];
  console.log("mulai");
  const getTaskBefore = (kodebooking) => {
    return models.jml_nelp
      .findOne({
        where: {
          rkunid: kodebooking,
        },
      })
      .then((nelp) => {
        if (!nelp) {
          kdbook_failed.push(kodebooking);
          console.log("gagal");
          return false;
          // throw new Error("Kunjungan tidak ditemukan");
        }
        let task = nelp.task_id;
        const promises = [];
        while (task < taskid) {
          task++;
          promises.push(task);
        }

        const upd = (val) => {
          return this.updateWaktu({
            tid: val,
            kdbook: nelp.rkunid,
            waktu: moment(nelp.tglkunjung, "YYYY-MM-DD")
              .set("hour", 14)
              .set("minute", 00)
              .format("YYYY-MM-DD hh:mm:ss"),
          })
            .then((waktu) => {
              if (!waktu.metadata || waktu.metadata.code !== 200) {
                return false;
              }
              if (val < taskid) {
                return upd(val + 1);
              }
              return true;
            })
            .then((value) => {
              return new Promise((resolve) => {
                setTimeout(() => {
                  resolve(value);
                }, 500);
              });
            });
        };

        return sequencePromise(promises, (x) => upd(x)).then(() => {
          console.log("done");
        });
      });
  };
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  // list.map((item) => {
  //   all.push(getTaskBefore(item));
  // });
  return sequencePromise(list, (x) => getTaskBefore(x))
    .then(() => {
      console.log("done");
    })
    .then(() => {
      return success(req, res, kdbook_failed, "Berhasil Update", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
