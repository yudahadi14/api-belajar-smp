const moment = require("moment");
const axiosBPJS = require("../Helpers/axios");
const decrypt = require("../Helpers/decrypt");
const { error, success } = require("../Helpers/responser");

exports.pesertaBy = (req, res) => {
  const { noka, tglsep } = req.query;
  if (!noka || !tglsep) {
    return error(req, res, {}, "Isi Parameter", 201, null);
  }
  return axiosBPJS
    .get(
      `/${process.env.BPJS_VCLAIM_URL}/Peserta/nokartu/${noka}/tglSEP/${tglsep}`
    )
    .then((payload) => {
      return success(
        req,
        res,
        payload.response,
        payload.metaData.message,
        payload.metaData.code,
        "v-claim"
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err, "v-claim");
    });
};
