const moment = require("moment");

const axiosBPJS = require("../Helpers/axios");
const { error, success, otherresponse } = require("../Helpers/responser");
const models = require("../../../../models");
const axios = require("axios");
const { Op } = require("sequelize");
exports.historysep = (req, res) => {
  let { noka, tgl1 } = req.query;
  if (!noka || !tgl1) {
    return error(req, res, {}, "Isi Parameter", 201, null);
  }

  let arr = [];

  tgl1 = moment(tgl1, "YYYY-MM-DD").format("YYYY-MM-DD");
  tgl2 = moment(tgl1, "YYYY-MM-DD").startOf("month").format("YYYY-MM-DD");

  return axiosBPJS
    .get(
      `/${process.env.BPJS_VCLAIM_URL}/monitoring/HistoriPelayanan/NoKartu/${noka}/tglMulai/${tgl2}/tglAkhir/${tgl1}`
    )
    .then((payload) => {
      if (payload.response) {
        arr = [...arr, ...payload.response.histori];
      }
    })
    .then(() => {
      tgl1 = moment(tgl1, "YYYY-MM-DD")
        .subtract(1, "M")
        .endOf("month")
        .format("YYYY-MM-DD");
      tgl2 = moment(tgl1, "YYYY-MM-DD").startOf("month").format("YYYY-MM-DD");

      return axiosBPJS
        .get(
          `/${process.env.BPJS_VCLAIM_URL}/monitoring/HistoriPelayanan/NoKartu/${noka}/tglMulai/${tgl2}/tglAkhir/${tgl1}`
        )
        .then((payload) => {
          if (payload.response) {
            arr = [...arr, ...payload.response.histori];
          }
        });
    })
    .then(() => {
      tgl1 = moment(tgl1, "YYYY-MM-DD")
        .subtract(1, "M")
        .endOf("month")
        .format("YYYY-MM-DD");
      tgl2 = moment(tgl1, "YYYY-MM-DD").startOf("month").format("YYYY-MM-DD");

      return axiosBPJS
        .get(
          `/${process.env.BPJS_VCLAIM_URL}/monitoring/HistoriPelayanan/NoKartu/${noka}/tglMulai/${tgl2}/tglAkhir/${tgl1}`
        )
        .then((payload) => {
          if (payload.response) {
            arr = [...arr, ...payload.response.histori];
          }
        });
    })
    .then(() => {
      tgl1 = moment(tgl1, "YYYY-MM-DD")
        .subtract(1, "M")
        .endOf("month")
        .format("YYYY-MM-DD");
      tgl2 = moment(tgl1, "YYYY-MM-DD").startOf("month").format("YYYY-MM-DD");

      return axiosBPJS
        .get(
          `/${process.env.BPJS_VCLAIM_URL}/monitoring/HistoriPelayanan/NoKartu/${noka}/tglMulai/${tgl2}/tglAkhir/${tgl1}`
        )
        .then((payload) => {
          if (payload.response) {
            arr = [...arr, ...payload.response.histori];
          }
        });
    })
    .then((dt) => {
      if (arr.length === 0) {
        throw Error("Data tidak ada");
      }
      return success(req, res, arr, "Berhasil memuat", 200, "v-claim");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err, "v-claim");
    });
};

exports.createKontrol = (req, res) => {
  const { no_sep, tanggal, no_mr } = req.query;
  if (!no_sep || !tanggal || !no_mr) {
    return error(req, res, {}, "Isi Paramater", 400);
  }
  return models.jml_nelp
    .findOne({
      where: {
        tglkunjung: tanggal,
        mrn: no_mr,
        [Op.not]: [
          {
            kddokter_bpjs: null,
          },
          {
            kdpoli_bpjs: null,
          },
        ],
      },
      order: [["id", "DESC"]],
    })
    .then((nelp) => {
      if (!nelp) {
        throw new Error("Kunjungan Tidak Ditemukan");
      }

      return nelp;
    })
    .then((nelp) => {
      return axios
        .get(
          `http://192.168.200.8:8080/RsudcApi/insertrencanakontrol?nosep=${no_sep}&kodedokter=${nelp.kddokter_bpjs}&polikontrol=${nelp.kdpoli_bpjs}&tglrencanakontrol=${tanggal}&user=rsudc_mobile`
        )
        .then((kontrol) => {
          if (kontrol.data.metaData && kontrol.data.metaData.code === 200) {
            // jenis_kunjungan = 3;
            return models.jml_nelp
              .update(
                {
                  where: {
                    id: nelp.id,
                  },
                },
                {
                  jeniskunjungan: 3,
                  no_surat_kontrol: kontrol.data.response.noSuratKontrol,
                }
              )
              .then(() => {
                return kontrol.data.response.noSuratKontrol;
              });
          } else if (kontrol.data.metaData) {
            throw new Error(
              `${kontrol.data.metaData.message}, Mohon coba lagi atau lakukan pendaftaran offline pada hari H melalui Admin`
            );
          }
        });
    })
    .then((dt) => {
      return success(req, res, dt, "Berhasil memuat", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
