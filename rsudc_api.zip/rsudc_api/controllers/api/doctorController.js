let models = require("../../models");
let { sequelize } = require("../../models");
const { QueryTypes, Op } = require("sequelize");
const { parseJadwal } = require("../../helpers/parser/doctorParser");
const { success, error } = require("../../helpers/utility/response");
const {
  getPeriodeTanggal,
  getHari,
  getDOW,
} = require("../../helpers/utility/common");
const axios = require("axios");

exports.jadwalDokter = (req, res) => {
  let { bulan1, bulan2, tahun, peg_id, tanggal } = req.query;
  const query = `
SELECT 
  cast(
    (
      periodeawal || '-' || periodeakhir || '  ' || thn
    ) as varchar (100)
  ) AS periode, 
  id, 
  peg_id,
  peg_nama, 
  ref_layanan_id,
  ref_layanan_nama, 
  hari_praktek, 
  jam_praktek_mulai, 
  jam_praktek_akhir, 
  jam_praktek_lainnya 
FROM 
  jadwal_praktek_dokter 
  left join pegawai ON peg_id = id_dokter 
  left join ref_layanan ON ref_layanan_id = id_poli 
WHERE 
  thn = :tahun 
  and aktif = true 
  and blnint1 = :bulan1
  and blnint2 = :bulan2
  and peg_nama not in ('ga ad nama', 'DOKTER RSUD', 'FISIOTHERAPIST')
  ${req.query.peg_id ? "and peg_id = :peg_id" : "--"} 
ORDER BY 
  ref_layanan_nama, 
  peg_nama, 
  CASE WHEN hari_praktek = 'Senin' THEN 1 WHEN hari_praktek = 'Selasa' THEN 2 WHEN hari_praktek = 'Rabu' THEN 3 WHEN hari_praktek = 'Kamis' THEN 4 WHEN hari_praktek = 'Jumat' THEN 5 WHEN hari_praktek = 'Sabtu' THEN 6 WHEN hari_praktek = 'Minggu' THEN 7 END ASC
`;
  if (tanggal) {
    bulan1 = getPeriodeTanggal(tanggal).periode1;
    bulan2 = getPeriodeTanggal(tanggal).periode2;
    tahun = getPeriodeTanggal(tanggal).tahun;
  } else {
    if (!bulan1 || !bulan2 || !tahun) {
      return error(req, res, {}, "Cek Parameter", 400, null);
    }
  }
  return models.sequelize
    .query(query, {
      replacements: {
        bulan1: bulan1,
        bulan2: bulan2,
        tahun: tahun,
        peg_id: peg_id,
      },
      type: QueryTypes.SELECT,
    })
    .then((payload) => {
      let result = parseJadwal(payload);
      return success(req, res, result);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.listDokter = (req, res) => {
  const query = `
select 
  p.peg_id, 
  p.peg_nopeg, 
  p.peg_nama as nama_dokter, 
  rl.ref_layanan_nama, 
  rl.ref_layanan_id,
  foto.filename
from 
  dokter_bpjs db
  inner join pegawai p on p.peg_id = db.dr_bpjs_id_peg 
  left join jadwal_praktek_dokter jpd on jpd.id_dokter = db.dr_bpjs_id_peg 
  left join ref_layanan rl on rl.ref_layanan_id = jpd.id_poli
  left join foto_dokter foto on foto.peg_id = p.peg_id
where 
  peg_nama not in ('ga ad nama', 'DOKTER RSUD', 'FISIOTHERAPIST')
  AND p.peg_aktif is true
  ${
    req.query.nama_dokter
      ? "AND UPPER(p.peg_nama) like UPPER(:nama_dokter)"
      : ""
  }
  ${
    req.query.layanan_id
      ? "AND rl.ref_layanan_id = :layanan_id"
      : "AND rl.ref_layanan_id != 0"
  }
  ${req.query.kdpoli ? "AND db.dr_bpjs_kode_spec = :kdpoli" : ""}
group by 
  p.peg_id, 
  p.peg_nopeg, 
  p.peg_nama, 
  rl.ref_layanan_nama, 
  rl.ref_layanan_id,
  foto.filename
order by 
  nama_dokter ASC;
  `;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        nama_dokter: "%" + req.query.nama_dokter + "%" || "",
        layanan_id: req.query.layanan_id,
        kdpoli: req.query.kdpoli,
      },
    })
    .then((payload) => {
      return success(req, res, payload);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.detailDokter = (req, res) => {
  const { peg_id } = req.query;
  if (!peg_id) {
    return error(req, res, {}, "Isi parameter", 400, null);
  }
  return models.dokter_bpjs
    .findOne({
      where: {
        dr_bpjs_id_peg: peg_id,
      },
      include: [
        {
          model: models.foto_dokter,
          as: "foto_dokter",
        },
        {
          model: models.ref_layanan,
          as: "layanan",
          required: true,
        },
        {
          model: models.pegawai,
          as: "pegawai",
          required: true,
        },
      ],
    })
    .then((dokter) => {
      if (!dokter) {
        throw new Error("Dokter tidak ditemukan");
      }
      return {
        id_dokter: dokter.dr_bpjs_id_peg,
        nama_dokter: dokter.pegawai.peg_nama,
        id_poli: dokter.dr_bpjs_id_layanan,
        nama_poli: dokter.layanan.ref_layanan_nama,
        foto_dokter: dokter.foto_dokter?.filename,
        bpjs: {
          kode_dokter: dokter.dr_bpjs_kode,
          kode_spec: dokter.dr_bpjs_kode_spec,
          nama_dokter: dokter.dr_bpjs_nama,
        },
      };
    })
    .then((payload) => {
      return success(req, res, payload);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.listPoliLansia = (req, res) => {
  const { type } = req.query;
  let whr = {
    [Op.not]: null,
  };
  let whr_kdpoli = {
    [Op.not]: null,
  };
  if (type === "daftar_online") {
    whr = {
      [Op.notIn]: [
        0, 84,
        // 87,
        19, 41, 20, 13,
        // 11,
        84, 60, 120,
      ],
      [Op.not]: null,
    };
    whr_kdpoli = {
      // [Op.notIn]: ['097', '034', '017', '005', '007', 'UGD', 'APT', 'LAB'],
      [Op.notIn]: [
        "097",
        "034",
        // "017",
        "005",
        "007",
        "UGD",
        "APT",
        "LAB",
        "IGD",
        "RAD",
        "HDL",
        "PTD",
        // "BDM",
        "GAS",
        "ESW",
        "DRH",
      ],
    };
  }
  return models.refpoli_bpjs
    .findAll({
      attributes: [
        "id_refpoli",
        "kd_layananpoli_rsc",
        "nmpoli",
        "kdpoli",
        "nmpoli_rsc",
      ],
      group: [
        "kd_layananpoli_rsc",
        "nmpoli",
        "kdpoli",
        "ref_layanan_nama",
        "ref_layanan_id",
        "id_refpoli",
        "nmpoli_rsc",
      ],
      include: {
        model: models.ref_layanan,
        required: true,
        as: "ref_layanan",
        attributes: ["ref_layanan_id", "ref_layanan_nama"],
      },
      order: [["nmpoli", "ASC"]],
      where: {
        id_refpoli: {
          [Op.notIn]: [185],
        },
        kd_layananpoli_rsc: whr,
        kdpoli: whr_kdpoli,
      },
    })
    .then((payload) => {
      let arr = [];
      payload.map((item) => {
        return arr.push({
          id_refpoli: item.id_refpoli,
          id_poli: item.kd_layananpoli_rsc,
          ref_layanan_nama: `${item.nmpoli_rsc}`,
          // ref_layanan_nama: `${item.kdpoli} - ${item.ref_layanan.ref_layanan_nama}`,
          kd_poli: item.kdpoli,
        });
      });
      return success(req, res, arr);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.functListPoli = (type = "daftar_online") => {
  let whr = {
    [Op.not]: null,
  };
  let whr_kdpoli = {
    [Op.not]: null,
  };
  if (type === "daftar_online") {
    whr = {
      [Op.notIn]: [
        // 84, //BEDAH ANAK
        // 87, //BEDAH MULUT
        19, //EDUKASI
        41, //ANASTESI
        20, //LAKTASI
        0,
      ], //--
      [Op.not]: null,
    };
    whr_kdpoli = {
      [Op.notIn]: [
        "097",
        "034",
        // "017",
        "005",
        "007",
        "UGD",
        "APT",
        "LAB",
        "IGD",
        "RAD",
        "HDL",
        "PTD",
        "AKP",
        // "BDM",
        "GAS",
        "ESW",
        "DRH",
        "KEM",
        // "GND",
      ],
    };
  }
  return models.refpoli_bpjs
    .findAll({
      attributes: [
        "id_refpoli",
        "kd_layananpoli_rsc",
        "nmpoli",
        "nmpoli_rsc",
        "kdpoli",
      ],
      group: [
        "kd_layananpoli_rsc",
        "nmpoli",
        "kdpoli",
        "ref_layanan_nama",
        "ref_layanan_id",
        "id_refpoli",
      ],
      order: [["nmpoli", "ASC"]],
      include: {
        model: models.ref_layanan,
        required: true,
        as: "ref_layanan",
        attributes: ["ref_layanan_id", "ref_layanan_nama"],
      },
      where: {
        id_refpoli: {
          [Op.notIn]: [185],
        },
        kd_layananpoli_rsc: whr,
        kdpoli: whr_kdpoli,
      },
    })
    .then((payload) => {
      let arr = [];
      payload.map((item) => {
        return arr.push({
          id_refpoli: item.id_refpoli,
          id_poli: item.kd_layananpoli_rsc,
          ref_layanan_nama: `${item.nmpoli_rsc}`,
          kd_poli: item.kdpoli,
        });
      });
      return arr;
    });
};

exports.listPoli = (req, res) => {
  const { type } = req.query;
  let whr = {
    [Op.not]: null,
  };
  let whr_kdpoli = {
    [Op.not]: null,
  };
  if (type === "daftar_online") {
    whr = {
      [Op.notIn]: [
        // 84, //BEDAH ANAK
        // 87, //BEDAH MULUT
        19, //EDUKASI
        41, //ANASTESI
        20, //LAKTASI
        0,
      ], //--
      [Op.not]: null,
    };
    whr_kdpoli = {
      [Op.notIn]: [
        "097",
        "034",
        // "017",
        "005",
        "007",
        "UGD",
        "APT",
        "LAB",
        "IGD",
        "RAD",
        "HDL",
        "PTD",
        "AKP",
        // "BDM",
        "GAS",
        "ESW",
        "DRH",
        "KEM",
        // "GND",
      ],
    };
  }
  return models.refpoli_bpjs
    .findAll({
      attributes: [
        "id_refpoli",
        "kd_layananpoli_rsc",
        "nmpoli",
        "nmpoli_rsc",
        "kdpoli",
      ],
      group: [
        "kd_layananpoli_rsc",
        "nmpoli",
        "kdpoli",
        "ref_layanan_nama",
        "ref_layanan_id",
        "id_refpoli",
      ],
      order: [["nmpoli", "ASC"]],
      include: {
        model: models.ref_layanan,
        required: true,
        as: "ref_layanan",
        attributes: ["ref_layanan_id", "ref_layanan_nama"],
      },
      where: {
        id_refpoli: {
          [Op.notIn]: [185],
        },
        kd_layananpoli_rsc: whr,
        kdpoli: whr_kdpoli,
      },
    })
    .then((payload) => {
      let arr = [];
      payload.map((item) => {
        return arr.push({
          id_refpoli: item.id_refpoli,
          id_poli: item.kd_layananpoli_rsc,
          ref_layanan_nama: `${item.nmpoli_rsc}`,
          kd_poli: item.kdpoli,
        });
      });
      return success(req, res, arr);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.postJadwal = (req, res) => {
  const findQ = `
SELECT * FROM jadwal_praktek_dokter
WHERE
 id_dokter = :peg_id
 AND hari_praktek = :hari_praktek
 AND jam_praktek_mulai = :jam_praktek_mulai
 AND jam_praktek_akhir = :jam_praktek_akhir
 AND periodeawal = :periodeawal
 AND periodeakhir = :periodeakhir
 AND thn = :thn
 AND blnint1 = :blnint1
 AND blnint2 = :blnint2 
 AND id_poli = :id_poli
LIMIT 1;
  `;
  const insQ = `
  insert into jadwal_praktek_dokter (
    id_dokter, hari_praktek, jam_praktek_mulai, 
    jam_praktek_akhir, id_poli, periodeawal, 
    periodeakhir, tgl_input, thn, blnint1, 
    blnint2, aktif
  ) 
  values 
  (
    :peg_id, :hari_praktek, :jam_praktek_mulai, :jam_praktek_akhir, 
    :id_poli, :periodeawal, :periodeakhir, now(), :thn, 
    :blnint1, :blnint2, true
  )
  `;
  const {
    peg_id,
    hari_praktek,
    jam_praktek_mulai,
    jam_praktek_akhir,
    periodeawal,
    periodeakhir,
    blnint1,
    blnint2,
    id_poli,
    thn,
  } = req.body;

  return models.sequelize
    .query(findQ, {
      type: QueryTypes.SELECT,
      replacements: {
        peg_id: peg_id,
        hari_praktek: hari_praktek,
        jam_praktek_mulai: jam_praktek_mulai,
        jam_praktek_akhir: jam_praktek_akhir,
        periodeawal: periodeawal,
        periodeakhir: periodeakhir,
        blnint1: blnint1,
        blnint2: blnint2,
        id_poli: id_poli,
        thn: thn,
      },
    })
    .then((jadwal) => {
      if (jadwal.length > 0) {
        throw new Error("Jadwal sudah ada.");
      }
      return models.sequelize.query(insQ, {
        type: QueryTypes.INSERT,
        replacements: {
          peg_id: peg_id,
          hari_praktek: hari_praktek,
          jam_praktek_mulai: jam_praktek_mulai,
          jam_praktek_akhir: jam_praktek_akhir,
          periodeawal: periodeawal,
          periodeakhir: periodeakhir,
          blnint1: blnint1,
          blnint2: blnint2,
          id_poli: id_poli,
          thn: thn,
        },
      });
    })
    .then((payload) => {
      return success(req, res, payload);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.fotoDokter = (req, res) => {
  const file = req.file;
  const { filename } = req.file;
  const { peg_id } = req.body;
  if (!file) {
    return error(req, res, "Error", null);
  }
  const findQ = `SELECT * FROM foto_dokter WHERE peg_id = :peg_id LIMIT 1`;
  const insQ = `
        INSERT INTO foto_dokter (peg_id, filename)
        VALUES (:peg_id, :filename)
      `;
  const updQ = `
        UPDATE foto_dokter SET filename = :filename WHERE peg_id = :peg_id
      `;
  return models.sequelize
    .query(findQ, {
      type: QueryTypes.SELECT,
      replacements: {
        peg_id: peg_id,
      },
    })
    .then((payload) => {
      if (payload && payload.length > 0) {
        return models.sequelize.query(updQ, {
          type: QueryTypes.UPDATE,
          replacements: {
            peg_id: peg_id,
            filename: "doctors/" + filename,
          },
        });
      } else {
        return models.sequelize.query(insQ, {
          type: QueryTypes.INSERT,
          replacements: {
            peg_id: peg_id,
            filename: "doctors/" + filename,
          },
        });
      }
    })
    .then(() => {
      return models.sequelize.query(findQ, {
        type: QueryTypes.SELECT,
        replacements: {
          peg_id: peg_id,
        },
      });
    })
    .then((payload) => {
      return success(req, res, payload);
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal upload foto", 500, err);
    });
};

exports.checkJadwalRajal = ({ id_layanan, kd_poli, tanggal }) => {
  if (!id_layanan || !kd_poli || !tanggal) {
    throw new Error("Isi parameter");
  }

  let url = "http://192.168.200.8:8080/RsudcApi/datadokter";
  let whr = {
    dr_bpjs_id_layanan: id_layanan,
  };
  if (kd_poli === "HIV") {
    whr = {
      dr_bpjs_id_layanan: id_layanan,
      // dr_bpjs_id_peg: 100275,
      // dr_bpjs_id_layanan: id_layanan,
    };
  }
  return axios
    .get(url, {
      params: {
        jnskontrol: 2,
        kdpoli: kd_poli === "HIV" ? "INT" : kd_poli,
        tglrencanakontrol: tanggal,
      },
    })
    .then((payload) => {
      let data = payload.data;
      let hari = getDOW(tanggal);
      if (!data.metaData) {
        throw new Error("Gagal Memuat Dokter");
      } else if (kd_poli == "GND" && hari < 7) {
        if (!data.response.list) {
          data.response = {
            list: [],
          };
        }
        data.response.list.push({
          kodeDokter: "267752",
          namaDokter: "Dwi Suprihartono, dr. Sp.Ort",
          jadwalPraktek: "08:00 - 12:00",
          kapasitas: "25",
        });
      } else if (data.metaData.code !== 200) {
        throw new Error(data.metaData.message);
      } else if (
        !data.response ||
        !data.response.list ||
        data.response.list.length === 0
      ) {
        throw new Error("Jadwal Kosong BPJS");
      }
      let list = data.response.list.filter((item) => item.kapasitas > 0);
      return list;
    })
    .then((dokter_bpjs) => {
      return models.dokter_bpjs
        .findAll({
          where: whr,
          attributes: {
            include: [
              [
                sequelize.literal(`(
                        SELECT COUNT(*)
                        FROM rencana_kunjungan AS rkun
                        WHERE
                            rkun.rkun_id_layanan = ${id_layanan}
                            AND (rkun.rkun_id_dokter = dokter_bpjs.dr_bpjs_id_peg or rkun.rkun_id_dokter = 100080)
                            AND rkun_tgl_visit = '${tanggal}'::date
                            AND rkun_batal is not true
                    )`),
                "total_kunjungan",
              ],
            ],
          },
          include: [
            {
              model: models.foto_dokter,
              as: "foto_dokter",
              required: false,
            },
            {
              model: models.ref_layanan,
              as: "layanan",
              required: true,
            },
          ],
        })
        .then((dokter_rs) => {
          if (dokter_rs.length === 0) {
            throw new Error("Jadwal Kosong");
          }
          let filtered_dokter = [];
          dokter_bpjs.map((bpjs) => {
            dokter_rs.map((dokter) => {
              if (String(dokter.dr_bpjs_kode) === bpjs.kodeDokter) {
                if (id_layanan == 87) {
                  // bpjs.kapasitas = 20;
                } else if (id_layanan == 51) {
                  bpjs.kapasitas = bpjs.kapasitas > 60 ? bpjs.kapasitas : 60;
                }
                let found = filtered_dokter.find(
                  (el) => el.peg_id === dokter.dr_bpjs_id_peg
                );
                let sisa_kuota =
                  bpjs.kapasitas - Number(dokter.get("total_kunjungan"));
                if (found) {
                  return found.jadwal_praktek.push({
                    jam: bpjs.jadwalPraktek
                      ? bpjs.jadwalPraktek.replace(/\s/g, "")
                      : "",
                    kapasitas: bpjs.kapasitas,
                    sisa_kuota: sisa_kuota < 0 ? 0 : sisa_kuota,
                  });
                }
                return filtered_dokter.push({
                  peg_id: dokter.dr_bpjs_id_peg,
                  nama_dokter: dokter.dr_bpjs_nama,
                  ref_layanan_nama: dokter.layanan.ref_layanan_nama,
                  ref_layanan_id: dokter.layanan.ref_layanan_id,
                  filename: dokter.foto_dokter
                    ? dokter.foto_dokter.filename
                    : null,
                  kode_dokter_bpjs: bpjs.kodeDokter,
                  nama_dokter_bpjs: bpjs.namaDokter,
                  jadwal_praktek: [
                    {
                      jam: bpjs.jadwalPraktek
                        ? bpjs.jadwalPraktek.replace(/\s/g, "")
                        : "",
                      kapasitas: bpjs.kapasitas,
                      sisa_kuota: sisa_kuota < 0 ? 0 : sisa_kuota,
                    },
                  ],
                });
              }
            });
          });
          console.log(filtered_dokter);
          return filtered_dokter;
          // const filtered_dokter = dokter_bpjs.filter((item1) =>
          //   dokter_rs.some(
          //     (item2) => item1.kodeDokter === String(item2.dr_bpjs_kode)
          //   )
          // );
        });
    });
};

exports.doctorBPJS = (req, res) => {
  const { id_layanan, kd_poli, tanggal } = req.query;

  if (!id_layanan || !kd_poli || !tanggal) {
    return error(req, res, {}, "Invalid Paremeter", 400, null);
  }
  return this.checkJadwalRajal({
    id_layanan,
    kd_poli,
    tanggal,
  })
    .then((payload) => {
      return success(req, res, payload, "Jadwal Termuat");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.cobaFoto = () => {};

exports.dokterKoas = (req, res) => {
  const { nama_dokter } = req.query;
  return models.dokter_koas
    .findAll({
      include: [
        {
          model: models.pegawai,
          required: true,
          attributes: ["peg_nama"],
          as: "pegawai",
          where: {
            peg_nama: {
              [Op.iLike]: `%${nama_dokter}%`,
            },
          },
        },
        {
          model: models.foto_dokter,
          required: false,
          as: "foto_dokter",
        },
      ],
    })
    .then((payload) => {
      let arr = payload.map((item) => {
        return {
          peg_id: item.peg_id,
          nama_dokter: item.pegawai.peg_nama,
          foto_dokter: item.foto_dokter?.filename,
          klinik_dokter: item.dokter_koas_klinik,
        };
      });
      return arr;
    })
    .then((payload) => {
      return success(req, res, payload, "Jadwal Termuat");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
