const jwt = require("jsonwebtoken");
const { Op } = require("sequelize");
const { error } = require("./responser");
const models = require("../../../../models");
const bcrypt = require("bcrypt");
const verifyAuth = (token) => {
  return jwt.verify(token, "RSUDCKBR!DG!NG", function (err, decoded) {
    if (err) {
      return {
        error: err,
      };
    }
    return decoded;
  });
};

const authMid = (req, res, next) => {
  const token = req.header("x-auth-token");
  const username = req.header("Api-User");
  const password = req.header("Api-Key");

  if (token) {
    const verify = verifyAuth(token);

    if (verify.error) {
      if (verify.error.name === "JsonWebTokenError") {
        return error(req, res, {}, "Not Authenticated", 401, {});
      } else if (verify.error.name == "TokenExpiredError") {
        return error(req, res, {}, "Token Expired!.", 401, {});
      } else {
        return error(req, res, {}, "Not Authenticated", 400, {});
      }
    }
    req.user = verify;
    return next();
  } else if (username) {
    return models.mst_auth_bridging
      .findOne({
        where: {
          auth_bridging_username: username,
        },
      })
      .then((payload) => {
        if (!payload) {
          throw Error("Username / password tidak sesuai");
        }
        let authenticated = bcrypt.compareSync(
          password,
          payload.auth_bridging_password
        );
        if (!authenticated) {
          throw Error("Username / password tidak sesuai");
        }
        return next();
      })
      .catch((err) => {
        return error(
          req,
          res,
          {},
          err.message ? err.message : "Ada Kesalahan",
          err.message ? 400 : 500,
          err
        );
      });
  } else {
    return error(req, res, {}, "Not Authenticated", 401, {});
  }
};
module.exports = authMid;
