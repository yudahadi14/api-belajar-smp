const log4js = require("log4js");
const moment = require("moment");

log4js.configure({
  appenders: {
    app: {
      type: "file",
      filename: `log/bpjs/${moment().format("YYYY_MM_DD")}.log`,
    },
    log: {
      type: "console",
    },
  },
  categories: {
    default: { appenders: ["app", "log"], level: "error" },
    log: {
      appenders: ["log"],
      level: "all",
    },
  },
});

exports.logger = log4js.getLogger("app");
exports.loggerConsole = log4js.getLogger("log");

exports.success = (
  req,
  res,
  data = null,
  message = "Berhasil",
  status = 200
) => {
  this.loggerConsole.info(message);
  return res.json({
    metadata: {
      code: status,
      message: message,
    },
    data: data,
  });
};

exports.error = (
  req,
  res,
  data = null,
  message = "Ada Kesalahan",
  status = 500,
  err
) => {
  console.log(err);
  if (err && err.response) {
    this.logger.fatal(err.response);
    message = err.response.message;
    // status = status ? status : 400;
    status = 400;
  } else if (err) {
    this.logger.fatal(err.toString());
    if (err.message) {
      message = err.message;
      status = 400;
    }
  } else {
    console.warn(err);
  }
  return res.status(status).json({
    metadata: {
      code: status,
      message: message + " hubungi: support@rsudcengkareng.com",
    },
    data: data,
  });
};

exports.successEis = (
  req,
  res,
  data = null,
  message = "Berhasil",
  status = 200
) => {
  this.loggerConsole.info(message);
  return res.json({
    code: status,
    messages: message,
    data: data,
  });
};

exports.errorEis = (
  req,
  res,
  data = null,
  message = "Ada Kesalahan",
  status = 500,
  err
) => {
  console.log(err);
  if (err && err.response) {
    this.logger.fatal(err.response);
    message = err.response.message;
    // status = status ? status : 400;
    status = 400;
  } else if (err) {
    this.logger.fatal(err.toString());
    if (err.message) {
      message = err.message;
      status = 400;
    }
  } else {
    console.warn(err);
  }
  return res.status(status).json({
    code: status,
    messages: message,
    data: data,
  });
};
