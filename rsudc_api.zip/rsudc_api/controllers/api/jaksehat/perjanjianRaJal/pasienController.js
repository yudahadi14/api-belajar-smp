const models = require("../../../../models");
const { Op } = require("sequelize");
const { parseJadwal } = require("../../../../helpers/parser/doctorParser");
const { success, error } = require("../helpers/responser");
const { stringToMR } = require("../../../../helpers/utility/common");
const axios = require("axios");
const { sequelize } = require("../../../../models");
const {
  getProvince,
  getRegency,
  getDistrict,
  getVillage,
} = require("../../../../helpers/utility/geoJKN");

exports.findPasien = (req, res) => {
  const { type, number } = req.params;
  let query = null;
  if (!type || !number) {
    return error(
      req,
      res,
      {},
      "Please provide identifierType and identifierNumber",
      400
    );
  }

  switch (type) {
    case "nik":
      query = new Promise((resolve, reject) => {
        return models.v_pasien
          .findOne({
            where: {
              [Op.or]: {
                ps_nomor_identitas: number,
                ps_mrn: stringToMR(number),
              },
            },
            // include: [
            //   {
            //     model: models.pasien,
            //     required: true,
            //     as: "pasien",
            //   },
            // ],
          })
          .then((payload) => {
            resolve(payload);
          })
          .catch((err) => {
            reject(err);
          });
      });
      break;
    case "nomr":
      query = new Promise((resolve, reject) => {
        return models.v_pasien
          .findOne({
            where: {
              ps_mrn: stringToMR(number),
            },
            // include: [
            //   {
            //     model: models.pasien,
            //     required: true,
            //     where: {
            //       ps_mrn: stringToMR(number),
            //     },
            //     as: "pasien",
            //   },
            // ],
          })
          .then((payload) => {
            resolve(payload);
          })
          .catch((err) => {
            reject(err);
          });
      });
      break;
    case "jkn":
      query = new Promise((resolve, reject) => {
        return models.v_pasien
          .findOne({
            where: {
              ps_no_jmn_non_cash: number,
            },
            // include: [
            //   {
            //     model: models.pasien,
            //     required: true,
            //     as: "pasien",
            //   },
            // ],
          })
          .then((payload) => {
            resolve(payload);
          })
          .catch((err) => {
            reject(err);
          });
      });
      break;
    default:
      return error(req, res, {}, "Please provide right identifierType", 400);
  }

  return query
    .then((payload) => {
      if (!payload) {
        return error(
          req,
          res,
          {},
          "Pasien tidak ditemukan, apakah anda telah datang ke RS?",
          404,
          null
        );
      }
      let body = {
        noMR: payload.ps_mrn,
        name: payload.ps_namalengkap,
        gender: payload.ps_jeniskelamin == 1 ? "L" : "P",
        birthDate: payload.ps_tgllahir,
        nik: payload.ps_nomor_identitas,
        noJKN: payload.ps_no_jmn_non_cash,
        phone: payload.ps_telpon,
      };
      return success(req, res, body, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Failed", 500, err);
    });
};

exports.cekRujukanBPJS = (req, res) => {
  const { bpjs } = req.params;
  if (!bpjs) {
    return error(req, res, {}, "Mohon masukkan nomer BPJS", 400);
  }
  const rujukanSatu = new Promise((resolve, reject) => {
    const url =
      "http://10.10.11.202/BpjsApi/Rujukan/rujukan_multi_dari_faskes1";
    return axios
      .get(url, {
        params: {
          noka: bpjs,
        },
      })
      .then((payload) => {
        let data = payload.data;
        let arr = [];
        if (data && data.response && data.response.rujukan) {
          data.response.rujukan.map((item) => {
            arr.push({
              no_rujukan: item.tglKunjungan,
              tgl_rujukan: item.noKunjungan,
              kode_ppk: item.provPerujuk.kode,
              nama_rs_ppk: item.provPerujuk.nama,
              kode_poli: item.poliRujukan.kode,
              nama_poli: item.poliRujukan.nama,
            });
          });
        }
        resolve(arr);
      })
      .catch((err) => {
        reject(err);
      });
  });

  const rujukanDua = new Promise((resolve, reject) => {
    const url = "http://10.10.11.202/BpjsApi/Rujukan/rujukan_multi_dari_rs";
    return axios
      .get(url, {
        params: {
          noka: bpjs,
        },
      })
      .then((payload) => {
        let data = payload.data;
        let arr = [];
        if (data && data.response && data.response.rujukan) {
          data.response.rujukan.map((item) => {
            arr.push({
              no_rujukan: item.tglKunjungan,
              tgl_rujukan: item.noKunjungan,
              kode_ppk: item.provPerujuk.kode,
              nama_rs_ppk: item.provPerujuk.nama,
              kode_poli: item.poliRujukan.kode,
              nama_poli: item.poliRujukan.nama,
            });
          });
        }
        resolve(arr);
      })
      .catch((err) => {
        reject(err);
      });
  });

  return rujukanSatu
    .then((satu) => {
      return success(req, res, satu, "OK", 200);
    })
    .catch(() => {
      return rujukanDua
        .then((dua) => {
          return success(req, res, dua, "OK", 200);
        })
        .catch((err) => {
          return error(req, res, [], "Failed", 500, err);
        });
    });

  //   const urlBPJS2 = "http://10.10.11.202/BpjsApi/Rujukan/rujukan_multi_dari_rs";
};

exports.daftarPasien = (req, res) => {
  let {
    nik,
    kkNumber,
    name,
    gender, //L P
    placeOfBirth,
    dateOfBirth,
    religion, //islam|kristen|katolik| hindu|budha|khonghucu
    address,
    provinceCode,
    regencyCode,
    districtCode,
    villageCode,
    postalCode,
    rw,
    rt,
    insurrance, //0000|00001) 0000 untuk umum, 0001 untuk bpjs
    insurranceNumber,
    phoneNumber,
    email,
    occupation, //PNS|SWASTA|WIRASWASTA|BURUH|PETANI|IBU_RUMAH_TANGGA|PEDAGANG|TNI_POLRI|PELAJAR|MAHASISWA|PENELITI|PENSIUNAN|LAINNYA
    education, //BELUM_SEKOLAH|SD|SMP|SMA|DIPLOMA|S1|S2|S3
    tribe,
    motherName,
    maritalStatus,
    patientCompanion,
    disabilities,
  } = req.body;
  return error(
    req,
    res,
    {},
    "Pasien baru harap datang ke RS secara langsung",
    400,
    null
  );

  // if(!req.file){
  //   return error(req, res, {}, "Fill your ID's Photo!", 400, null);
  // }
  // const { filename } = req.file;

  //   const {
  //     name,
  //     gender,
  //     phoneNumber,
  //     dateOfBirth, //YYYY-MM-DD
  //     address,
  //   } = patientCompanion;
  let temp = {
    agama: null,
    pendidikan: null,
  };
  return models.ref_agama
    .findOne({
      where: {
        ref_agama_ket: {
          [Op.iLike]: `%${religion}%`,
        },
      },
    })
    .then((agama) => {
      temp = {
        ...temp,
        agama,
      };
      let strOccupation = "";
      if (occupation === "SMP") {
        strOccupation = "SLTP";
      } else if (occupation === "SMA") {
        strOccupation = "SLTA";
      } else {
        strOccupation = education;
      }
      return models.asp_ref_pendidikan
        .findOne({
          where: {
            pend_nama: {
              [Op.iLike]: `%${strOccupation}%`,
            },
          },
        })
        .then((pendidikan) => {
          temp = {
            ...temp,
            pendidikan,
          };
        });
    })
    .then(() => {
      let propinsi = getProvince(Number(provinceCode));
      let regency = getRegency(Number(regencyCode));
      let kotadati = getDistrict(Number(districtCode));
      let village = getVillage(Number(villageCode));

      address = address ? address.toUpperCase() : "";
      rt = rt ? rt.toUpperCase() : "";
      rw = rw ? rw.toUpperCase() : "";
      village = village ? village.village_name : "";
      regency = regency ? regency.district_name : "";
      kotadati = kotadati ? kotadati.district_name : "";
      propinsi = propinsi ? propinsi.province_name : "";

      name = name ? name.toUpperCase() : "";
      placeOfBirth = placeOfBirth ? placeOfBirth.toUpperCase() : "";
      let namaWaliDarurat = patientCompanion.name
        ? patientCompanion.name.toUpperCase()
        : "";
      alamatDomisili = address ? address.toUpperCase() : "";
      occupation = occupation ? occupation.toUpperCase() : "";
      tribe = tribe ? tribe.toUpperCase() : "";

      return models.pasienonline.create({
        regpsonline_id_jns_id: 1,
        regpsonline_id_jns_id_nomor: nik,
        regpsonline_namalengkap: name,
        regpsonline_namapanggilan: null,
        regpsonline_tmptlahir: placeOfBirth,
        regpsonline_tgllahir: dateOfBirth,
        regpsonline_jnskelamin: gender === "L" ? 1 : 2,
        regpsonline_alamat: `${address} ${rt}/${rw} ${village} ${regency} ${kotadati} ${propinsi} ${postalCode}`,
        regpsonline_rtrw: rt + "/" + rw,
        regpsonline_kelurahan: village,
        regpsonline_kecamatan: regency,
        regpsonline_kotadati: kotadati,
        regpsonline_kdpos: postalCode,
        regpsonline_propinsi: propinsi,
        regpsonline_notelpon: phoneNumber,
        regpsonline_agama: temp.agama ? temp.agama.ref_agama_id : 7,
        regpsonline_nilaiyakin: null,
        regpsonline_textnilaiyakin: null,
        regpsonline_stsnikah: maritalStatus === "KAWIN" ? 2 : 1,
        regpsonline_stswarganegara: null,
        regpsonline_infoibu: motherName,
        regpsonline_infoayah: "",
        regpsonline_infoistrisuami: "",
        regpsonline_nopenjamin: insurranceNumber,
        regpsonline_nmwalidarurat: namaWaliDarurat,
        regpsonline_telponwalidarurat: patientCompanion.phoneNumber,
        // regpsonline_fileupload: filename,
        // regpsonline_filephoto: filename,
        regpsonline_flig_flag: false,
        regpasienonline_notelpon2: null,
        regpsonline_alamat_domisili: alamatDomisili,
        regpsonline_stspendidikan: temp.pendidikan
          ? temp.pendidikan.pend_id
          : 10,
        regpsonline_penjamin: insurrance === 0001 ? 85931 : -1,
        regpsonline_bahasa: null,
        regpsonline_infokerja: occupation,
        regpsonline_produk_id: null,
        regpsonline_tgl_kunjungan: null,
        regpsonline_disabilitas: disabilities,
        regpsonline_email: email,
        regpsonline_tribe: tribe,
        regpsonline_kk: kkNumber,
      });
    })
    .then((pasien) => {
      if (pasien) {
        return success(
          req,
          res,
          {
            nik: pasien.regpsonline_id_jns_id_nomor,
            kkNumber: pasien.regpsonline_kk,
            name: pasien.regpsonline_namalengkap,
            gender: pasien.regpsonline_jnskelamin,
            dateOfBirth: pasien.regpsonline_tgllahir,
            address: pasien.regpsonline_alamat,
            provinceCode: provinceCode,
            provinceName: pasien.regpsonline_propinsi,
            regencyCode: regencyCode,
            regencyName: pasien.regpsonline_kotadati,
            districtCode: districtCode,
            districtName: pasien.regpsonline_kecamatan,
            villageCode: villageCode,
            villageName: pasien.regpsonline_kelurahan,
            rw: rt,
            rt: rw,
            insurrance: insurrance,
            insurranceNumber: pasien.regpsonline_id_jns_id_nomor,
          },
          "Pasien berhasil terdaftar."
        );
      }
      return error(req, res, {}, "Gagal mendaftar", 400);
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal mendaftar", 500, err);
    });
};
