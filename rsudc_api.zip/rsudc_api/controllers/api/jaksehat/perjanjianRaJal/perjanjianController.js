const models = require("../../../../models");
const { QueryTypes, Op } = require("sequelize");
const { success, error, logger } = require("../helpers/responser");
const {
  getHari,
  stringToMR,
  batasPendaftaranRajal,
} = require("../../../../helpers/utility/common");
const moment = require("moment");
const { sequelize, Sequelize } = require("../../../../models");
const {
  quotaDokterHFIS,
  kuotaBerjalanDokter,
} = require("../../BPJS/Antrian/wsrsController");
const {
  mulaiAntriJKN,
  batalJKN,
} = require("../../BPJS/Antrian/wsBPJSController");
const { createAntrian, funCariRujukan } = require("../../layananController");
const { default: axios } = require("axios");

exports.createAppointment = async (req, res) => {
  let {
    noMR,
    bookingDate,
    policlinicID,
    doctorID,
    paymentID,
    referrralNumber,
    bpjsNumber,
    startTime,
    endTime,
  } = req.body;
  if (
    !noMR ||
    !bookingDate ||
    !policlinicID ||
    !doctorID ||
    !paymentID ||
    // !referrralNumber ||
    // !bpjsNumber ||
    !startTime ||
    !endTime
  ) {
    return error(req, res, {}, "Invalid Parameters", 400);
  }

  let validDate = moment(bookingDate, "YYYY-MM-DD", true);
  if (!validDate.isValid()) {
    return error(req, res, {}, "Date format is YYYY-MM-DD", 400);
  }

  if (!validDate.isValid()) {
    return error(req, res, {}, "Date format is YYYY-MM-DD", 400);
  }

  if (getDiffDay(bookingDate) >= 0) {
    return error(req, res, {}, "Hanya Untuk Hari Mendatang", 400);
  }
  if (paymentID == "bpjs") {
    if (!bpjsNumber) {
      return error(req, res, {}, "Invalid Parameters", 400);
    }
  }
  startTime = startTime.substring(0, 5);
  endTime = endTime.substring(0, 5);
  let day = getHari(moment().format("dddd"));
  if (batasPendaftaranRajal(bookingDate)) {
    return error(
      req,
      res,
      {},
      "Batas pendaftaran poli H-1 pukul 14:00 WIB",
      400
    );
  }
  logger.fatal("================== MULAI JAKSEHAT =============");
  logger.fatal(req.body);
  // let doctor_id = null;
  return models.dokter_bpjs
    .findOne({
      where: {
        dr_bpjs_kode: doctorID,
      },
    })
    .then((dokter) => {
      if (!dokter) {
        throw new Error("Dokter Tidak Tersedia");
      }
      let whr = {
        [Op.notIn]: [0, 19, 41, 20, 120],
        [Op.not]: null,
        [Op.eq]: policlinicID,
      };
      let whr_kdpoli = {
        [Op.notIn]: [
          "097",
          "034",
          // "017",
          "005",
          "007",
          "UGD",
          "APT",
          "LAB",
          "IGD",
          "RAD",
          "HDL",
          "PTD",
          // "BDM",
          "GAS",
          "ESW",
          "DRH",
        ],
        // [Op.notIn]: ["097", "034", "017", "007", "005"],
      };
      doctorID = dokter.dr_bpjs_id_peg;
      return models.refpoli_bpjs.findOne({
        where: {
          kd_layananpoli_rsc: whr,
          kdpoli: whr_kdpoli,
        },
        raw: true,
      });
    })
    .then((polibpjs) => {
      let kode_poli_bpjs = polibpjs.kdpoli;
      if (!polibpjs) {
        throw new Error("Poli tidak tersedia");
      }
      if (paymentID === "umum" || paymentID === "UMUM") {
        return createAntrian({
          mr: noMR,
          id_layanan: policlinicID,
          tanggal: bookingDate,
          doctor_id: doctorID,
          is_bpjs: false,
          no_rujukan: "",
          // jenis_kunjungan,
          no_kartu: "",
          nik: "",
          waktu: `${startTime}-${endTime}`,
          penanggung_id: "",
          kd_poli: polibpjs.kdpoli,
          kd_poli_rujukan: "",
          jenis_reservasi: 4,
        });
      }
      if (policlinicID == 14) {
        kode_poli_bpjs = "INT";
      }
      // return axios
      //   .get("http://192.168.200.103:5001/api/layanan/cari-rujukan", {
      //     params: {
      //       noka: bpjsNumber,
      //     },
      //   })
      //   .catch((err) => {
      //     if (
      //       err.response &&
      //       err.response.data &&
      //       err.response.data.status === 400
      //     ) {
      //       throw new Error("Rujukan tidak ada");
      //     }
      //   })
      return funCariRujukan(bpjsNumber, true)
        .then((rujukan) => {
          let no_rujukan = "";
          // if (rujukan.data.status !== 200 || !rujukan.data.data) {
          //   throw new Error("Rujukan tidak ada");
          // }

          let found = rujukan.find(
            (e) => e.poliRujukan.kode === kode_poli_bpjs
          );
          console.log(found);
          if (found) {
            no_rujukan = found.noKunjungan;
          } else {
            no_rujukan = rujukan[0].noKunjungan;
          }
          // if (referrralNumber) {
          //   no_rujukan = referrralNumber;
          // }
          console.log("rujukan=========", no_rujukan);
          return no_rujukan;
        })
        .then((no_rujukan) => {
          return axios
            .get("http://192.168.200.8:8080/RsudcApi/CariRujukanByNorujukF1", {
              params: {
                norujuk: no_rujukan,
              },
            })
            .then((rujuksatu) => {
              if (rujuksatu.data.metaData.code === 200) {
                return rujuksatu.data.response;
              }
              return axios
                .get(
                  "http://192.168.200.8:8080/RsudcApi/CariRujukanByNorujukF2",
                  {
                    params: {
                      norujuk: no_rujukan,
                    },
                  }
                )
                .then((rujukdua) => {
                  if (rujukdua.data.metaData.code === 200) {
                    return rujukdua.data.response;
                  }
                  throw new Error("Rujukan tidak ditemukan");
                });
            });
        })
        .then((rujuk) => {
          return createAntrian({
            mr: noMR,
            id_layanan: policlinicID,
            tanggal: bookingDate,
            doctor_id: doctorID,
            is_bpjs: true,
            no_rujukan: rujuk.rujukan.noKunjungan,
            // jenis_kunjungan,
            no_kartu: bpjsNumber,
            nik: "",
            waktu: `${startTime}-${endTime}`,
            penanggung_id: "",
            kd_poli: kode_poli_bpjs,
            kd_poli_rujukan: rujuk.rujukan.poliRujukan.kode,
            jenis_reservasi: 4,
          });
        });
    })
    .then((payload) => {
      logger.fatal("Success JKN");
      return success(
        req,
        res,
        {
          bookingcode: payload.rkun_id,
          queueNumber: payload.no_antri,
          waitingNumber: payload.no_antri,
        },
        "OK",
        200
      );
    })
    .catch((err) => {
      logger.fatal(err.toString());
      return error(req, res, {}, "Failed", 500, err);
    });
};

exports.findAppointment = async (req, res) => {
  const { noMr, startDate, endDate } = req.params;

  if (!noMr || !startDate || !endDate) {
    return error(req, res, {}, "Invalid Parameters", 400, null);
  }
  const isStartDateValid = moment(startDate, "YYYY-MM-DD", true).isValid();
  const isEndDateValid = moment(endDate, "YYYY-MM-DD", true).isValid();
  if (!isStartDateValid || !isEndDateValid) {
    return error(req, res, {}, "Date Format : YYYY-MM-DD", 400, null);
  }
  return models.rencana_kunjungan
    .findAll({
      attributes: [
        "rkun_nomor",
        "rkun_id",
        "rkun_batal",
        "rkun_waktu_daftarulang",
        "rkun_tgl_daftar",
      ],
      include: [
        {
          model: models.asp_pasien,
          attributes: ["ps_id", "ps_namalengkap"],
          required: true,
          as: "asp_pasien",
          include: {
            attributes: ["ps_id", "ps_mrn"],
            model: models.pasien,
            as: "pasien",
            where: {
              ps_mrn: stringToMR(noMr),
            },
          },
        },
        {
          model: models.dokter_bpjs,
          required: true,
          as: "many_dokter_bpjs",
          limit: 1,
        },
        {
          model: models.jml_nelp,
          required: false,
          as: "jml_nelp",
          include: [
            {
              model: models.refpoli_bpjs,
              required: false,
              as: "poli_bpjs",
            },
          ],
        },
      ],
      where: {
        // rkun_batal: {
        //   [Op.or]: [false, null],
        // },
        rkun_tgl_visit: {
          [Op.between]: [startDate, endDate],
        },
      },
    })
    .then((payload) => {
      const arr = [];
      payload.map((item) => {
        let jadwal = item.jml_nelp ? item.jml_nelp.pesanfoot1 : null;
        let rgx = /[\d:/]/g;
        let jadwalParsed = jadwal ? jadwal.match(rgx).join("").split("/") : "";
        return arr.push({
          bookingCode: item.rkun_id,
          noMR: item.asp_pasien.pasien.ps_mrn,
          patientName: item.asp_pasien.ps_namalengkap,
          bookingDate: item.rkun_tgl_daftar,
          policlinicID: item.jml_nelp
            ? item.jml_nelp.poli_bpjs
              ? item.jml_nelp.poli_bpjs.kdpoli
              : "POLI RSUD"
            : "POLI RSUD",
          policlinicName: item.jml_nelp
            ? item.jml_nelp.poli_bpjs
              ? item.jml_nelp.poli_bpjs.nmpoli
              : "POLI RSUD"
            : "POLI RSUD",
          doctorID: item.many_dokter_bpjs
            ? item.many_dokter_bpjs[0].dr_bpjs_kode
            : "DOKTER RSUD",
          doctorName: item.many_dokter_bpjs
            ? item.many_dokter_bpjs[0].dr_bpjs_nama
            : "DOKTER RSUD",
          paymentID: item.is_bpjs ? "bpjs" : "umum",
          queueNumber: item.rkun_nomor.toString(),
          startTime: jadwalParsed ? jadwalParsed[0] : "07:00",
          endTime: jadwalParsed ? jadwalParsed[0] : "12:00",
          waitingNumber: 1,
          statusID: item.rkun_batal ? 3 : item.rkun_waktu_daftarulang ? 2 : 1,
        });
      });
      return success(req, res, arr, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Failed", 500, err);
    });
};

const countPatient = async (date) => {
  return models.rencana_kunjungan.count({
    where: {
      rkun_reservasi: true,
      rkun_tgl_visit: date,
    },
  });
};

const getKunjungan = async (psId, tgl) => {
  return models.rencana_kunjungan.findOne({
    where: {
      rkun_reservasi: true,
      rkun_batal: {
        [Op.or]: [false, null],
      },
      rkun_id_pasien: psId,
      rkun_tgl_visit: tgl,
    },
    order: [["rkun_tgl_visit", "DESC"]],
  });
};

const getHoliday = async (date) => {
  return models.kalender_libur.findOne({
    where: {
      kal_libur_tgl: date,
    },
  });
};

const noAntri5 = async (idLayanan, date, psID, pegid) => {
  // const query = "select smsnoantri5(:idLayanan,:date,1,:psID) as data";
  const query = "select fnoantri(:idLayanan,:date,1,:psID, :doctorId) as data";

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        idLayanan: idLayanan,
        date: date,
        psID: psID,
        doctorId: pegid,
      },
    })
    .then((payload) => {
      return payload[0];
    });
};

const checkHourQuota = async (layananId, day) => {
  const query = `
  SELECT 
  id_quota, 
  jamke1, 
  jamke2, 
  jamke3, 
  jamke4, 
  jamke5, 
  jamke6, 
  quota_id_layanan, 
  hari, 
  jambuka, 
  jml_quota, 
  interv, 
  intervaljam, 
  intervaljam2 
from 
  quota_pasien_poli 
where 
  quota_id_layanan = :layananId 
  and hari = :day
`;

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        layananId: layananId,
        day: day,
      },
    })
    .then((payload) => {
      return payload[0];
    });
};
const sumTime = (props) => {
  // let args = Array.prototype.slice.call(arguments);
  let i = 0;
  let hour = 0;

  props.forEach((time) => {
    let arr = time.split(":");
    hour = parseInt(arr[0]);
    i += parseInt(arr[0]) * 60 + parseInt(arr[1]);
  });
  hour = Math.floor(i / 60);
  i = i % 60;
  return `${hour < 10 ? "0" + hour : hour}:${i < 10 ? "0" + i : i}`;
};
const getVisitTime = async (noAntri, layananId, day) => {
  const result = await checkHourQuota(layananId, day);
  if (!result) {
    return error(req, res, {}, "Ada Kesalahan", 400);
  }

  let intervalOne = result.intervaljam;
  let intervalTwo = result.intervaljam2;
  let q1 = result.jamke1;
  let q2 = result.jamke2;
  let q3 = result.jamke3;
  let q4 = result.jamke4;
  let q5 = result.jamke5;
  let q6 = result.jamke6;
  let timeStart = result.jambuka;
  let minute = "00:00";
  let openTime = sumTime([timeStart, minute]);
  let QueueNo = noAntri + 1;
  let message = "";
  let nextTime = "";
  let nextTimeLagi = "";
  if (QueueNo <= q1) {
    nextTime = sumTime([openTime, intervalOne]);
    message = "Pkl " + openTime + " s/d " + nextTime + " WIB";
  }

  if (QueueNo > q1 && QueueNo <= q1 + q2) {
    nextTime = sumTime([openTime, intervalOne]);
    nextTimeLagi = sumTime([openTime, intervalOne, intervalTwo]);
    message = "Pkl " + openTime + " s/d " + nextTimeLagi + " WIB";
  }

  if (QueueNo > q1 + q2 && QueueNo <= q1 + q2 + q3) {
    nextTime = sumTime([openTime, intervalOne, intervalTwo]);
    nextTimeLagi = sumTime([openTime, intervalOne, intervalTwo, intervalTwo]);
    message = "Pkl " + nextTime + " s/d " + nextTimeLagi + " WIB";
  }

  if (QueueNo > q1 + q2 + q3 && QueueNo <= q1 + q2 + q3 + q4) {
    nextTime = sumTime([openTime, intervalOne, intervalTwo, intervalTwo]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    message = "Pkl " + nextTime + " s/d " + nextTimeLagi + " WIB";
  }
  if (QueueNo > q1 + q2 + q3 + q4 && QueueNo <= q1 + q2 + q3 + q4 + q5) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    message = "Pkl " + nextTime + " s/d " + nextTimeLagi + " WIB";
  }
  if (
    QueueNo > q1 + q2 + q3 + q4 + q5 &&
    QueueNo <= q1 + q2 + q3 + q4 + q5 + q6
  ) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    message = "Pkl " + nextTime + " s/d " + nextTimeLagi + " WIB";
  }
  if (
    QueueNo > q1 + q2 + q3 + q4 + q5 + q6 &&
    QueueNo <= q1 + q2 + q3 + q4 + q5 + q6 + q6
  ) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    message = "Pkl " + nextTime + " s/d " + nextTimeLagi + " WIB";
  }
  if (
    QueueNo > q1 + q2 + q3 + q4 + q5 + q6 + q6 &&
    QueueNo <= q1 + q2 + q3 + q4 + q5 + q6 + q6 + q6
  ) {
    nextTime = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    nextTimeLagi = sumTime([
      openTime,
      intervalOne,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
      intervalTwo,
    ]);
    message = "Pkl " + nextTime + " s/d " + nextTimeLagi + " WIB";
  }
  if (QueueNo > q1 + q2 + q3 + q4 + q5 + q6 + q6 + q6) {
    if (q1 > 0 && q2 == 0) {
      nextTime = sumTime([timeStart, intervalOne]);
      nextTime = sumTime([timeStart, intervalOne, intervalTwo]);
    } else {
      if (q1 > 0 && q2 > 0 && q3 == 0) {
        nextTime = sumTime([timeStart, intervalOne, intervalTwo]);
        nextTime = sumTime([timeStart, intervalOne, intervalTwo, intervalTwo]);
      }
      if (q1 > 0 && q2 > 0 && q3 > 0 && q4 == 0) {
        nextTime = sumTime([timeStart, intervalOne, intervalTwo, intervalTwo]);
        nextTime = sumTime([
          timeStart,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
      }
      if (q1 > 0 && q2 > 0 && q3 > 0 && q4 > 0 && q5 == 0) {
        nextTime = sumTime([
          timeStart,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
        nextTime = sumTime([
          timeStart,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
      }
      if (q1 > 0 && q2 > 0 && q3 > 0 && q4 > 0 && q5 > 0 && q6 == 0) {
        nextTime = sumTime([
          timeStart,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
        nextTime = sumTime([
          timeStart,
          intervalOne,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
          intervalTwo,
        ]);
      }

      message = "Pkl " + nextTime + " s/d " + nextTime + " WIB";
    }
  }
  return message;
};

const insertTotalNelp = async (body, type) => {
  if (type === "baru") {
    return models.jml_nelp.create(body);
  } else {
    return models.jml_nelp
      .update(
        {
          session_id: body.session_id,
          kode: body.kode,
        },
        {
          where: {
            rkunid: body.rkunid,
          },
        }
      )
      .then(() => {
        return models.jml_nelp.findOne({
          where: {
            rkunid: body.rkunid,
          },
        });
      });
  }
};

const checkAssuranceNo = async (noMr) => {
  const query = `
  select 
  ps_no_jmn_non_cash 
from 
  asp_pasien 
where 
  ps_id =(
    select 
      ps_id 
    from 
      pasien 
    where 
      ps_mrn = :mr'
  )
`;
  return models.sequelize.query(query, {
    type: QueryTypes.SELECT,
    replacements: {
      noMr: noMr,
    },
  });
};

const countQuota = async (day, layanan_id) => {
  return models.quota_pasien_poli.findOne({
    attributes: ["quota_id_layanan", "jml_quota"],
    where: {
      hari: day,
      quota_id_layanan: layanan_id,
    },
  });
};

const prosesAppointment = async (props) => {
  const {
    layananId,
    day,
    psId,
    dateYMD,
    // name,
    // noMr,
    // poliName,
    // dateDMY,
    // isOld,
    // isBPJS,
    // drId = 10080,
    // poliID,
    // paymentID,
    // refNumber,
    // noHpCript = "",
    kdpolibpjs,
    kddokter,
    waktu,
    pegid,
  } = props;

  let qDokter = 0;
  let qBerjalanDokter = 0;
  // let qBerjalanDokterBPJS = 0;
  let quota = 0;
  return Promise.all([
    quotaDokterHFIS(
      kdpolibpjs,
      dateYMD,
      kddokter,
      waktu,
      pegid,
      layananId
    ).then((data) => {
      quota = data;
    }),
    // kuotaBerjalanDokter(dateYMD, pegid, layananId).then((quota) => {
    //   qBerjalanDokter = quota;
    // }),
    // kuotaBerjalanDokter(dateYMD, pegid, layananId, true).then((quota) => {
    //   qBerjalanDokterBPJS = quota;
    // }),
    getKunjungan(psId, dateYMD).then((data) => {
      if (data) {
        throw new Error(
          "Nomor Antrean Hanya Dapat Diambil 1 Kali Pada Tanggal Yang Sama"
        );
      }
    }),
  ])
    .then(() => {
      if (quota.sisa_bpjs <= 0) {
        throw new Error("Quota Kosong");
      }
      return checkHourQuota(layananId, day).then((result) => {
        if (!result) {
          throw new Error("Quota Kosong!");
        }
        return noAntri5(layananId, dateYMD, psId, pegid);
      });
    })
    .then((antri) => {
      let result = antri.data.split("_");
      return getVisitTime(result[2], layananId, day).then((waktu) => {
        return {
          bookingcode: `${result[1]}`,
          queueNumber: `${result[2]}`,
          waitingNumber: Number(result[2]),
          estimasi: waktu,
        };
      });
    });

  // let quotaPoli = await countQuota(day, layananId);
  // let patientPoli = await countPatient(dateYMD);

  // let curTotalQuota = "99999";
  // let curTotalPatient = "0";

  // if (quotaPoli) {
  //   curTotalQuota = quotaPoli.jml_quota;
  //   if (curTotalQuota == "") {
  //     curTotalQuota = "99999";
  //   }
  //   if (curTotalQuota == "0") {
  //     curTotalQuota = "99999";
  //   }
  // } else {
  //   curTotalQuota = "99999";
  // }

  // if (!patientPoli) {
  //   curTotalPatient = "0";
  // } else {
  //   curTotalPatient = patientPoli;
  //   if (curTotalPatient == "") {
  //     curTotalPatient = "0";
  //   }
  // }

  // if (curTotalPatient >= curTotalQuota) {
  //   // return error(req, res, {}, "Quota Full", 400);
  //   throw new Error("Quota Full");
  // }

  // let rKun = await getKunjungan(psId);

  // if (rKun) {
  //   return {
  //     code: 201,
  //     message: "Sudah Terdaftar",
  //     data: rKun,
  //   };
  // }
  // let result = await noAntri5(layananId, dateYMD, psId);
  // let resultTwo = result.data.split("_");
  // let rkunId = null;
  // let rkunNo = null;
  // let waktu = null;
  // //   if (resultTwo[0] === "baru") {
  // rkunId = resultTwo[1];
  // rkunNo = resultTwo[2];
  // waktu = await getVisitTime(curTotalPatient, layananId, day);
  // //   }
  // return {
  //   bookingcode: rkunId,
  //   queueNumber: `${rkunNo}`,
  //   waitingNumber: Number(rkunNo),
  // };
};
const getDiffDay = (date) => {
  let now = moment(moment().format("YYYY-MM-DD"));
  let end = moment(date, "YYYY-MM-DD");
  let duration = moment.duration(now.diff(end));
  return duration.asDays();
};

const getPoliBPJS = async (poli_id) => {
  return models.refpoli_bpjs.findOne({
    where: {
      kd_layananpoli_rsc: poli_id,
    },
  });
};

const getPatient = async (noMr) => {
  let query = `select 
  a.ps_id, 
  ps_mrn, 
  ps_namalengkap, 
  umurws(ps_tgllahir) as umur, 
  umur(ps_tgllahir) as umur2, 
  is_lansia(ps_tgllahir), 
  ps_no_jmn_non_cash 
from 
  pasien a 
  join asp_pasien b on a.ps_id = b.ps_id 
where 
  a.ps_id != '-1' 
  and a.ps_mrn = mrn_decoded(:mrn)
limit 1;
`;

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        mrn: noMr,
      },
    })
    .then((payload) => {
      return payload[0];
    });
};

const cekPoli = async (ref_layanan_id) => {
  return models.ref_layanan.findOne({
    where: {
      ref_layanan_aktif: 1,
      ref_layanan_rj: true,
      [Op.or]: [
        {
          ref_layanan_up: true,
        },
        {
          ref_layanan_poli: true,
        },
      ],
      ref_layanan_id: {
        [Op.notIn]: [
          42, 59, 1115, 1109, 63, 101, 40, 73, 49, 27, 110, 57, 31, 17, 71, 118,
          21, 82, 33, 113, 95, 123, 1108, 1118, 28, 92, 90, 91, 122, 89, 117,
          62, 88,
        ],
      },
      ref_layanan_id: ref_layanan_id,
    },
  });
};

const getPatientBlackList = async (ps_id) => {
  return models.pasienblacklist.findOne({
    where: {
      id_ps: ps_id,
    },
  });
};

const isDokterOff = async (layananId, day) => {
  const query = `
  select 
  quota_id_layanan,
  hari,
  ref_layanan_nama
from
  quota_pasien_poli
  left join ref_layanan on ref_layanan_id = quota_id_layanan
where
  hari = :day
  and active = false
  and ref_layanan_id = :idLayanan
  and quota_id_layanan =(
    select
      id_layanan
    from
      sms_id_layanan
    where
      active is true
      and id_layanan = :idLayanan);
`;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        idLayanan: layananId,
        day: day,
      },
    })
    .then((payload) => {
      return payload[0];
    });
};

exports.sisaAntri = (req, res) => {
  const { kodebooking } = req.params;
  return models.rencana_kunjungan
    .findOne({
      attributes: [
        "rkun_nomor",
        "rkun_id",
        "rkun_batal",
        "rkun_waktu_daftarulang",
        "rkun_tgl_daftar",
        "rkun_tgl_visit",
        "rkun_id_layanan",
      ],
      include: [
        {
          model: models.asp_pasien,
          attributes: ["ps_id", "ps_no_jmn_non_cash"],
          required: true,
          as: "asp_pasien",
          include: {
            attributes: ["ps_id", "ps_mrn"],
            model: models.pasien,
            as: "pasien",
          },
        },
        // {
        //   model: models.refpoli_bpjs,
        //   required: false,
        //   as: "poli_bpjs",
        // },
        {
          model: models.dokter_bpjs,
          required: false,
          as: "many_dokter_bpjs",
        },
        {
          model: models.jml_nelp,
          required: true,
          as: "jml_nelp",
          include: [
            {
              model: models.refpoli_bpjs,
              required: false,
              as: "poli_bpjs",
            },
          ],
        },
      ],
      where: {
        rkun_id: kodebooking,
      },
    })
    .then((payload) => {
      let body = {};
      let jadwal = payload.jml_nelp.pesanfoot1;
      let rgx = /[\d:/]/g;
      let jadwalParsed = jadwal ? jadwal.match(rgx).join("").split("/") : "";

      return models.no_antri
        .findOne({
          where: {
            id_layanan: payload.rkun_id_layanan,
            tgl_no_antri: payload.rkun_tgl_visit,
            // no_all: {
            //   [Op.gt]: payload.rkun_nomor,
            // },
            sudah_dipanggil: false,
          },
          order: [["no_all", "ASC"]],
        })
        .then((antri) => {
          body = {
            noMR: payload.asp_pasien.pasien.ps_mrn,
            bookingDate: payload.rkun_tgl_daftar,
            policlinicID: payload.jml_nelp
              ? payload.jml_nelp.poli_bpjs
                ? payload.jml_nelp.poli_bpjs.kdpoli
                : "POLI RSUD"
              : "POLI RSUD",
            policlinicName: payload.jml_nelp
              ? payload.jml_nelp.poli_bpjs
                ? payload.jml_nelp.poli_bpjs.nmpoli
                : "POLI RSUD"
              : "POLI RSUD",
            doctorID: payload.many_dokter_bpjs
              ? payload.many_dokter_bpjs[0].dr_bpjs_kode
              : "DOKTER RSUD",
            doctorName: payload.many_dokter_bpjs
              ? payload.many_dokter_bpjs[0].dr_bpjs_nama
              : "DOKTER RSUD",
            paymentID: payload.is_bpjs ? "bpjs" : "umum", //ini kode dari siapa ?
            paymentName: payload.is_bpjs ? "BPJS" : "NON BPJS", //
            referrralNumber: "",
            bpjsNumber: payload.asp_pasien.ps_no_jmn_non_cash,
            startTime: jadwalParsed ? jadwalParsed[0] : "07:00",
            endTime: jadwalParsed ? jadwalParsed[1] : "12:00",
            bookingCode: payload.rkun_id.toString(),
            queueNumber: payload.rkun_nomor,
            queue: {
              untilMyTurn:
                payload.rkun_nomor > antri.no_all
                  ? payload.rkun_nomor - antri.no_all
                  : 0,
              currentBookingCode: antri.no_all,
              currentNumber: antri.no_all,
            },
          };
          return body;
        });
    })
    .then((payload) => {
      return success(req, res, payload, "OK", 200);
    })
    .catch((err) => {
      return error(req, res, {}, "Failed", 500, err);
    });
};

exports.cancelAppointment = (req, res) => {
  const { noMr, bookingCode } = req.body;
  if (!bookingCode || !noMr) {
    return error(req, res, {}, "Isi Parameter", 400, null);
  }
  return models.pasien
    .findOne({
      where: {
        ps_mrn: stringToMR(noMr),
      },
    })
    .then((pasien) => {
      if (!pasien) {
        throw new Error("Patient not found");
      }
      return models.rencana_kunjungan.update(
        {
          rkun_batal: true,
        },
        {
          where: {
            rkun_id_pasien: pasien.ps_id,
            rkun_id: bookingCode,
          },
        }
      );
    })
    .then(() => {
      return batalJKN({ kodebooking: bookingCode }).catch((err) => {
        console.log("Batal Error -----", err);
        return;
      });
    })
    .then((payload) => {
      return success(
        req,
        res,
        null,
        "OK. 1 appointment(s) has been canceled",
        200
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

const getDokterBPJS = (code) => {
  return models.dokter_bpjs
    .findOne({
      where: {
        dr_bpjs_kode: code,
      },
    })
    .then((data) => {
      if (!data) {
        throw new Error("Dokter Tidak Ditemukan");
      }
      return data;
    });
};
