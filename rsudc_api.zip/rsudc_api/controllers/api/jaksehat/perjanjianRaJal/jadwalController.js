const models = require("../../../../models");
const { Op } = require("sequelize");
const { parseJadwal } = require("../../../../helpers/parser/doctorParser");
const { success, error } = require("../helpers/responser");
const { pagination, getHari } = require("../../../../helpers/utility/common");
const axios = require("axios");
const { sequelize } = require("../../../../models");
const {
  quotaDokterHFIS,
  kuotaBerjalanDokter,
} = require("../../BPJS/Antrian/wsrsController");
const { checkJadwalRajal, functListPoli } = require("../../doctorController");
const moment = require("moment");

exports.jadwalPoliDokter = (req, res) => {
  const { poli_id, visit_date } = req.params;
  if (!poli_id || !visit_date) {
    return error(req, res, {}, "Please provide poli_id and visit_date", 400);
  }

  // filtered poli
  //   FIS	Fisioterapi	0
  // LAI	Lain-Lain	0
  // TUM	TUM	0
  // 034	ANAK NEUROLOGI	13
  // AKP	Akupuntur	120
  // 017	Bedah Onkologi	85
  // ANT	ANASTESI	41
  // 097	PARU	16
  // 097	ASMA DAN PPOK	16
  // 007	GINJAL-HIPERTENSI	14

  let url = "http://192.168.200.8:8080/RsudcApi/datadokter";
  let whr = {
    [Op.notIn]: [
      // 84, //BEDAH ANAK
      // 87, //BEDAH MULUT
      19, //EDUKASI
      41, //ANASTESI
      20, //LAKTASI
      0,
    ],
    [Op.not]: null,
    [Op.eq]: poli_id,
  };
  let whr_kdpoli = {
    [Op.notIn]: [
      "097",
      "034",
      // "017",
      "005",
      "007",
      "UGD",
      "APT",
      "LAB",
      "IGD",
      "RAD",
      "HDL",
      "PTD",
      "AKP",
      // "BDM",
      "GAS",
      "ESW",
      "DRH",
      "KEM",
      // "GND",
    ],
  };
  return models.quota_pasien_poli
    .findOne({
      where: {
        hari: getHari(getHari(moment(visit_date, "YYYY-MM-DD").format("dddd"))),
        quota_id_layanan: poli_id,
        active: false,
      },
    })
    .then((tutup) => {
      if (tutup) {
        throw new Error("Jadwal Kosong");
      }
      return models.refpoli_bpjs.findOne({
        where: {
          kd_layananpoli_rsc: whr,
          kdpoli: whr_kdpoli,
        },
      });
    })
    .then((layanan) => {
      if (!layanan) {
        throw new Error("Poli tidak tersedia");
      }
      return checkJadwalRajal({
        id_layanan: poli_id,
        kd_poli: layanan.kdpoli,
        tanggal: visit_date,
      });
      // console.log(layanan.kdpoli);
    })
    .then((filtered) => {
      let filtered_dokter = [];
      filtered.map((item) => {
        let times = [];
        item.jadwal_praktek.map((jadwal) => {
          let jadw = jadwal.jam.split("-");
          return times.push({
            start_time: jadw[0],
            end_time: jadw[1],
            quota_left: jadwal.sisa_kuota,
          });
        });
        return filtered_dokter.push({
          doctorId: item.kode_dokter_bpjs,
          doctorName: item.nama_dokter_bpjs,
          times: times,
        });
        // return filtered_dokter.push({
        //   doctorId: item.kode_dokter_bpjs,
        //   doctorName: item.nama_dokter_bpjs,
        //   times: [
        //     {
        //       start_time: jadwal[0],
        //       end_time: jadwal[1],
        //       quota_left: item.sisa_kuota,
        //     },
        //   ],
        // });
      });
      return filtered_dokter;
    })
    .then((payload) => {
      return success(req, res, payload, "Schedule Loaded", 200);
    })
    .catch((err) => {
      return error(req, res, [], "Failed", 500, err);
    });
};

exports.listPoli = (req, res) => {
  return functListPoli()
    .then((payload) => {
      let arr = [];
      payload.map((item) => {
        return arr.push({
          id: item.id_poli,
          name: item.ref_layanan_nama,
        });
      });
      return success(req, res, arr, "Poli Loaded", 200);
    })
    .catch((err) => {
      return error(req, res, [], "Failed", 500, err);
    });
};
