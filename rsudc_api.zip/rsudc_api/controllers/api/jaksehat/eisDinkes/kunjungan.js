const models = require("../../../../models");
const { sequelize } = require("../../../../models");
const { QueryTypes, Op } = require("sequelize");
const { successEis, errorEis } = require("../helpers/responser");

exports.perPoli = (req, res) => {
  const { date } = req.body;
  const { start, end } = date;
  const query = `
  select
     count(kun_id) as total
    ,kd as kode_poli
from
(
select
    kun_id
    ,upper(case
        when (select kdpoli from sep_history where idrkun = kun_id_rencana_kunjungan order by id desc limit 1) is not null
        then (select kdpoli from sep_history where idrkun = kun_id_rencana_kunjungan order by id desc limit 1)
    else
        (select kdpoli from refpoli_bpjs where kd_layananpoli_rsc = kun_id_layanan order by id_refpoli asc limit 1)
    end) as kd
    ,(select count(*) from billing where bill_id_rkun = kun_id_rencana_kunjungan) as ada
from
    kunjungan
where
    kun_inap is false
    and kun_tgl >= :start 
    and kun_tgl <= :end
    and kun_id_layanan not in (23,24,39)
) as hh
where length(kd) > 2 and ada > 0
group by kd
order by kd asc
`;
  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        start: start,
        end: end,
      },
    })
    .then((payload) => {
      let arr = [];
      let tot = 0;
      payload.map((item) => {
        tot += Number(item.total);
        return arr.push({
          ...item,
          total: Number(item.total),
        });
      });
      console.log(tot);
      return successEis(
        req,
        res,
        {
          faskes: "RSUD CENGKARENG",
          kunjungan: arr,
        },
        "SUCCESS",
        200
      );
    })
    .catch((err) => {
      return errorEis(req, res, null, "Ada Kesalahan", 400, err);
    });
};

exports.top10Diagnosa = (req, res) => {
  const { date, limit } = req.body;
  const { start, end } = date;
  const query = `
  select
*
from((
select
    'diagnosa_igd' as status
    ,icd_rjl_mr_code as kode_diagnosa
    ,count(icd_rjl_mr_code) as total
from
    kunjungan
        left join icd_rajal_mr on icd_rjl_mr_id_kunjungan = kun_id
where
    kun_inap is false
    and kun_tgl >= :start 
    and kun_tgl <= :end
    and kun_diproses is true
    and kun_id_layanan = 25
group by
    icd_rjl_mr_code
    order by total desc
limit :limit)
union all
(
select
    'diagnosa_ralan' as status
    ,icd_code as kode_diagnosa
    ,count(icd_code) as total
from
    kunjungan
        left join icd on icd_id_kunjungan = kun_id
where
    kun_inap is false
    and kun_tgl = now()::date
    and kun_diproses is true
    and kun_id_layanan != 25
    and icd_code != 'Z71.9'
group by
    icd_code
order by total desc limit :limit)
union all
(
select
    'diagnosa_ranap' as status
    ,inap_icd_kode as kode_diagnosa
    ,count(inap_icd_kode) as total
from
   inap_icd
where
    inap_icd_lastupdate::date = now()::date
    and inap_icd_kode != 'Z71.9'
group by
    inap_icd_kode
order by total desc limit :limit)

) as jj
  `;

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        start: start,
        end: end,
        limit: limit,
      },
    })
    .then((payload) => {
      let arrIGD = [];
      let arrRajal = [];
      let arrRanap = [];
      payload.map((item) => {
        if (item.status === "diagnosa_igd") {
          return arrIGD.push({
            ...item,
            total: Number(item.total),
          });
        } else if (item.status === "diagnosa_ranap") {
          return arrRanap.push({
            ...item,
            total: Number(item.total),
          });
        } else {
          return arrRajal.push({
            ...item,
            total: Number(item.total),
          });
        }
      });
      return successEis(
        req,
        res,
        {
          faskes: "RSUD CENGKARENG",
          diagnosa: {
            diagnosa_igd: arrIGD,
            diagnosa_ralan: arrRajal,
            diagnosa_ranap: arrRanap,
          },
        },
        "SUCCESS",
        200
      );
    })
    .catch((err) => {
      return errorEis(req, res, null, "Ada Kesalahan", 400, err);
    });
};
