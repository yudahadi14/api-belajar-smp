const { error, success } = require("../../helpers/utility/response");
const models = require("../../models");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const signAuthJwt = (data) => {
  return jwt.sign(data, "RSUDCKBR!DG!NG", {
    expiresIn: "1y",
  });
};

exports.getToken = (req, res) => {
  const { username, password } = req.body;

  return models.mst_auth_bridging
    .findOne({
      where: {
        auth_bridging_username: username,
      },
    })
    .then((payload) => {
      if (!payload) {
        throw Error("Username / password tidak sesuai");
      }
      let authenticated = bcrypt.compareSync(
        password,
        payload.auth_bridging_password
      );
      if (!authenticated) {
        throw Error("Username / password tidak sesuai");
      }
      const authToken = signAuthJwt({
        auth_bridging_name: payload.auth_bridging_name,
      });
      return success(
        req,
        res,
        {
          authToken: authToken,
        },
        "Token termuat",
        200
      );
    })
    .catch((err) => {
      return error(
        req,
        res,
        {},
        err.message ? err.message : "Ada Kesalahan",
        err.message ? 400 : 500,
        err
      );
    });
};

exports.addUser = (req, res) => {
  const { name, username, password } = req.body;
  let hashPassword = null;
  hashPassword = bcrypt.hashSync(password, 10);
  return models.mst_auth_bridging
    .create({
      auth_bridging_username: username,
      auth_bridging_password: hashPassword,
      auth_bridging_name: name,
    })
    .then((payload) => {
      return success(
        req,
        res,
        {
          auth_bridging_username: payload.auth_bridging_username,
          auth_bridging_name: payload.auth_bridging_name,
        },
        "User Bridging Terbuat",
        200
      );
    })
    .catch((err) => {
      console.log(err);
      return error(
        req,
        res,
        {},
        err.message ? err.message : "Ada Kesalahan",
        err.message ? 400 : 500,
        err
      );
    });
};
