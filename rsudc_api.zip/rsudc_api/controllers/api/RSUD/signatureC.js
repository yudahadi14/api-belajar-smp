const { success, error } = require("../../../helpers/utility/response");
// const CustomError = require("../../../helpers/utility/customError");
const models = require("../../../models");
const QRCode = require("qrcode");

exports.addSign = (req, res) => {
  const { signature_code, pegawai_id } = req.query;
  if (!signature_code || !pegawai_id) {
    return error(req, res, null, "Ada Kesalahan", 400, null);
  }
  return models.tsignature
    .findOne({
      where: {
        signature: signature_code,
      },
    })
    .then((exist) => {
      if (exist) {
        throw new Error("Kode Sudah Ada");
      }
    })
    .then(() => {
      return models.tsignature.create({
        signature: signature_code,
        pegawaiid: pegawai_id,
      });
    })
    .then((payload) => {
      return success(req, res, payload, "Signature Berhasil Dibuat");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getSign = (req, res) => {
  const { signature_code } = req.query;
  if (!signature_code) {
    return error(req, res, null, "Ada Kesalahan", 400, null);
  }
  return models.tsignature
    .findOne({
      where: {
        signature: signature_code,
      },
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Kode Tidak Ditemukan");
      }
      return models.pegawai.findOne({
        where: {
          peg_id: payload.pegawaiid,
        },
        attributes: ["peg_nama"],
      });
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Data tidak ditemukan!");
      }
      return res.render("signature/getPegawai", {
        peg_nama: payload.peg_nama,
      });
      // return success(
      //   req,
      //   res,
      //   {
      //     peg_nama: payload.peg_nama,
      //   },
      //   "Pegawai Termuat"
      // );
    })
    .catch((err) => {
      return error(req, res, null, "Ada Kesalahan", 500, err);
    });
};

exports.getSignPhoto = (req, res) => {
  const { signature_code } = req.query;
  if (!signature_code) {
    return error(req, res, null, "Ada Kesalahan", 400, null);
  }
  return models.tsignature
    .findOne({
      where: {
        signature: signature_code,
      },
    })
    .then((payload) => {
      if (!payload) {
        throw new Error("Kode Tidak Ditemukan");
      }
    })
    .then(() => {
      return QRCode.toDataURL(signature_code).then((url) => {
        let img = Buffer.from(url.split(",")[1], "base64");
        return img;
      });
    })
    .then((img) => {
      res.writeHead(200, {
        "Content-Type": "image/png",
        "Content-Length": img.length,
      });
      return res.end(img);
    })
    .catch((err) => {
      return error(req, res, null, "Ada Kesalahan", 500, err);
    });
};
