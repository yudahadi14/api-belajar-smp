const models = require("../../../models");
const { success, error } = require("../../../helpers/utility/response");
const jwt = require("jsonwebtoken");
const axios = require("axios");
const moment = require("moment");
const { QueryTypes, Op } = require("sequelize");

exports.findSignature = (req, res) => {
  const { value } = req.query;
  if (!value) {
    return error(req, res, {}, "Isi Parameter", 400, null);
  }
  return jwt.verify(value, process.env.SIGNATURE_KEY, function (err, decoded) {
    if (err) {
      return models.trx_signature
        .findOne({
          where: {
            signature: value,
          },
        })
        .then((signature) => {
          if (!signature) {
            throw new Error("Signature tidak ditemukan");
          }
          return success(req, res, signature, "Digital signature termuat.");
        })
        .catch((err) => {
          return error(req, res, {}, "Ada Kesalahan", 500, err);
        });
    }
    return success(req, res, decoded, "Digital signature termuat.");
  });
};

exports.addSignature = (req, res) => {
  const { peg_id, peg_nama } = req.body;

  if (!peg_id || !peg_nama) {
    return error(req, res, {}, "Isi Parameter", 400, null);
  }

  return models.trx_signature
    .create({
      peg_id,
      peg_nama,
    })
    .then((newSign) => {
      let token = jwt.sign(
        {
          id: newSign.signature_id,
          peg_id: newSign.peg_id,
          peg_nama: newSign.peg_nama,
        },
        process.env.SIGNATURE_KEY
      );
      return models.trx_signature
        .update(
          {
            signature: token,
          },
          {
            where: {
              signature_id: newSign.signature_id,
            },
          }
        )
        .then(() => {
          return token;
        });
    })
    .then((signature) => {
      return success(
        req,
        res,
        {
          signature: `${process.env.SERVER_URL}/api/rsud/signature/find?value=${signature}`,
        },
        "Digital signature terbuat."
      );
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
