const models = require("../../../models");
const md5 = require("md5");
const { error, success } = require("../../../helpers/utility/response");
const { sequelize } = require("../../../models");
const { Op } = require("sequelize");
const moment = require("moment");
const { getBulan } = require("../../../helpers/utility/common");

exports.kunjunganBulanan = (req, res) => {
  let payload = {
    rajal: [
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
    ],
    ranap: [
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },

      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
      {
        bulan: "Januari",
        total: 100,
      },
    ],
  };

  const getIGD = () => {
    return models.kunjungan.findAll({
      group: ["bulan"],
      order: [["bulan", "asc"]],
      attributes: [
        [sequelize.literal(`DATE_PART('MONTH', kun_tgl)`), "bulan"],
        [sequelize.literal(`COUNT(*)`), "total"],
      ],
      where: {
        kun_tgl: {
          [Op.gte]: moment().startOf("year"),
        },

        kun_id_layanan: 25,
      },
      raw: true,
    });
  };

  const getInap = () => {
    return models.kunjungan.findAll({
      group: ["bulan"],
      order: [["bulan", "asc"]],
      attributes: [
        [sequelize.literal(`DATE_PART('MONTH', kun_tgl)`), "bulan"],
        [sequelize.literal(`COUNT(*)`), "total"],
      ],
      where: {
        kun_tgl: {
          [Op.gte]: moment().startOf("year"),
        },
        kun_inap: true,
        kun_id_layanan: {
          [Op.not]: 39,
        },
      },
      raw: true,
    });
  };
  const getRajal = () => {
    return models.kunjungan.findAll({
      group: ["bulan"],
      order: [["bulan", "asc"]],
      attributes: [
        [sequelize.literal(`DATE_PART('MONTH', kun_tgl)`), "bulan"],
        [sequelize.literal(`COUNT(*)`), "total"],
      ],
      where: {
        kun_tgl: {
          [Op.gte]: moment().startOf("year"),
        },
        kun_diproses: true,
        kun_tervalidasi: true,
        kun_id_layanan: {
          [Op.not]: 25,
        },
      },
      raw: true,
    });
  };

  return Promise.all([getRajal(), getInap(), getIGD()]).then((data) => {
    let payload = {
      rajal: [],
      ranap: [],
      igd: [],
    };
    data[0].map((item) => {
      return payload.rajal.push({
        bulan: getBulan(item.bulan),
        total: Number(item.total),
      });
    });

    data[1].map((item) => {
      return payload.ranap.push({
        bulan: getBulan(item.bulan),
        total: Number(item.total),
      });
    });

    data[2].map((item) => {
      return payload.igd.push({
        bulan: getBulan(item.bulan),
        total: Number(item.total),
      });
    });

    // payload.rajal = data[0] ?? 0;
    // payload.ranap = data[1] ?? 0;
    // payload.igd = data[2] ?? 0;

    return success(req, res, payload, "", 200);
  });

  // return success(req, res, payload, "", 200);
  return models.kunjungan
    .findAll({
      group: ["bulan", "kun_inap"],
      attributes: [
        "kun_inap",
        [sequelize.literal(`DATE_PART('MONTH', kun_tgl)`), "bulan"],
        [sequelize.literal(`COUNT(*)`), "total"],
      ],
      where: {
        kun_tgl: {
          [Op.gte]: moment().startOf("year"),
        },
      },
      order: [["bulan", "asc"]],
      raw: true,
    })
    .then((data) => {
      let arr_rajal = [];
      let arr_ranap = [];
      data.map((item) => {
        if (item.kun_inap === true) {
          arr_ranap.push({
            bulan: getBulan(item.bulan),
            total: Number(item.total),
          });
        } else {
          arr_rajal.push({
            bulan: getBulan(item.bulan),
            total: Number(item.total),
          });
        }
      });
      return success(
        req,
        res,
        {
          rajal: arr_rajal,
          ranap: arr_ranap,
        },
        "",
        200
      );
    })
    .catch((err) => {
      return error(req, res, "", "", 500, err);
    });
};

exports.kunjunganMerchant = (req, res) => {
  const payload = [
    {
      label: "Internal",
      total: 0,
    },
    {
      label: "JKN",
      total: 0,
    },
    {
      label: "Jaksehat",
      total: 0,
    },
    {
      label: "RSUDC Mobile",
      total: 0,
    },
  ];

  const { type } = req.query;
  let where = sequelize.where(
    sequelize.fn("date", sequelize.col("tgl")),
    "=",
    moment().format("YYYY-MM-DD")
  );

  if (type === "bulan") {
    where = {
      [Op.and]: [
        {
          tgl: sequelize.where(
            sequelize.fn("date", sequelize.col("tgl")),
            ">=",
            moment().startOf("M").format("YYYY-MM-DD")
          ),
        },
        {
          tgl: sequelize.where(
            sequelize.fn("to_char", sequelize.col("tgl"), "MM"),
            "=",
            moment().format("MM")
          ),
        },
      ],
    };
  }
  return models.jml_nelp
    .findAll({
      attributes: [
        "jenis_reservasi",
        [sequelize.fn("count", sequelize.col("jenis_reservasi")), "total"],
      ],
      group: ["jenis_reservasi"],
      where: where,
      // tglkunjung: moment().format("YYYY-MM-DD"),
      raw: true,
    })
    .then((jml) => {
      let arr = payload;
      let total_internal = 0;
      jml.map((item) => {
        if (item.jenis_reservasi === 2) {
          return (arr[3].total = Number(item.total));
        } else if (item.jenis_reservasi === 3) {
          return (arr[1].total = Number(item.total));
        } else if (item.jenis_reservasi === 4) {
          return (arr[2].total = Number(item.total));
        } else {
          total_internal += Number(item.total);
          return (arr[0].total = Number(total_internal));
        }
      });
      return success(req, res, arr, "", 200);
    });
};

exports.kunjunganHarian = (req, res) => {
  const getIGD = () => {
    return models.kunjungan.count({
      where: {
        kun_tgl: moment().format("YYYY-MM-DD"),
        kun_id_layanan: 25,
      },
    });
  };

  const getInap = () => {
    return models.kunjungan.count({
      where: {
        kun_tgl: moment().format("YYYY-MM-DD"),
        kun_inap: true,
        kun_id_layanan: {
          [Op.not]: 39,
        },
      },
    });
  };
  const getRajal = () => {
    return models.kunjungan.count({
      where: {
        kun_tgl: moment().format("YYYY-MM-DD"),
        kun_diproses: true,
        kun_inap: false,
        kun_tervalidasi: true,
        kun_id_layanan: {
          [Op.not]: 25,
        },
      },
    });
  };

  const getRajalEnd = () => {
    return models.kunjungan.count({
      where: {
        kun_tgl: moment().format("YYYY-MM-DD"),
        kun_inap: false,
        kun_id_layanan: {
          [Op.not]: 25,
        },
      },
    });
  };

  return Promise.all([getRajal(), getRajalEnd(), getInap(), getIGD()]).then(
    (data) => {
      let payload = {
        rajal: 0,
        rajal_end: 0,
        ranap: 0,
        igd: 0,
      };

      payload.rajal = data[0] ?? 0;
      payload.rajal_end = data[1] ?? 0;
      payload.ranap = data[2] ?? 0;
      payload.igd = data[3] ?? 0;

      return success(req, res, payload, "", 200);

      // let payload = {
      //   rajal: 0,
      //   ranap: 0,
      //   igd: 0,
      // };
      // data.map((item) => {
      //   if (item.kun_id_layanan === 25) {
      //     payload.igd +=
      //   }
      // });
    }
  );
};

exports.kunjunganRajal = (req, res) => {
  return models.rencana_kunjungan
    .findAll({
      group: ["jml_nelp.jenis_reservasi"],
      // order: [["bulan", "asc"]],
      attributes: [
        [sequelize.literal(`jml_nelp.jenis_reservasi`), "jenis_reservasi"],
        [sequelize.literal(`COUNT(*)`), "total"],
      ],
      include: {
        attributes: [],
        model: models.jml_nelp,
        as: "jml_nelp",
      },
      where: {
        rkun_tgl_daftar: {
          [Op.gte]: moment().subtract(3, "months"),
        },
        rkun_inap: false,
      },
      raw: true,
    })
    .then((data) => {
      let arr = {
        online: 0,
        offline: 0,
      };
      data.map((item) => {
        if (item.jenis_reservasi === null) {
          arr.offline += Number(item.total);
        } else {
          arr.online += Number(item.total);
        }
      });
      return success(req, res, arr, "", 200);
    })
    .catch((err) => {
      return error(req, res, "", "", 500, err);
    });
};
