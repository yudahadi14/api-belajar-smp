const fs = require("fs");
const PdfMake = require("pdfmake");
const moment = require("moment");
const models = require("../../../models");
const {
  getHari,
  plainMr,
  stringToMR,
} = require("../../../helpers/utility/common");
const { error, success } = require("../../../helpers/utility/response");
const { Op } = require("sequelize");
const sequelize = require("sequelize");
// const roboto = require("../../../public/assets/fonts/Open_Sans/static/OpenSans/OpenSans-Regular.ttf");
// const robotoBold = require("../../../public/assets/fonts/Open_Sans/static/OpenSans/OpenSans-Bold.ttf");
// const robotoItalic = require("../../../public/assets/fonts/Open_Sans/static/OpenSans/OpenSans-Italic.ttf");
// const robotoBoldItalic = require("../../../public/assets/fonts/Open_Sans/static/OpenSans/OpenSans-BoldItalic.ttf");
exports.generatePDF = (req, res) => {
  const { type, kelahiran_id, peg_id } = req.query;
  if (!kelahiran_id) {
    return error(req, res, {}, "Isi Parameter", 400);
  }
  if (peg_id) {
    models.tkelahiran
      .findOne({
        where: {
          kelahiranid: kelahiran_id,
        },
      })
      .then((kelahiran) => {
        if (!kelahiran) {
          return;
        }
        return models.registrasi_bayi
          .findOne({
            where: {
              reg_bayi_nomor: kelahiran.noregistrasi,
            },
          })
          .then((reg) => {
            if (reg) {
              if (type === "back") {
                return models.riwayat_cetak_skl_blkg.create({
                  rcsb_id_peg: peg_id,
                  rcs_waktu: moment().format(),
                  rcs_id_reg_bayi: reg.reg_bayi_id,
                });
              } else {
                return models.riwayat_cetak_skl_depan.create({
                  rcs_id_peg: peg_id,
                  rcs_waktu: moment().format(),
                  rcs_id_reg_bayi: reg.reg_bayi_id,
                });
              }
            }
          });
      });
  }
  let fonts = {
    Roboto: {
      normal: "public/assets/fonts/Roboto-Regular.ttf",
      bold: "public/assets/fonts/Roboto-Bold.ttf",
      italics: "public/assets/fonts/Roboto-Italic.ttf",
      bolditalics: "public/assets/fonts/Roboto-BoldItalic.ttf",
    },
  };
  let pdfPrinter = new PdfMake(fonts);
  const getPersalinan = (id) => {
    let t = "Spontan";
    switch (id) {
      case 1:
        t = "Spontan";
        break;
      case 2:
        t = "SC";
        break;
      case 3:
        t = "Vacum";
        break;
      default:
        t = "Spontan";
        break;
    }
    return t;
  };
  return models.tkelahiran
    .findOne({
      where: {
        kelahiranid: kelahiran_id,
      },
      // include: {
      //   model: models.mjenispersalinan,
      //   required: true,
      //   as: "jenis_persalinan",
      // },
    })
    .then((skl) => {
      if (!skl) {
        throw new Error("SKL Tidak Ditemukan");
      }

      let NoSurat = skl.kelahiranid;
      let NoSertifikat = `${skl.noregistrasi}`;
      // let NoSertifikat = `${skl.kelahiranid}/RSUDC/${moment(
      //   skl.kelahirantgl,
      //   "YYYY-MM-DD"
      // ).format("MM")}/${moment(skl.kelahirantgl, "YYYY-MM-DD").format("y")}`;
      let DokterDPJP = skl.kelahirandpjp;
      let DokterDPJPNama = skl.kelahirandpjpnama;
      let NamaBayi = skl.namabayi;
      let NamaIbu = skl.namaibu ?? "-";
      let KTPIbu = skl.ktpibu ?? "-";
      let PekerjaanIbu = skl.pekerjaanibu ?? "-";
      let AlamatIbu = skl.alamatibu;
      let MRIbu = skl.mrnibu
        ? plainMr(skl.mrnibu).split("")
        : ["0", "0", "0", "0", "0", "0"];
      let NamaAyah = skl.namaayah ?? "-";
      let KTPAyah = skl.ktpayah ?? "-";
      let PekerjaanAyah = skl.pekerjaanayah ?? "-";
      let MRBayiOri = skl.mrnanak;
      let MRBayi = skl.mrnanak
        ? plainMr(skl.mrnanak).split("")
        : ["0", "0", "0", "0", "0", "0"];
      let HariLahir = moment(skl.kelahirantgl, "YYYY-MM-DD").format("dddd");
      let HariLahirIndo = getHari(HariLahir);
      let TglLahir = skl.kelahirantgl;
      let JamLahir = skl.kelahiranwaktu;
      let BeratBayi = skl.kelahiranbb;
      let TinggiBayi = skl.kelahiranpb;
      let KelahiranTunggal = skl.kelahirantunggal;
      let KelahiranJumlah = skl.kelahiranjumlahbayi;
      let KelahiranAnakKe = skl.kelahirananakke;
      let KelahiranNormal = skl.kelahirannormal;
      let jenispersalinanid = skl.jenispersalinanid;
      let KelahiranDenganTindakan = getPersalinan(skl.jenispersalinanid);
      let KelainanBawaan = skl.kelainanbawaan;
      let KelahiranKelamin = skl.kelahirankelamin;
      let TTDDPJP = skl.kelahiranttddpjp;
      let rightThumb = skl.fingerid1;
      let leftThumb = skl.fingerid2;
      let totalCopy = skl.totalcopy;
      let sklLocked = skl.skllocked;
      if (sklLocked) {
        throw new Error("SKL Locked");
      }
      const frontContent = [
        {
          layout: "noBorders",
          table: {
            widths: ["auto", "*", "auto"],
            body: [
              [
                {
                  image: "public/assets/images/dki.png",
                  fit: [50, 50],
                },
                [
                  {
                    text: `PEMERINTAH PROVINSI DAERAH KHUSUS IBUKOTA JAKARTA RUMAH SAKIT UMUM DAERAH CENGKARENG`,
                    alignment: "center",
                    bold: true,
                    fontSize: 14,
                  },
                  {
                    text: `Jalan Kamal Raya, Bumi Cengkareng Indah Cengkareng Timur
                        Telepon : 021-54372874, Fax : 021-5442693
                        Website: www.rsudcengkareng.com
                        Email : marketingrs@rsudcengkareng.com
                        JAKARTA`,
                    alignment: "center",
                  },
                ],
                {
                  image: "public/assets/images/logo_new.png",
                  fit: [75, 75],
                },
              ],
            ],
          },
        },
        {
          layout: "noBorders",
          table: {
            widths: ["*", "*"],
            body: [
              [
                {
                  text: `No. Surat : RM 037A REV.0.`,
                  fontSize: 10,
                },
                {
                  text: "Kode Pos : 11730",
                  fontSize: 10,
                  alignment: "right",
                },
              ],
            ],
          },
        },
        {
          pageBreak: type === "full" ? "after" : null,
          layout: {
            hLineWidth: function (i, node) {
              return i === 0 || i === node.table.body.length ? 2 : 0;
            },
            vLineWidth: function (i, node) {
              return i === 0 || i === node.table.widths.length ? 2 : 0;
            },
            hLineColor: function (i, node) {
              return i === 0 || i === node.table.body.length ? "black" : "gray";
            },
            vLineColor: function (i, node) {
              return i === 0 || i === node.table.widths.length
                ? "black"
                : "gray";
            },
            paddingLeft: function (i, node) {
              return 8;
            },
            paddingRight: function (i, node) {
              return 8;
            },
          },
          table: {
            widths: ["*"],
            body: [
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: ["*"],
                    body: [
                      [
                        {
                          text: [
                            {
                              text: "Surat Keterangan Lahir",
                              decoration: "underline",
                              fontSize: 14,
                            },
                            `\nBirth Certificate\nNo: ${NoSertifikat}`,
                          ],
                          fontSize: 12,
                          bold: true,
                          italics: true,
                          alignment: "center",
                        },
                      ],
                      // [
                      //   {
                      //     text: "Birth Certificate",
                      //     fontSize: 14,
                      //     alignment: "center",
                      //   },
                      // ],
                      // [
                      //   {
                      //     text: "No: 1426/RSUDC/07/22",
                      //     fontSize: 14,
                      //     alignment: "center",
                      //   },
                      // ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: ["auto", "*"],
                    body: [
                      [
                        {
                          text: [
                            {
                              text: "Yang bertanda tangan dibawah ini:",
                              decoration: "underline",
                            },
                            {
                              text: "\nThe undersigned Obstetrician",
                              italics: true,
                            },
                          ],
                        },
                        {
                          text: `${DokterDPJPNama}`,
                          bold: true,
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: ["auto"],
                    body: [
                      [
                        {
                          text: [
                            {
                              text: "Menerangkan dengan sesungguhnya bahwa telah lahir seorang bayi ",
                              decoration: "underline",
                            },
                            {
                              text: "Laki-Laki",
                              decoration:
                                KelahiranKelamin !== "L" ? "lineThrough" : "",
                            },
                            "/",
                            {
                              text: "Perempuan",
                              decoration:
                                KelahiranKelamin !== "P" ? "lineThrough" : "",
                            },
                            "*\n",
                            {
                              text: "Herewith certify the of a ",
                              italics: true,
                            },
                            {
                              text: "male",
                              decoration:
                                KelahiranKelamin !== "L" ? "lineThrough" : "",
                              italics: true,
                            },
                            "/",
                            {
                              text: "female infant",
                              italics: true,
                              decoration:
                                KelahiranKelamin !== "P" ? "lineThrough" : "",
                            },
                            "*\n",
                          ],
                        },
                        //   {
                        //     text: "Laki-laki",
                        //   },
                        //   {
                        //     text: "/",
                        //   },
                        //   {
                        //     text: "Perempuan",
                        //   },
                        //   {
                        //     text: "*",
                        //   },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: [30, "auto", "auto", "*"],
                    body: [
                      [
                        "",
                        {
                          text: [
                            {
                              text: "Nama",
                              decoration: "underline",
                            },
                            {
                              text: "\nName",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${NamaBayi}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "Anak dari Ibu",
                              decoration: "underline",
                            },
                            {
                              text: "\nMother's Name",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${NamaIbu}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "No. KTP/Paspor",
                              decoration: "underline",
                            },
                            {
                              text: "\nID / Passport no",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${KTPIbu}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "Pekerjaan",
                              decoration: "underline",
                            },
                            {
                              text: "\nOccupation",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${PekerjaanIbu}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "Alamat",
                              decoration: "underline",
                            },
                            {
                              text: "\nAddress",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${AlamatIbu}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "No RM Ibu",
                              decoration: "underline",
                            },
                            {
                              text: "\nMR Mother",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          table: {
                            body: [MRIbu],
                          },
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "Nama Ayah",
                              decoration: "underline",
                            },
                            {
                              text: "\nFather's Namer",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${NamaAyah}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "No. KTP/Paspor",
                              decoration: "underline",
                            },
                            {
                              text: "\nID / Passport no",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${KTPAyah}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "Pekerjaan",
                              decoration: "underline",
                            },
                            {
                              text: "\nOccupation",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          text: `${PekerjaanAyah}`,
                        },
                      ],
                      [
                        "",
                        {
                          text: [
                            {
                              text: "No RM Bayi",
                              decoration: "underline",
                            },
                            {
                              text: "\nMR Baby",
                              italics: true,
                            },
                          ],
                        },
                        ":",
                        {
                          table: {
                            body: [MRBayi],
                          },
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: [30, "*", "*", "*"],
                    body: [
                      [
                        "",
                        {
                          text: [
                            {
                              text: "Pada Hari",
                              decoration: "underline",
                            },
                            {
                              text: ` : ${HariLahirIndo}`,
                              decoration: "underline",
                            },
                            {
                              text: "\nOn Day",
                              italics: true,
                            },
                            {
                              text: ` : ${HariLahir}`,
                              italics: true,
                            },
                          ],
                        },
                        {
                          text: [
                            {
                              text: "Tanggal",
                              decoration: "underline",
                            },
                            {
                              text: ` : ${TglLahir}`,
                              decoration: "underline",
                            },
                            {
                              text: "\nDate",
                              italics: true,
                            },
                          ],
                        },
                        {
                          text: [
                            {
                              text: "Jam",
                              decoration: "underline",
                            },
                            {
                              text: ` : ${JamLahir} WIB`,
                              decoration: "underline",
                            },
                            {
                              text: "\nTime",
                              italics: true,
                            },
                          ],
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: [30, "auto", "*"],
                    body: [
                      [
                        "",
                        "Biodata:",
                        {
                          ol: [
                            {
                              text: [
                                {
                                  text: "Berat : ",
                                  decoration: "underline",
                                },
                                {
                                  text: `${BeratBayi}gr`,
                                  bold: true,
                                },
                                {
                                  text: "\nWeight",
                                  italics: true,
                                },
                              ],
                            },
                            {
                              text: [
                                {
                                  text: "Panjang : ",
                                  decoration: "underline",
                                },
                                {
                                  text: `${TinggiBayi}cm`,
                                  bold: true,
                                },
                                {
                                  text: "\nLength",
                                  italics: true,
                                },
                              ],
                            },
                            {
                              text: [
                                {
                                  text: "Kelahiran : ",
                                  decoration: "underline",
                                },
                                {
                                  text: "Tunggal / ",
                                  decoration:
                                    Number(KelahiranTunggal) === 0
                                      ? ["underline", "lineThrough"]
                                      : "underline",
                                },
                                {
                                  text: "Kembar ",
                                  decoration:
                                    Number(KelahiranTunggal) > 0
                                      ? ["underline", "lineThrough"]
                                      : "underline",
                                },
                                {
                                  text: "ke: ",
                                },
                                {
                                  text:
                                    Number(KelahiranTunggal) === 1
                                      ? `${KelahiranAnakKe}`
                                      : `${KelahiranJumlah} Anak Ke ${KelahiranAnakKe}`,
                                  bold: true,
                                },
                                {
                                  text: "\n",
                                  italics: true,
                                },
                                {
                                  text: "Single / ",
                                  italics: true,
                                  decoration:
                                    Number(KelahiranTunggal) === 0
                                      ? ["underline", "lineThrough"]
                                      : "underline",
                                },
                                {
                                  text: "Twin for",
                                  italics: true,
                                  decoration:
                                    Number(KelahiranTunggal) > 0
                                      ? ["underline", "lineThrough"]
                                      : "underline",
                                },
                              ],
                            },
                            {
                              text: [
                                {
                                  text: "Kelahiran Normal : ",
                                  decoration: "underline",
                                },
                                {
                                  text: [
                                    {
                                      text: "Ya",
                                      decoration:
                                        jenispersalinanid != 1
                                          ? ["underline", "lineThrough"]
                                          : "underline",
                                    },
                                    {
                                      text: " / ",
                                      decoration: "underline",
                                    },
                                    {
                                      text: "Tidak",
                                      decoration:
                                        jenispersalinanid == 1
                                          ? ["underline", "lineThrough"]
                                          : "underline",
                                    },
                                  ],
                                },
                                {
                                  text: "\nSpontaneous labor ",
                                  italics: true,
                                },
                                {
                                  text: [
                                    {
                                      text: "Yes",
                                      decoration:
                                        jenispersalinanid != 1
                                          ? "lineThrough"
                                          : "",
                                    },
                                    " / ",
                                    {
                                      text: "No",
                                      decoration:
                                        jenispersalinanid == 1
                                          ? "lineThrough"
                                          : "",
                                    },
                                  ],
                                },
                              ],
                            },
                            {
                              text: [
                                {
                                  text: "Kelahiran dengan tindakan : ",
                                  decoration: "underline",
                                },
                                {
                                  text: KelahiranDenganTindakan,
                                  bold: true,
                                },
                                {
                                  text: "\nPhatological Labour",
                                  italics: true,
                                },
                              ],
                            },
                            {
                              text: [
                                {
                                  text: "Kelainan bawaan : ",
                                  decoration: "underline",
                                },
                                {
                                  text: KelainanBawaan,
                                  bold: true,
                                },
                                {
                                  text: "\nHereditary defect",
                                  italics: true,
                                },
                              ],
                            },
                          ],
                        },
                      ],
                    ],
                  },
                },
              ],
            ],
          },
        },
        //   [
        //     {
        //       layout: "noBorders",
        //       margin: [8, 8],
        //       table: {
        //         widths: ["auto", "*", "auto"],
        //         body: [
        //           [
        //             {
        //               layout: "noBorders",

        //               table: {
        //                 widths: ["auto"],
        //                 body: [
        //                   [
        //                     {
        //                       qr: "${process.env.BASE_URL}/signature?signature_code=K5J5K-KK5KK-XDVMN",
        //                       fit: 50,
        //                       alignment: "center",
        //                     },
        //                   ],
        //                   [
        //                     {
        //                       text: "Syarifah Chairani, dr. Sp.OG",
        //                       alignment: "right",
        //                     },
        //                   ],
        //                 ],
        //               },
        //             },
        //             "",
        //             {
        //               layout: "noBorders",
        //               table: {
        //                 widths: ["auto"],
        //                 body: [
        //                   [
        //                     {
        //                       qr: "${process.env.BASE_URL}/signature?signature_code=K5J5K-KK5KK-XDVMN",
        //                       fit: 50,
        //                       alignment: "center",
        //                     },
        //                   ],
        //                   [
        //                     {
        //                       text: "Syarifah Chairani, dr. Sp.OG",
        //                       alignment: "right",
        //                     },
        //                   ],
        //                 ],
        //               },
        //             },
        //           ],
        //         ],
        //       },
        //     },
        //   ],
      ];
      const backContent = [
        {
          layout: "noBorders",
          table: {
            widths: ["auto", "*", "auto"],
            body: [
              [
                {
                  image: "public/assets/images/dki.png",
                  fit: [50, 50],
                },
                [
                  {
                    text: `PEMERINTAH PROVINSI DAERAH KHUSUS IBUKOTA JAKARTA RUMAH SAKIT UMUM DAERAH CENGKARENG`,
                    alignment: "center",
                    bold: true,
                    fontSize: 12,
                  },
                  {
                    text: `Jalan Kamal Raya, Bumi Cengkareng Indah Cengkareng Timur
                            Telepon : 021-54372874, Fax : 021-5442693
                            Website: www.rsudcengkareng.com
                            Email : marketingrs@rsudcengkareng.com
                            JAKARTA`,
                    alignment: "center",
                    fontSize: 10,
                  },
                ],
                {
                  image: "public/assets/images/logo_new.png",
                  fit: [75, 75],
                },
              ],
            ],
          },
        },
        {
          layout: "noBorders",
          margin: [0, 32, 0, 0],
          table: {
            widths: ["*", "*"],
            body: [
              [
                {
                  text: `Nama : ${NamaBayi} ${MRBayiOri}`,
                  fontSize: 10,
                },
              ],
            ],
          },
        },
        {
          layout: {
            hLineWidth: function (i, node) {
              return i === 0 || i === node.table.body.length ? 2 : 0;
            },
            vLineWidth: function (i, node) {
              return i === 0 || i === node.table.widths.length ? 2 : 0;
            },
            hLineColor: function (i, node) {
              return i === 0 || i === node.table.body.length ? "black" : "gray";
            },
            vLineColor: function (i, node) {
              return i === 0 || i === node.table.widths.length
                ? "black"
                : "gray";
            },
            paddingLeft: function (i, node) {
              return 8;
            },
            paddingRight: function (i, node) {
              return 8;
            },
          },
          table: {
            widths: ["*"],
            body: [
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: ["*"],
                    body: [
                      [
                        {
                          text: [
                            {
                              text: "Sidik Telapak Kaki Bayi",
                              decoration: "underline",
                              fontSize: 14,
                            },
                            "\nBaby's Foot Print",
                          ],
                          fontSize: 12,
                          bold: true,
                          italics: true,
                          alignment: "center",
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: ["*", "*"],
                    body: [
                      [
                        {
                          text: "Sidik Telapak Kaki Kiri",
                          decoration: "underline",
                          alignment: "center",
                        },
                        {
                          text: "Sidik Telapak Kaki Kanan",
                          decoration: "underline",
                          alignment: "center",
                        },
                      ],
                      [
                        {
                          text: "Left Foot Print",
                          alignment: "center",
                          italics: true,
                        },
                        {
                          text: "Right Foot Print",
                          alignment: "center",
                          italics: true,
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  table: {
                    widths: ["*", "*"],
                    body: [
                      [
                        {
                          qr: `${process.env.BASE_URL}/api/rsud/kelahiran/kaki-bayi?kelahiran_id=${kelahiran_id}`,
                          fit: 75,
                          alignment: "center",
                          margin: [5, 5],
                        },
                        {
                          qr: `${process.env.BASE_URL}/api/rsud/kelahiran/kaki-bayi?kelahiran_id=${kelahiran_id}`,
                          fit: 75,
                          alignment: "center",
                          margin: [5, 5],
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: ["*"],
                    body: [
                      [
                        {
                          text: [
                            {
                              text: "Sidik Ibu Jari Tangan Ibu",
                              decoration: "underline",
                              fontSize: 14,
                            },
                            "\nMother's Thumb Print",
                          ],
                          fontSize: 12,
                          bold: true,
                          italics: true,
                          alignment: "center",
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: ["*", "*"],
                    body: [
                      [
                        {
                          text: "Sidik Ibu Jari Kiri",
                          decoration: "underline",
                          alignment: "center",
                        },
                        {
                          text: "Sidik Ibu Jari Kanan",
                          decoration: "underline",
                          alignment: "center",
                        },
                      ],
                      [
                        {
                          text: "Left Thumb Print",
                          alignment: "center",
                          italics: true,
                        },
                        {
                          text: "Right Thumb Print",
                          alignment: "center",
                          italics: true,
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  table: {
                    widths: ["*", "*"],
                    body: [
                      [
                        {
                          qr: `${process.env.BASE_URL}/api/rsud/kelahiran/ibu-jari?kelahiran_id=${kelahiran_id}`,
                          fit: 75,
                          alignment: "center",
                          margin: [5, 5],
                        },
                        {
                          qr: `${process.env.BASE_URL}/api/rsud/kelahiran/ibu-jari?kelahiran_id=${kelahiran_id}`,
                          fit: 75,
                          alignment: "center",
                          margin: [5, 5],
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                {
                  text: "Dokter Yang Menolong",
                  bold: true,
                  alignment: "center",
                  fontSize: 12,
                  margin: [0, 16, 0, 0],
                },
              ],
              [
                {
                  qr: `${process.env.BASE_URL}/api/rsud/sign/get?signature_code=${TTDDPJP}`,
                  fit: 50,
                  alignment: "center",
                },
              ],
              [
                {
                  text: `${DokterDPJPNama}`,
                  alignment: "center",
                },
              ],
            ],
          },
        },
      ];
      let pdfHTML = {
        defaultStyle: {
          fontSize: 10,
        },
        watermark: {
          color: "gray",
          opacity: !peg_id ? 0.3 : 0,
          bold: true,
          italics: false,
          text: "COPY",
        },
        // content: [...frontContent],
      };
      if (type === "back") {
        pdfHTML = {
          ...pdfHTML,
          content: [...backContent],
        };
      } else if (type === "full") {
        pdfHTML = {
          ...pdfHTML,
          content: [...frontContent, ...backContent],
        };
      } else {
        pdfHTML = {
          ...pdfHTML,
          content: [...frontContent],
        };
      }
      if ((type === "back" || type === "full") && !peg_id) {
        models.tkelahiran.update(
          {
            skllocked: 1,
            totalcopy: sequelize.literal("totalcopy + 1"),
          },
          {
            where: {
              kelahiranid: kelahiran_id,
            },
          }
        );
      }
      res.set("content-type", "application/pdf");
      var pdfDoc = pdfPrinter.createPdfKitDocument(pdfHTML);
      //   pdfDoc.pipe(fs.createReadStream("document.pdf"));
      pdfDoc.pipe(res);
      pdfDoc.end();
    })
    .catch((err) => {
      return error(req, res, {}, "Isi Parameter", 500, err);
    });
};

exports.requestSKL = (req, res) => {
  const files = req.files;
  const { kelahiran_ke, tgl_lahiran, info_tambahan, kelahiran_id } = req.body;
  const { mr } = req.user;
  let foto_polisi = "";
  let foto_ktp = "";
  let foto_kk = "";
  let buku_nikah = "";
  files.map((item) => {
    if (item.fieldname === "laporan_polisi") {
      foto_polisi = `skl_request/${item.filename}`;
    } else if (item.fieldname === "ktp") {
      foto_ktp = `skl_request/${item.filename}`;
    } else if (item.fieldname === "kk") {
      foto_kk = `skl_request/${item.filename}`;
    } else if (item.fieldname === "buku_nikah") {
      buku_nikah = `skl_request/${item.filename}`;
    }
  });

  return models.requestskl
    .create({
      reqsklstatus: 1,
      reqskllaporanpolisi: foto_polisi,
      reqsklktp: foto_ktp,
      reqsklkk: foto_kk,
      reqsklbukunikah: buku_nikah,
      // reqsklmribu: mr,
      kelahiranid: kelahiran_id,
    })
    .then((uploaded) => {
      return success(req, res, uploaded, "Data Terupload.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.listKelahiran = (req, res) => {
  const { start, end } = req.query;
  const { mr } = req.user;
  if (!start || !end) {
    return error(req, res, {}, "Isi Parameter", 400);
  }
  return (
    models.tkelahiran
      .findAll({
        where: {
          // mrnibu: stringToMR(mr),
          mrnibu: "35-19-70",
          kelahiranstatus: 3,
          kelahirantgl: {
            [Op.between]: [start, end],
          },
        },
        // limit: 5,
        attributes: {
          include: [
            [
              sequelize.literal(`(
                    SELECT reqsklstatus
                    FROM requestskl request
                    WHERE
                        tkelahiran.kelahiranid = request.kelahiranid
                    ORDER BY request.reqsklid DESC
                    LIMIT 1
                )`),
              "request_status",
            ],
            // model: models.requestskl,
            // required: true,
            // order: [["reqsklid", "DESC"]],
            // // limit: 1,
            // as: "request"
          ],
        },
      })
      // return models.requestskl
      //   .findAll({
      //     where: {
      //       [Op.and]: [
      //         sequelize.literal("createdat::date >= " + `'${start}'`),
      //         sequelize.literal("createdat::date <= " + `'${end}'`),
      //       ],
      //       reqsklmribu: mr,
      //     },
      //   })
      .then((uploaded) => {
        return success(req, res, uploaded, "Data Terupload.");
      })
      .catch((err) => {
        return error(req, res, {}, "Ada Kesalahan", 500, err);
      })
  );
};

exports.getIbuJari = (req, res) => {
  const { kelahiran_id } = req.query;
  if (!kelahiran_id) {
    return error(req, res, {}, "Isi Parameter", 400);
  }
  return models.tkelahiran
    .findOne({
      where: {
        kelahiranid: kelahiran_id,
      },
      attributes: [
        "namaibu",
        "mrnibu",
        "mrnanak",
        "kelahirantgl",
        "kelahirankelamin",
        "namabayi",
      ],
    })
    .then((kelahiran) => {
      if (!kelahiran) {
        throw new Error("Data Tidak Ditemukan!");
      }
      return kelahiran;
    })
    .then((uploaded) => {
      return res.render("kelahiran/bayi", {
        namaibu: uploaded.namaibu,
        mrnibu: uploaded.mrnibu,
        mrnanak: uploaded.mrnanak,
        kelahirantgl: uploaded.kelahirantgl,
        kelahirankelamin: uploaded.kelahirankelamin,
        namabayi: uploaded.namabayi,
      });
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getKakiBayi = (req, res) => {
  const { kelahiran_id } = req.query;
  if (!kelahiran_id) {
    return error(req, res, {}, "Isi Parameter", 400);
  }
  return models.tkelahiran
    .findOne({
      where: {
        kelahiranid: kelahiran_id,
      },
      attributes: [
        "namaibu",
        "mrnibu",
        "mrnanak",
        "kelahirantgl",
        "kelahirankelamin",
        "namabayi",
      ],
    })
    .then((kelahiran) => {
      if (!kelahiran) {
        throw new Error("Data Tidak Ditemukan!");
      }
      return kelahiran;
    })
    .then((uploaded) => {
      return res.render("kelahiran/bayi", {
        namaibu: uploaded.namaibu,
        mrnibu: uploaded.mrnibu,
        mrnanak: uploaded.mrnanak,
        kelahirantgl: uploaded.kelahirantgl,
        kelahirankelamin: uploaded.kelahirankelamin,
        namabayi: uploaded.namabayi,
      });
    })
    .catch((err) => {
      console.log(err);
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.latestRequestSKL = (req, res) => {
  const { kelahiranid } = req.query;
  const { mr } = req.user;
  return (
    models.tkelahiran
      .findOne({
        where: {
          kelahiranid,
          mrnibu: stringToMR(mr),
        },
        include: {
          model: models.requestskl,
          required: true,
          limit: 1,
          order: [["reqsklid", "DESC"]],
          as: "request",
        },
        // attributes: {
        //   include: [
        //     [
        //       sequelize.literal(`(
        //             SELECT reqsklstatus
        //             FROM requestskl request
        //             WHERE
        //                 tkelahiran.kelahiranid = request.kelahiranid
        //             ORDER BY request.reqsklid DESC
        //             LIMIT 1
        //         )`),
        //       "request_status",
        //     ],
        //     // model: models.requestskl,
        //     // required: true,
        //     // order: [["reqsklid", "DESC"]],
        //     // // limit: 1,
        //     // as: "request"
        //   ],
        // },
      })
      // return models.requestskl
      //   .findAll({
      //     where: {
      //       [Op.and]: [
      //         sequelize.literal("createdat::date >= " + `'${start}'`),
      //         sequelize.literal("createdat::date <= " + `'${end}'`),
      //       ],
      //       reqsklmribu: mr,
      //     },
      //   })
      .then((uploaded) => {
        if (!uploaded) {
          throw new Error("Data Tidak Ditemukan");
        }
        return success(
          req,
          res,
          uploaded.request[0] || null,
          "Data Terupload."
        );
      })
      .catch((err) => {
        return error(req, res, {}, "Ada Kesalahan", 500, err);
      })
  );
};
