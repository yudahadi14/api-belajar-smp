const models = require("../../../models");
const md5 = require("md5");
const QRCode = require("qrcode");
const { error, success } = require("../../../helpers/utility/response");
const { Op } = require("sequelize");
// const Error = require("../../../helpers/utility/Error");
exports.addDevice = (req, res) => {
  const { devicename, sn, vc, ac, vkey } = req.body;

  return models.mfingerspot
    .create({
      fingerspotdn: devicename,
      fingerspotsn: sn,
      fingerspotvc: vc,
      fingerspotac: ac,
      fingerspotvkey: vkey,
    })
    .then((payload) => {
      return success(req, res, payload);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.getDevice = (req, res) => {
  const { vc } = req.query;
  if (vc) {
    return models.mfingerspot
      .findOne({
        where: {
          fingerspotvc: vc,
        },
      })
      .then((device) => {
        return {
          device_name: device.fingerspotdn,
          sn: device.fingerspotsn,
          vc: device.fingerspotvc,
          ac: device.fingerspotac,
          vkey: device.fingerspotvkey,
        };
      })
      .then((data) => {
        let aw = `${data.ac}${data.sn}`;
        return res.send(aw);
      });
  }
};

exports.addFinger = (req, res) => {
  const { RegTemp } = req.body;
  const { redirect_url } = req.query;
  let data = RegTemp.split(";");
  let vStamp = data[0];
  let sn = data[1];
  let user_id = data[2];
  let regTemp = data[3];
  return models.mfingerspot
    .findOne({
      where: {
        fingerspotsn: sn,
      },
    })
    .then((device) => {
      return {
        device_name: device.fingerspotdn,
        sn: device.fingerspotsn,
        vc: device.fingerspotvc,
        ac: device.fingerspotac,
        vkey: device.fingerspotvkey,
      };
    })
    .then((data) => {
      let salt = md5(`${data.ac}${data.vkey}${regTemp}${sn}${user_id}`);

      if (salt.toUpperCase() === vStamp.toUpperCase()) {
        return models.tfingerspotfinger
          .findOne({
            where: {
              fingerspotuserid: user_id,
            },
          })
          .then((ada) => {
            if (ada) {
              return models.tfingerspotfinger.update(
                {
                  fingerdata: regTemp,
                  fingerspotuserid: user_id,
                },
                {
                  where: {
                    fingerspotuserid: user_id,
                  },
                }
              );
            }
            return models.tfingerspotfinger.create({
              fingerspotuserid: user_id,
              fingerdata: regTemp,
            });
          });
      } else {
        throw new Error("Gagal Insert");
      }
    })
    .then(() => {
      if (redirect_url) {
        return res.send(redirect_url + "?result=1");
      }
      return res.send(
        `${process.env.SERVER_URL}/api/fingerprint/return-message?message=Berhasil Insert`
      );
    })
    .catch((err) => {
      console.log("======Fingerprint Gagal", err);
      if (redirect_url) {
        return res.redirect(redirect_url + "?result=0");
      }
      return res.send(
        `${process.env.SERVER_URL}/api/fingerprint/return-message?message=Gagal Insert`
      );
      // return models.mfingerspotuser
      //   .findOne({
      //     where: {
      //       fingerspotuserid: user_id,
      //     },
      //   })
      //   .then((user) => {
      //     return models.tkelahiran
      //       .findOne({
      //         where: {
      //           [Op.or]: [
      //             {
      //               fingerid1: user.fingerspotcode,
      //             },
      //             {
      //               fingerid2: user.fingerspotcode,
      //             },
      //           ],
      //         },
      //       })
      //       .then((kelahiran) => {
      //         if (kelahiran.fingerid1 === user.fingerspotcode) {
      //           kelahiran.fingerid1 = null;
      //         }
      //         if (kelahiran.fingerid2 === user.fingerspotcode) {
      //           kelahiran.fingerid2 = null;
      //         }
      //         kelahiran.save();
      //       })
      //       .finally(() => {
      //         if (redirect_url) {
      //           return res.redirect(redirect_url + "?result=0");
      //         }
      //         return res.send(
      //           `${process.env.SERVER_URL}/api/fingerprint/return-message?message=Gagal Insert`
      //         );
      //       });
      //   });
      // error(req, res, null, "Ada Kesalahan", 500, err);
    });
};

exports.register = (req, res) => {
  const { user_id, redirect_url } = req.query;
  if (!user_id) {
    return res.send("input user_id !");
  }
  $data = `${user_id};SecurityKey;30;${process.env.SERVER_URL}/api/fingerprint/process-register?redirect_url=${redirect_url};${process.env.SERVER_URL}/api/fingerprint/get-device`;
  return res.send($data);
};

exports.verification = (req, res) => {
  const { user_id } = req.query;
  if (!user_id) {
    return res.send("input user_id !");
  }
  return models.tfingerspotfinger
    .findOne({
      where: {
        fingerspotuserid: user_id,
      },
    })
    .then((data) => {
      if (!data) {
        throw new Error("Data tidak ditemukan");
      }
      let reg = `${user_id};${data.fingerdata};SecurityKey;10;${process.env.SERVER_URL}/api/fingerprint/process-verification;${process.env.SERVER_URL}/api/fingerprint/get-device;extraParams`;
      return res.send(reg);
    })
    .catch((err) => {
      return error(req, res, null, "Ada Kesalahan", 500, err);
    });
};

exports.processVerification = (req, res) => {
  // return models.tfingerspotfinger
  const { VerPas } = req.body;
  let data = VerPas.split(";");
  let user_id = data[0];
  let vStamp = data[1];
  let time = data[2];
  let sn = data[3];
  return models.tfingerspotfinger
    .findOne({
      where: {
        fingerspotuserid: user_id,
      },
    })
    .then((user) => {
      return models.mfingerspot
        .findOne({
          where: {
            fingerspotsn: sn,
          },
        })
        .then((device) => {
          let salt = md5(
            `${sn}${user.fingerdata}${device.fingerspotvc}${time}${user_id}${device.fingerspotvkey}`
          );

          if (vStamp.toUpperCase() === salt.toUpperCase()) {
            return res.send(
              `${process.env.SERVER_URL}/api/fingerprint/return-message?message=Verified`
            );
          } else {
            return res.send(
              `${process.env.SERVER_URL}/api/fingerprint/return-message?message=Tidak Terauthentikasi`
            );
          }
        });
    })
    .catch((err) => {
      return error(req, res, null, "Ada Kesalahan", 500, err);
    });
};

exports.generateVerification = (req, res) => {
  const { finger_code } = req.query;
  if (!finger_code) {
    return res.send("input finger_code !");
  }
  return models.mfingerspotuser
    .findOne({
      where: {
        fingerspotcode: finger_code,
      },
    })
    .then((fingerUser) => {
      if (!fingerUser) {
        throw new Error("Kode Tidak Ditemukan");
      }
      return models.tfingerspotfinger.findOne({
        where: {
          fingerspotuserid: fingerUser.fingerspotuserid,
        },
      });
    })
    .then((data) => {
      if (!data) {
        throw new Error("Data Tidak Ditemukan");
      }
      let url_register = `${process.env.SERVER_URL}/api/fingerprint/verification?user_id=${data.fingerspotuserid}`;
      url_register = Buffer.from(url_register).toString("base64");
      return res.redirect(`finspot:FingerspotVer;${url_register}`);
    })
    .catch((err) => {
      return error(req, res, null, "Ada Kesalahan", 500, err);
    });
};

exports.generateRegister = (req, res) => {
  const { finger_code, redirect_url } = req.query;
  if (!finger_code) {
    return res.send("input finger_code !");
  }
  return models.mfingerspotuser
    .findOne({
      where: {
        fingerspotcode: finger_code,
      },
    })
    .then((fingerUser) => {
      // if (fingerUser) {
      //   throw new Error("Kode Sudah Ada");
      //   // return fingerUser.fingerspotuserid;
      // }
      if (fingerUser) {
        return fingerUser.fingerspotuserid;
      }
      return models.mfingerspotuser
        .create({
          fingerspotcode: finger_code,
        })
        .then((newFinger) => {
          return newFinger.fingerspotuserid;
        });
    })
    .then((user_id) => {
      let url_register = `${process.env.SERVER_URL}/api/fingerprint/register?user_id=${user_id}&redirect_url=${redirect_url}`;
      url_register = Buffer.from(url_register).toString("base64");
      return res.redirect(`finspot:FingerspotReg;${url_register}`);
    })
    .catch((err) => {
      return error(req, res, null, "Ada Kesalahan", 500, err);
      // res.send(err.message);
    });
};

exports.returnMessage = (req, res) => {
  const { message } = req.query;
  return success(req, res, null, message, 200);
};

exports.testController = (req, res) => {
  return QRCode.toDataURL("I am a pony!")
    .then((url) => {
      let img = Buffer.from(url.split(",")[1], "base64");
      res.writeHead(200, {
        "Content-Type": "image/png",
        "Content-Length": img.length,
      });
      return res.end(img);
    })
    .catch((err) => {
      return error(req, res, null, "Ada Kesalahan", 500, err);
    });
};

exports.testQuery = (req, res) => {
  return models.sequelize
    .query("select top 10 * from  rsc.dbo.RSC_Produk")
    .then((payload) => {
      return success(req, res, payload);
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
