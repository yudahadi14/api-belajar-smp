const models = require("../../../models");
const { success, error } = require("../../../helpers/utility/response");
const axios = require("axios");
const moment = require("moment");
const ExcelJS = require("exceljs");
const { QueryTypes, Op } = require("sequelize");
const { pagination } = require("../../../helpers/utility/common");

exports.listJantung = (req, res) => {
  const { no_mr, nama_pasien, tanggal_mulai, tanggal_akhir, page } = req.query;
  const { limit, offset } = pagination(page > 0 ? page : 1);

  const query = `select 
  to_char(rkun_tgl_visit, 'DD-Mon-YYYY') AS tglkun, 
  kun_id_rencana_kunjungan, 
  kun_id, 
  rkun_nomor, 
  L.ref_layanan_nama, 
  P.ps_id,
  (
    select 
      CASE WHEN kun_diproses IS true THEN '<b>Sudah </b>' ELSE '<b>Belum</b>' END AS status 
    from 
      kunjungan 
    where 
      kun_id_rencana_kunjungan = rkun_id 
      and kun_id_layanan = rkun_id_layanan 
    limit 
      1
  ) as status, 
  ps_mrn, 
  ps_namalengkap, 
  (
    select 
      ref_waktu_ket 
    from 
      ref_waktu_kunjungan 
    where 
      ref_waktu_id = rkun_waktu
  ) as waktu, 
  CASE WHEN ps_jeniskelamin = 1 THEN 'L' ELSE 'P' END AS kelamin, 
  to_char(ps_tgllahir, 'DD-Mon-YYYY') || ' (' || get_umur(ps_tgllahir) || ')' AS umur, 
  ps_alamat || ps_kota_kab || ps_kodepos AS alamat, 
  CASE WHEN (
    SELECT 
      COUNT(*) 
    FROM 
      billing 
    WHERE 
      bill_id_kun = kun_id 
      AND bill_id_layanan = kun_id_layanan 
      AND bill_id_produk IN (
        SELECT 
          ref_prod_id 
        FROM 
          ref_produk 
        WHERE 
          ref_prod_is_registrasi = true 
          OR ref_prod_is_pemeriksaan = true
      ) 
      AND bill_id_pembayaran is not null
  ) > 0 THEN 'LUNAS' ELSE 'BELUM LUNAS' END AS Bayar, 
  ps_telpon 
from 
  rencana_kunjungan R 
  left join pasien P on P.ps_id = rkun_id_pasien 
  left join asp_pasien AP on AP.ps_id = rkun_id_pasien 
  left join rekam_medis_mutasi_berkas RM on RM.rm_mut_brks_id_rkun = R.rkun_id, 
  ref_layanan L, 
  Kunjungan Q 
where 
  Q.kun_id_layanan = 15 
  AND R.rkun_id_layanan = 15 
  AND R.rkun_id_pasien = P.ps_id 
  AND Q.kun_id_layanan = L.ref_layanan_id 
  AND R.rkun_id = Q.kun_id_rencana_kunjungan 
  and Q.kun_inap is false 
  and rm_mut_brks_id_peg_minta > 0 
  and (
    select 
      count(*) 
    from 
      billing 
    where 
      bill_id_rkun = R.rkun_id 
      and bill_tabel != 'pembayaran'
  ) > 0 
  AND rkun_tgl_visit between :tanggal_mulai and :tanggal_akhir
  ${no_mr ? "AND ps_mrn = :no_mr" : "--"}
  ${nama_pasien ? "AND ps_namalengkap ilike :nama_pasien" : "--"}
order by 
  rkun_tgl_visit DESC, 
  rkun_nomor, 
  rkun_waktu asc
`;

  const qCount = `select count(*) from (select 
to_char(rkun_tgl_visit, 'DD-Mon-YYYY') AS tglkun, 
kun_id_rencana_kunjungan, 
kun_id, 
rkun_nomor, 
L.ref_layanan_nama, 
(
  select 
    CASE WHEN kun_diproses IS true THEN '<b>Sudah </b>' ELSE '<b>Belum</b>' END AS status 
  from 
    kunjungan 
  where 
    kun_id_rencana_kunjungan = rkun_id 
    and kun_id_layanan = rkun_id_layanan 
  limit 
    1
) as status, 
ps_mrn, 
ps_namalengkap, 
(
  select 
    ref_waktu_ket 
  from 
    ref_waktu_kunjungan 
  where 
    ref_waktu_id = rkun_waktu
) as waktu, 
CASE WHEN ps_jeniskelamin = 1 THEN 'L' ELSE 'P' END AS kelamin, 
to_char(ps_tgllahir, 'DD-Mon-YYYY') || ' (' || get_umur(ps_tgllahir) || ')' AS umur, 
ps_alamat || ps_kota_kab || ps_kodepos AS alamat, 
CASE WHEN (
  SELECT 
    COUNT(*) 
  FROM 
    billing 
  WHERE 
    bill_id_kun = kun_id 
    AND bill_id_layanan = kun_id_layanan 
    AND bill_id_produk IN (
      SELECT 
        ref_prod_id 
      FROM 
        ref_produk 
      WHERE 
        ref_prod_is_registrasi = true 
        OR ref_prod_is_pemeriksaan = true
    ) 
    AND bill_id_pembayaran is not null
) > 0 THEN 'LUNAS' ELSE 'BELUM LUNAS' END AS Bayar, 
ps_telpon 
from 
rencana_kunjungan R 
left join pasien P on P.ps_id = rkun_id_pasien 
left join asp_pasien AP on AP.ps_id = rkun_id_pasien 
left join rekam_medis_mutasi_berkas RM on RM.rm_mut_brks_id_rkun = R.rkun_id, 
ref_layanan L, 
Kunjungan Q 
where 
Q.kun_id_layanan = 15 
AND R.rkun_id_layanan = 15 
AND R.rkun_id_pasien = P.ps_id 
AND Q.kun_id_layanan = L.ref_layanan_id 
AND R.rkun_id = Q.kun_id_rencana_kunjungan 
and Q.kun_inap is false 
and rm_mut_brks_id_peg_minta > 0 
and (
  select 
    count(*) 
  from 
    billing 
  where 
    bill_id_rkun = R.rkun_id 
    and bill_tabel != 'pembayaran'
) > 0 
AND rkun_tgl_visit between :tanggal_mulai and :tanggal_akhir
${no_mr ? "AND ps_mrn = :no_mr" : "--"}
${nama_pasien ? "AND ps_namalengkap ilike :nama_pasien" : "--"}
order by 
rkun_tgl_visit DESC, 
rkun_nomor, 
rkun_waktu asc) as c
`;

  return models.sequelize
    .query(query, {
      type: QueryTypes.SELECT,
      replacements: {
        no_mr: no_mr,
        limit: limit,
        offset: offset,
        nama_pasien: nama_pasien ? `%${nama_pasien}%` : "",
        tanggal_mulai: tanggal_mulai || moment().format("YYYY-MM-DD"),
        tanggal_akhir: tanggal_akhir || moment().format("YYYY-MM-DD"),
      },
    })
    .then((payload) => {
      return models.sequelize
        .query(qCount, {
          type: QueryTypes.SELECT,
          replacements: {
            no_mr: no_mr,
            limit: limit,
            offset: offset,
            nama_pasien: nama_pasien ? `%${nama_pasien}%` : "",
            tanggal_mulai: tanggal_mulai || moment().format("YYYY-MM-DD"),
            tanggal_akhir: tanggal_akhir || moment().format("YYYY-MM-DD"),
          },
        })
        .then((count) => {
          return {
            data: payload,
            count: count[0] ? count[0].count : 0,
          };
        });
    })
    .then((payload) => {
      let data = {
        list: payload.data,
        total_row: payload.count,
      };
      return success(req, res, data, "Termuat.");
    })
    .catch((err) => {
      return error(req, res, {}, "Gagal memuat", 500, err);
    });
};

exports.uploadJantung = (req, res) => {
  const file = req.files;
  const { rkun_id, diagnosa, no_telp, ps_id, tgl_tindakan } = req.body;
  // const { filename } = req.file;
  const { peg_id } = req.user;
  if (file.length === 0 || !rkun_id) {
    return error(req, res, {}, "Isi Parameter", 400);
  }
  if (!diagnosa) {
    return error(req, res, {}, "Isi Diagnosa", 400);
  }
  let root_id = 0;
  let uploaded = [];
  let promises = [];
  return models.trx_files
    .create({
      file_name: `${file[0].filename}`,
      file_type: "image",
    })
    .then((fil) => {
      root_id = fil.file_id;
      return models.trx_files
        .update(
          {
            file_root_id: root_id,
          },
          {
            where: {
              file_id: root_id,
            },
          }
        )
        .then(() => {
          file.map((item, index) => {
            if (index > 0) {
              return promises.push(
                models.trx_files.create({
                  file_name: `${item.filename}`,
                  file_type: "image",
                  file_root_id: fil.file_id,
                })
              );
            }
            return;
          });
        });
    })
    .then(() => {
      return Promise.all(promises);
    })
    .then(() => {
      return models.trx_jantung_upload
        .findOne({
          where: {
            rkun_id: rkun_id,
          },
        })
        .then((upl) => {
          if (!upl) {
            return models.trx_jantung_upload.create({
              rkun_id: rkun_id,
              files_id: root_id,
              ps_id: ps_id,
              diagnosa: diagnosa,
              no_telp: no_telp,
              tgl_tindakan: tgl_tindakan,
              created_by: peg_id,
            });
          }
          return models.trx_jantung_upload.update(
            {
              files_id: root_id,
              diagnosa: diagnosa,
              no_telp: no_telp,
              tgl_tindakan: tgl_tindakan,
              updated_by: peg_id,
              updated_at: Date.now(),
            },
            {
              where: {
                rkun_id: rkun_id,
              },
            }
          );
        });
    })
    .then(() => {
      return success(req, res, uploaded, "Data Terupload.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};

exports.findJantung = (req, res) => {
  const { rkun_id } = req.query;

  if (!rkun_id) {
    return error(req, res, {}, "Isi Parameter", 400);
  }

  return models.trx_jantung_upload
    .findOne({
      where: {
        rkun_id,
      },
      include: [
        {
          model: models.trx_files,
          as: "file",
          include: {
            model: models.trx_files,
            as: "children",
          },
        },
        {
          model: models.pegawai,
          as: "creator",
          attributes: ["peg_nopeg", "peg_nama"],
        },
        {
          model: models.pegawai,
          as: "updator",
          attributes: ["peg_nopeg", "peg_nama"],
        },
      ],
    })
    .then((jantung) => {
      if (!jantung) {
        throw new Error("Data Tidak Ada");
      }
      let file = [
        {
          file_id: jantung.file.file_id,
          file_name: jantung.file.file_name,
          file_type: jantung.file.file_type,
          created_by: jantung.file.created_by,
          updated_by: jantung.file.updated_by,
          file_root_id: jantung.file.file_root_id,
        },
      ];
      let body = jantung.dataValues;
      jantung.file.children.map((item) => {
        file.push(item);
      });
      return {
        ...body,
        file: file,
      };
    })
    .then((jantung) => {
      return success(req, res, jantung, "Data Terupload.");
    })
    .catch((err) => {
      return error(req, res, {}, "Ada Kesalahan", 500, err);
    });
};
