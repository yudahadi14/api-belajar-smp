<?php
//disini kita manggil koding yang ada di function.php
include "function.php";
