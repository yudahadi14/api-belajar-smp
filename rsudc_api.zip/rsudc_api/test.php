<?php
$key_hash = (hash('sha256', "9045rsudcgk1210161647317148"));
echo ($key_hash);
